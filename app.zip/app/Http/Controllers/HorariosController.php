<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;

class HorariosController extends Controller
{
    public function getNrcs(Request $request)
    {
        //dd(auth()->user()->dni);
        $dni = auth()->user()->dni;
        $periodo = $request['periodo'];

        //$dni = '76803802';
        //$periodo = '202320';
        //dd($periodo);

        $pdo = DB::connection('oracle')->getPdo();
        $stmt = $pdo->prepare("BEGIN ISIL.SP_ISILNET_GET_HORARIOS_NRCS(:dni, :periodo, :cursor); END;");
        $stmt->bindParam(':dni', $dni, \PDO::PARAM_STR);
        $stmt->bindParam(':periodo', $periodo, \PDO::PARAM_STR);
        $stmt->bindParam(':cursor', $cursor, \PDO::PARAM_STMT | \PDO::PARAM_INPUT_OUTPUT);
        //$stmt->bindParam(':cursor2', $cursor2, \PDO::PARAM_STMT | \PDO::PARAM_INPUT_OUTPUT);

        // Ejecutar la llamada al procedimiento almacenado
        $stmt->execute();
        oci_execute($cursor);
        oci_fetch_all($cursor, $data, null, null, OCI_FETCHSTATEMENT_BY_ROW);
        oci_free_statement($cursor);
        $stmt->closeCursor();
        return [
            "data" => $data,
            'rows' => count($data)
        ];
    }

    public function getHorarios(Request $request)
    {
        $dni = auth()->user()->dni;
        $periodo = $request['periodo'];

        //$dni = '76803802';
        //$periodo = '202320';

        $pdo = DB::connection('oracle')->getPdo();
        $stmt = $pdo->prepare("BEGIN ISIL.SP_ISILNET_GET_HORARIOS(:dni, :periodo, :cursor); END;");
        $stmt->bindParam(':dni', $dni, \PDO::PARAM_STR);
        $stmt->bindParam(':periodo', $periodo, \PDO::PARAM_STR);
        $stmt->bindParam(':cursor', $cursor, \PDO::PARAM_STMT | \PDO::PARAM_INPUT_OUTPUT);
        //$stmt->bindParam(':cursor2', $cursor2, \PDO::PARAM_STMT | \PDO::PARAM_INPUT_OUTPUT);

        // Ejecutar la llamada al procedimiento almacenado
        $stmt->execute();
        oci_execute($cursor);
        oci_fetch_all($cursor, $data, null, null, OCI_FETCHSTATEMENT_BY_ROW);
        oci_free_statement($cursor);
        $stmt->closeCursor();
        return [
            "data" => $data,
            'rows' => count($data)
        ];
    }
}
