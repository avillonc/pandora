<template>
  <div>
    <v-card>
      <v-card-title class="my-2">
        <h4><strong>{{ isShowEntityActive ? 'Generar EA para Alumno: '+ itemSelected.last_name + ' ' + itemSelected.first_name: 'Estudiantes pendientes de generar EA'}}</strong></h4>
      </v-card-title>
      <UCToolbar v-if="isShowEntityActive"
        @on-read="createEntityOrClose"></UCToolbar>
      <v-divider v-if="!isShowEntityActive"></v-divider>
      <v-card-text v-if="!isShowEntityActive" class="my-4">
        <v-form ref="form"
          v-model="valid"
          @submit="onSubmit" 
          @submit.prevent="preSubmit">
          <v-row>
            <v-col
              cols="12"
              md="3"
            >
              <v-text-field
                label="ID"
                v-model="entityData.spriden_id"
                variant="outlined"
                density="compact"
                hide-details="auto"
              ></v-text-field>
            </v-col>
            <v-col cols="12" md="3">
                <v-select
                  label="Periodo"
                  v-model="entityData.term_code"
                  variant="outlined"
                  density="compact"
                  :items="termscode"
                  item-title="period_desc"
                  item-value="period_val"
                  :menu-props="{ offsetY: true }"
                  hide-details="auto"
                ></v-select>
            </v-col>
            <v-col cols="12" md="3">
                <v-select
                  multiple
                  label="Estado de Pago"
                  v-model="entityData.payment_status"
                  variant="outlined"
                  density="compact"
                  :items="estados"
                  item-title="text"
                  item-value="id"
                  :menu-props="{ offsetY: true }"
                  hide-details="auto"
                ></v-select>
            </v-col>
            <v-col cols="12" md="3">
                <v-select
                  label="Estado de EA"
                  v-model="entityData.ea_status"
                  variant="outlined"
                  density="compact"
                  :items="estadosEa"
                  item-title="text"
                  item-value="id"
                  :menu-props="{ offsetY: true }"
                  hide-details="auto"
                ></v-select>
            </v-col>

            <v-col
              cols="12"
              md="3"
            >
              <v-text-field
                label="SSN"
                v-model="entityData.ssn"
                variant="outlined"
                density="compact"
                hide-details="auto"
              ></v-text-field>
            </v-col>
            <v-col
              cols="12"
              md="4"
            >
              <v-text-field
                label="Apellidos"
                v-model="entityData.last_name"
                variant="outlined"
                density="compact"
                hide-details="auto"
              ></v-text-field>
            </v-col>
            <v-col
              cols="12"
              md="5"
            >
              <v-text-field
                label="Nombres"
                v-model="entityData.first_name"
                variant="outlined"
                density="compact"
                hide-details="auto"
              ></v-text-field>
            </v-col>
          </v-row>
          <v-row>
            <v-spacer></v-spacer>
                <v-col
                  cols="12"
                  md="2"
                >
                  <v-btn block color="info" @click="exportResult" variant="outlined"> 
                  <v-icon
                    left
                    dark
                    icon="mdi-file-excel"
                  >
                  </v-icon>
                  Exportar</v-btn>
                </v-col>
                <v-col
                  cols="12"
                  md="3"
                > 
                  <v-btn  block color="success" type="submit" :loading="isLoading">
                    <v-icon
                    left
                    dark
                    id="btnConsultar"
                    icon="mdi-magnify"
                  >

                  </v-icon>
                    Consultar
                  </v-btn>
                </v-col>
          </v-row>
        </v-form>
      </v-card-text>
      <UCDatatable v-if="!isShowEntityActive"
            class="mt-4"
            :key="tableKey"
            :items="items" 
            :isLoading="isLoading"
            :headers="headers"
            :itemTotal="itemTotal"
            :itemsPage="itemsPerPage"
            :page="page"
            @on-submit="onSubmit"
            @show-ea-form="showEaForm"
            @change-page="changePage"
            @item-per-page="changeItemPerPage"
      ></UCDatatable><!-- itemKey="pidm" -->

      <ea-form v-if="isShowEntityActive"
        :entityData="itemSelected">
      </ea-form>
  </v-card>

  </div>
</template>

<script>

import UCToolbar from '@/components/UCToolbarOnBack.vue';
import useAppConfig from '@core/@app-config/useAppConfig';
import { required } from '@core/utils/validation.js';
import { ref } from 'Vue';
import EaForm from './application-components/EaForm.vue';
import UCDatatable from './application-components/applicationsTable.vue';

export default {
  components: {
    UCToolbar,
    UCDatatable,
    EaForm
  },
  setup() {
    var { overlay } = useAppConfig()
    const valid = ref(false)
    const form = ref(null)
    const validate = () => {
      form.value.validate()
    }

    let entityData = ref({fechas: [], payment_status: [1], ea_status: 0,term_code: null})
    let itemSelected = ref({})
    let items = ref([])
    let termscode = ref([])
    let tableKey = 0
    let page = ref(1)
    let itemsPerPage = ref(25)
    let itemTotal = ref(0)
    let isLoading = ref(false)
    let isShowEntityActive = ref(false)
    return {
      headers: [
        { title: 'ID', key: 'spriden_id', filterable: true , width: '100', sortable: false},
        { title: 'SSN', key: 'ssn', filterable: true, width: '80', sortable: false},
        { title: 'NOMBRES', key: 'full_name', filterable: true, width: '200', sortable: false},
        { title: 'ES ALUMNO ISIL', key: 'gaston_pidm', align: ' d-none', sortable: false},
        { title: 'PERIODO', key: 'term_code', filterable: true, sortable: false},
        { title: 'FECHA DE REGISTRO', key: 'entry_date', width: '127', sortable: false},
        //{ title: 'FECHA TRANSACCIÓN', key: 'entry_date'},
        { title: 'PROGRAMA', key: 'program_title', sortable: false  },
        { title: 'NOMBRE DE PROGRAMA', key: 'program_name', align: ' d-none', sortable: false  },
        { title: 'EMAIL', key: 'email', align: ' d-none' },
        { title: 'PAGO', key: 'payment', sortable: false  },
        { title: 'ESTADO PAGO', key: 'payment_status', sortable: false },
        { title: 'ESTADO EA', key: 'ea_status', sortable: false },
        { title: '', key: 'options', sortable: false },
        
      ],
      valid,
      form,
      validate,
      estados: [{id: 0, text: 'Pendiente'}, {id: 1, text:'Pagado'}],
      estadosEa: [{id: -1, text: 'Todos'}, {id: 0, text: 'No generado'}, {id: 1, text:'Enviado'}, {id: 2, text:'Firmado'}],
      items,
      itemsPerPage,
      itemTotal,
      page,
      termscode,
      isLoading,
      overlay,
      entityData,
      validators: { required },
      menu1: false,
      itemSelected,
      isShowEntityActive,
      tableKey
    }
 },

  beforeMount(){
    this.getConfiguration()
    this.initialize()
  },
  methods: {
    loadAlert(text, type="error", title="Advertencia"){
      //this.$store.commit('appConfig/TOGGLE_SNACKBAR', {show: true, text: text, color: type})
      this.$swal.fire({
              title: title,
              text: text,
              icon: type,
              confirmButtonText: 'OK',
            })
    },
    initialize() {
      this.overlay = true
      this.$http.get('data/termcode')
          .then(response => {
            this.termscode = response.data
            this.$forceUpdate()
      })
      this.overlay = false
    },
    getConfiguration() {
        this.$http.post('data/getConfiguration', {})
        .then(response => {
            this.entityData.term_code = response.data[0].termcode
            this.$forceUpdate()
        })

    },
    changePage(page){
      this.page = page
      this.onSubmit()
    },
    changeItemPerPage(itemperpage) {
      this.itemsPerPage = itemperpage
      this.page = 1
      this.onSubmit()
    },
    preSubmit(){
      this.validate()
      this.page = 1
      this.onSubmit()
    },
    onSubmit() {
      if (!this.valid) {
        return
      }
      if(this.entityData.fechas!=null && this.entityData.fechas.length>1) {
        this.entityData.fechas = this.entityData.fechas.sort()
      }
        
        this.isLoading = true
        this.items = []

        this.entityData.itemsPerPage = this.itemsPerPage
        this.entityData.page = this.page

        this.$http.post('enrollment/getPersona', this.entityData)
        .then(response => {
            this.items = response.data.data
            //console.log(response.data)
            this.itemTotal = Number(response.data.rows)
            this.tableKey++             
            this.isLoading = false              
        })
        .catch(error => {
              this.isLoading = false
        })
    },
    showEaForm(item){
      this.itemSelected = item
      this.isShowEntityActive = true
    },
    createEntityOrClose(){
      this.itemSelected = {}
      this.isShowEntityActive = false
    },
    sendMail(item) {
      this.overlay = true
      this.$http.post('reserva/email', item)
        .then(response => {
            this.overlay = false
            this.loadAlert(response.data.msg, 'success', 'Éxito')

        })
        .catch(error => {     
              this.overlay = false
              this.loadAlert(error.response.data.message)
        })
    },
    exportResult(){
      
      window.open('/enrollment/pendientes-export/?spriden_id=' + (this.entityData.spriden_id ?? '')+
      '&term_code='+(this.entityData.term_code ?? '')+
      '&payment_status='+(this.entityData.payment_status ?? '')+
      '&ea_status='+(this.entityData.ea_status ?? '')+
      '&ssn='+(this.entityData.ssn ?? '')+
      '&last_name='+(this.entityData.last_name ?? '')+
      '&first_name='+(this.entityData.first_name ?? '')
      )
  
      /*
      alert("aa");
      if(this.items.length==0) return

      const headers = this.headers
      var arrData = []

      const replacef = function (string) {
        return Functions.replaceChar(string)
      }

      this.items.map(function (element) {
          const row = new Object ()
          headers.map(function (header) {
            if(header.value!='options') {

              const value = header.value.split('.');
              if(value.length == 1) {
                row[header.text] = element[header.value] == undefined ? '' :  element[header.value]
              } else if (value.length == 2) {
                row[header.text] = element[value[0]] == undefined ? '' :  element[value[0]][value[1]]
              } else {
                row[header.text] = ''
              }

              row[header.text] = isNaN(row[header.text]) ? replacef(row[header.text]) : row[header.text]

              if(header.value == 'payment_status') {
                const status = {
                  1: 'Pagado',
                  0: 'Pendiente',
                }
                row[header.text] = status[element[header.value]]
              }
              if(header.value == 'ea_status') {
                const eaStatus = {
                  null: 'No Generado',
                  1: 'Enviado',
                  2: 'Firmado'
                }
                row[header.text] = eaStatus[element[header.value]]
              }
              if(header.value == 'gaston_pidm') {
                //alert(element[header.value])
                row[header.text] = element[header.value] !== null ? ' SI' : ' NO'
              }
              
            } 

          })
          arrData.push(row)
      })

      Functions.downloadFileCsvEncode(arrData, 'Listado_Alumnos_EA.csv');*/
    }

  }
}
</script>
