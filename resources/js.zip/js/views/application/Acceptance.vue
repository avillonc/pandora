<template>
  <div>
    <v-card>
      <v-card-title class="my-2">
        <h4><strong>{{ isShowEntityActive ? 'Admisión de Alumno: '+itemSelected.last_name + ' ' + itemSelected.first_name : 'Admisión de Estudiantes'}}</strong></h4>
      </v-card-title>
      <UCToolbar v-if="isShowEntityActive"
        @on-read="createEntityOrClose"></UCToolbar>
      <v-divider v-if="!isShowEntityActive"></v-divider>
      <v-card-text v-if="!isShowEntityActive" class="my-4">
        <v-form ref="form"
          v-model="valid"
          @submit="onSubmit" 
          @submit.prevent="preSubmit">
          <v-row>
            <v-col cols="12" md="4">
                <v-select
                  label="Periodo"
                  v-model="entityData.term_code"
                  variant="outlined"
                  density="compact"
                  :items="termscode"
                  item-title="period_desc"
                  item-value="period_val"
                  :menu-props="{ offsetY: true }"
                  hide-details="auto"
                ></v-select>
            </v-col>
            <v-col cols="12" md="4">
                <v-select
                  multiple
                  label="Estado Admisión"
                  v-model="entityData.admission_status"
                  variant="outlined"
                  density="compact"
                  :items="estados"
                  item-title="text"
                  item-value="id"
                  :menu-props="{ offsetY: true }"
                  hide-details="auto"
                ></v-select>
            </v-col>
            <v-col
              cols="12"
              md="4"
            >
              <v-text-field
                label="ID"
                v-model="entityData.dni"
                variant="outlined"
                density="compact"
                hide-details="auto"
              ></v-text-field>
            </v-col>
            <v-col
              cols="12"
              md="4"
            >
              <v-text-field
                label="Apellidos"
                v-model="entityData.last_name"
                variant="outlined"
                density="compact"
                hide-details="auto"
              ></v-text-field>
            </v-col>
            <v-col
              cols="12"
              md="4"
            >
              <v-text-field
                label="Nombres"
                v-model="entityData.first_name"
                variant="outlined"
                density="compact"
                hide-details="auto"
              ></v-text-field>
            </v-col>

          </v-row>
          <v-row>
            <v-spacer></v-spacer>
                <!--<v-col
                  cols="12"
                  md="2"
                >
                  <v-btn block color="info" @click="exportResult" variant="outlined"> 
                  <v-icon
                    left
                    dark
                    icon="mdi-file-excel"
                  >
                  </v-icon>
                  Exportar </v-btn>
                </v-col>-->
                <v-col
                  cols="12"
                  md="3"
                > 
                  <v-btn block color="success" type="submit" id="btnConsultar">
                    <v-icon
                    left
                    dark
                    icon="mdi-magnify"
                  >
                  </v-icon>
                    Consultar
                  </v-btn>
                </v-col>
          </v-row>
        </v-form>
      </v-card-text>
      <UCDatatable v-if="!isShowEntityActive"
            class="mt-4"
            :key="tableKey"
            :items="items" 
            :isLoading="isLoading"
            :headers="headers"
            @on-submit="onSubmit"
            @show-ea-form="showEaForm"
            @regenerar-cuotas="regenerarCuotas"
            :itemTotal="itemTotal"
            :itemsPage="itemsPerPage"
            @change-page="changePage"
            @item-per-page="changeItemPerPage"    
            :page.sync="page"        
      ></UCDatatable><!-- itemKey="pidm" -->

      <ea-form v-if="isShowEntityActive"
        :entityData="itemSelected"
        @load-alert="loadAlert"
        @create="createEntityOrClose">
      </ea-form>
  </v-card>

  </div>
</template>

<script>
// eslint-disable-next-line object-curly-newline
import { ref } from 'vue'
import  UCDatatable  from './acceptance-components/AcceptanceTable.vue';
//import  UCDatatable  from './alumnos-componentes/AlumnosTabla.vue';
import UCToolbar from '@/components/UCToolbarOnBack.vue'
import  EaForm  from './acceptance-components/AcceptanceForm.vue';
import { required } from '@core/utils/validation.js'
import useAppConfig from '@core/@app-config/useAppConfig'
import {Functions} from "@core/libs/lib.js"

export default {
  components: {
    UCToolbar,
    UCDatatable,
    EaForm
  },
  setup() {
    var { overlay } = useAppConfig()
    const valid = ref(false)
    const form = ref(null)
    const validate = () => {
      form.value.validate()
    }

    let entityData = ref({fechas: [], admission_status: [0, 1], term_code: null})
    let itemSelected = ref({})
    let items = ref([])
    let termscode = ref([])
    let tableKey = 0
    let page = ref(1)
    let itemsPerPage = ref(25)
    let itemTotal = ref(0)
    let isLoading = ref(false)
    let isShowEntityActive = ref(false)

    return {
      headers: [
        //{ title: 'PIDM', key: 'pidm', filterable: true , sortable: false , width: '100'},
        { title: 'ID', key: 'spriden_id', filterable: true, sortable: false, width: '80'},
        { title: 'NOMBRES', key: 'full_name', filterable: true, sortable: false, width: '200' },
        { title: 'PERIODO', key: 'term_code', filterable: true, sortable: false},
        { title: 'FECHA EA', key: 'created_at', width: '127', sortable: false},
        { title: 'PROGRAMA', key: 'program_title', sortable: false },
        { title: 'ESTADO', key: 'admission_status', sortable: false },
        { title: '', key: 'options', sortable: false },
      ],
      valid,
      form,
      validate,
      estados: [{id: 0, text: 'Pendiente'}, {id: 1, text:'Admitido'}],
      items,
      itemsPerPage,
      itemTotal,
      page,
      termscode,
      isLoading,
      overlay,
      tableKey,
      entityData,
      validators: { required},
      menu1: false,
      itemSelected,
      isShowEntityActive,

    }
 },
  beforeMount(){
    this.getConfiguration()
    this.initialize()
  },
  methods: {
    loadAlert(text, type="error", title="Advertencia", refrescar = null){
      
      //this.$store.commit('appConfig/TOGGLE_SNACKBAR', {show: true, text: text, color: type})
      this.$swal.fire({
              title: title,
              text: text,
              icon: type,
              confirmButtonText: 'OK',
            })
      if(refrescar == 1){
        //document.getElementById("btnConsultar").click();
        this.onSubmit()
      }
    },
    initialize() {
      this.overlay = true
      this.$http.get('data/termcode')
          .then(response => {
            this.termscode = response.data
            this.$forceUpdate()
      })
      this.overlay = false
    },
    getConfiguration() {
        this.$http.post('data/getConfiguration', {})
        .then(response => {
            this.entityData.term_code = response.data[0].termcode
            this.$forceUpdate()
        })

      },
    changePage(page){
      this.page = page
      this.onSubmit()
    },
    changeItemPerPage(itemperpage) {
      this.itemsPerPage = itemperpage
      this.page = 1
      this.onSubmit()
    },
    preSubmit(){
      this.validate()
      this.page = 1
      this.onSubmit()
    },
    onSubmit() {
      if (!this.valid) {
        return
      }
      if(this.entityData.fechas!=null && this.entityData.fechas.length>1) {
        this.entityData.fechas = this.entityData.fechas.sort()
        this.$forceUpdate() 
      } 
        
        this.isLoading = true
        this.items = []

        this.entityData.itemsPerPage = this.itemsPerPage
        this.entityData.page = this.page

        this.$http.post('admission/getPersona', this.entityData)
        .then(response => {
          
          this.items = response.data.data
          this.itemTotal = Number(response.data.total) 
          this.tableKey++             
          this.isLoading = false        
                
          //this.page = response.data.current_page
            //this.$forceUpdate()
        })
        .catch(error => {
              this.isLoading = false
        })
    },
    showEaForm(item){
      this.itemSelected = item.raw
      this.isShowEntityActive = true
    },
    regenerarCuotas(item){
      this.$swal.fire({
        title: "Confirmacion",
        text: "¿desea regenerar las cuotas?",
        icon: "warning",
        confirmButtonText: 'Continuar',
        cancelButtonText: 'Cancelar',
        showCancelButton: true
      }).then((result) => {
        //console.log(item)
        if (result.isConfirmed) {
          this.overlay = true
        
          this.$http.post('admission/generar-cuotas', item.raw)
          .then(response => {
            console.log(response.data.mensaje);
            if(response.status == 200){
              this.$swal.fire({
                title: 'Listo!',
                text: response.data.mensaje,
                icon: 'success',
                confirmButtonText: 'OK',
              })
            }else{
              this.$swal.fire({
                title: 'Revisar',
                html: response.data.mensaje,
                icon: 'warning',
                confirmButtonText: 'OK',
              })
            }

            this.overlay = false
          })
          .catch(error => {
                this.isLoading = false
          })
        }
      })
    },
    
    createEntityOrClose(){
      this.itemSelected = {}
      this.isShowEntityActive = false
    },
    exportResult(){
      if(this.items.length==0) return

      const headers = this.headers
      var arrData = []

      const replacef = function (string) {
        return Functions.replaceChar(string)
      }

      this.items.map(function (element) {
          const row = new Object ()
          headers.map(function (header) {
            if(header.value!='options') {

              const value = header.value.split('.');
              if(value.length == 1) {
                row[header.text] = element[header.value] == undefined ? '' :  element[header.value]
              } else if (value.length == 2) {
                row[header.text] = element[value[0]] == undefined ? '' :  element[value[0]][value[1]]
              } else {
                row[header.text] = ''
              }

              row[header.text] = isNaN(row[header.text]) ? replacef(row[header.text]) : row[header.text]

              if(header.value == 'estado') {
                row[header.text] = element[header.value]==1 ? 'Activo' : 'Inactivo'
              }
              if(header.value == 'operativo') {
                row[header.text] = element[header.value]==1 ? 'Operativo' : 'No Operativo'
              }
              if(header.value == 'lab_virtual') {
                row[header.text] = element[header.value]==1 ? 'Habilitado' : 'No Habilitado'
              }
            } 

          })
          arrData.push(row)
      })

      Functions.downloadFileCsvEncode(arrData, 'Listado_Alumnos_EA.csv');
    }

  }
}
</script>
