
<template>
  <div>
    <v-card-text class="my-6">
      <v-row>
        <v-col
          cols="12"
          md="6"
        >
        <span>Total de Registros: {{itemTotal}}</span>
          </v-col>
        <v-spacer></v-spacer>
      </v-row>
    </v-card-text>
    <v-data-table-server
      class="mb-4"
      :headers="headers"
      :items="items"
      :loading="isLoading"
      :items-per-page="itemsPerPage"
      density="compact"
      no-data-text="No hay datos para mostrar"
      loading-text="Cargando..."
      :page="page"
      :items-length="itemTotal"
      @update:itemsPerPage="changeItemPerPage"
      @update:page="changePage"
    >
      <template #[`item.options`]="{ item }">
        <v-tooltip location="top" text="Visualizar EA" v-if="item.value.ea_status!=null">
          <template v-slot:activator="{ props }">
            <v-avatar size="28" color="primary" v-bind="props" class="mr-1">
              <a :href="'/enrollment_send/Enrollment agreement_' + item.value.term_code + '_' + item.value.program_title + '_' + item.value.first_name.trim() + '_' + item.value.last_name.trim() + '.pdf'" target="_blank">
                 <v-icon size="20" icon="mdi-file-search-outline" color="white">
                </v-icon>
              </a>
            </v-avatar>
          </template>
        </v-tooltip>

        <v-tooltip location="top" text="Generar EA" v-if="item.value.payment_status==1">
          <template v-slot:activator="{ props }">
            <v-avatar size="28" color="error" v-bind="props">
              <v-icon size="20"  
                @click="showEa(item)"
                icon="mdi-file-pdf-box"></v-icon>
            </v-avatar>
          </template>
        </v-tooltip>


        <!--<v-tooltip top color="primary">
          <template v-slot:activator="{ on, attrs }" v-if="item.value.estado_ea==1">
            <v-avatar size="28" class="v-avatar-light-bg primary--text" 
              v-bind="attrs"
              v-on="on">
                <v-icon size="20" @click="correoReserveItem(item)" color="primary">
                    {{ icons.mdiEmail  }}
                </v-icon>
            </v-avatar>
          </template>
          <span>Reenviar EA</span>
        </v-tooltip>-->
      </template>
      
      <template #[`item.full_name`]="{item}">
        <slot name="nombres">
            <span class="text-primary font-weight-medium">{{item.value.full_name}}</span>
        </slot>
      </template>

      <template #[`item.payment_status`]="{item}">
        <v-chip
          small
          density="compact"
          :color="statusColor[item.value.payment_status]"
          class="v-chip-light-bg"
        >
          {{ status[item.value.payment_status] }}
        </v-chip>
      </template>
      <template #[`item.ea_status`]="{item}">
        <v-chip
          small
          density="compact"
          :color="eaStatusColor[item.value.ea_status]"
          class="v-chip-light-bg"
        >
          {{ eaStatus[item.value.ea_status] }}
        </v-chip>
      </template>

      <template #[`item.entry_date`]="{item}">
         {{ formatDate(item.value.effective_date) }}
      </template>

      <template v-slot:loading>
        <div class="text-center py-4">
          <p>Obteniendo Data ...</p>
        </div>
      </template>

    </v-data-table-server>
    
    <!--<UCDialogQuestion
        :visible="activemsgConfirm"
        :message="msgConfirm"
        title="Confirmación"
        @cancel="closemsgConfirm"
        @ok="generarEa"
    ></UCDialogQuestion>-->
  </div>
</template>

<script>
import { ref } from 'vue'
import {Functions} from "@core/libs/lib.js"
//import UCDialogQuestion from '@/components/UCDialogQuestion.vue'
import useAppConfig from '@core/@app-config/useAppConfig'
import { required, requiredObject } from '@core/utils/validation.js'

export default {
  components: {
   // UCDialogQuestion
  },
  props: {
    items: {
      type: Array,
      default: []
    },
    isLoading: {
      type: Boolean,
      default: false,
    },
    headers: {
      type: Array,
      required: true
    },
    sortBy: {
      type: String,
      default: "id"
    },
    showSelect: {
      type: Boolean,
      default: false
    },
    nameAction: {
      type: String,
      default: 'Guardar'
    },
    itemKey: {
      type: String,
      default: 'id'
    },
    search: {
      type: String,
      default: ''
    },
    itemTotal: {
      type: Number,
      default: null
    },
    itemsPage: {
      type: Number,
      default: 25
    },
    page: {
      type: Number,
      default: 1
    }
  },
  setup(props) {
    const statusColor = {
      1: 'success',
      0: 'error',
    }
    const status = {
      1: 'Pagado',
      0: 'Pendiente',
    }

    const eaStatusColor = {
      null: 'error',
      1: 'success',
      2: 'Firmado'
      
    }
    const eaStatus = {
      null: 'No Generado',
      1: 'Enviado',
      2: 'Firmado'
    }

    var { overlay } = useAppConfig()

    const entityData = ref({})

    let valueSelected = ref([])

    let page = ref(props.page)
    let itemsPerPage = ref(props.itemsPage)

    return {
      page,
      itemsPerPage,
      status,
      statusColor,
      eaStatus,
      eaStatusColor,
      valueSelected,
      msgConfirm: '',
      activemsgConfirm: false,
      msgConfirmReenvio: '',
      overlay,
      validators: { required, requiredObject},
      entityData,
    }
  },
  methods: {
    loadAlert(text, type="error", title="Advertencia"){
      this.$swal.fire({
              title: title,
              text: text,
              icon: type,
              confirmButtonText: 'OK',
            })
    },
    formatDate(created_at) {
        return this.$moment(created_at).format('DD/MM/YYYY');
    },
    formatDateTime(fecha) {
      if(fecha==null) return ''
      return this.$moment(fecha).format('DD/MM/YYYY HH:mm');
    },
    changePage(value){
      this.entityData = {}
      this.$emit('change-page', value)
    },
    changeItemPerPage(item){
      this.entityData = {}
      this.$emit('item-per-page', item)
    },
    select(select){
      if(select.value) {

          var pidm = null
          if(select.item != undefined) {
            pidm = select.item.value.pidm
          } else {
            if(select.currentItem != undefined)  pidm = select.currentitem.value.pidm
          }
          
          if(pidm != null) {
            var index = this.valueSelected.indexOf(pidm);
            if (index == -1) {
              this.valueSelected.push(pidm)
            }
          }
          
      } else {
 
          var pidm = null
          if(select.item != undefined) {
            pidm = select.item.value.pidm
          } else {
            if(select.currentItem != undefined)  pidm = select.currentitem.value.pidm
          }
          
          if(pidm != null) {
            var index = this.valueSelected.indexOf(select.item.value.pidm);
            if (index > -1) {
                this.valueSelected.splice(index, 1);
            }
          }

      }
      this.$forceUpdate()
    },
    selectAll(select){
      select.items.map((item) => {
          const index = this.valueSelected.indexOf(item.value.pidm);
          if (index > -1) {
              if(!select.value) {
                this.valueSelected.splice(index, 1);
              }
          } else {
            if(select.value) {
              this.valueSelected.push(item.value.pidm)
            }
          }
      })
      this.$forceUpdate()
    },
    /*showMessageConfirm(){
      if (this.valid) {
        this.msgConfirm = "Seguro de generar y enviar EA para el alumno: "+ this.entityData.full_name

        this.activemsgConfirm= true
      }
    },
    closemsgConfirm(){
      this.activemsgConfirm = false
    },
    generarEa(){
      this.$http.post('enrollment/generar-ea', this.entityData)
            .then(response => {
                //alert("ss");
                //this.$emit('create', response.data)
                //this.$emit('load-alert', 'Enrollment agreement registrado correctamente', 'success', 'Éxito')
                this.loadAlert('Enrollment agreement registrado correctamente', 'success', 'Éxito')
                this.activemsgConfirm= false
            })
            .catch(error => {     
                  this.overlay = false
                  this.$emit('load-alert', error.response.data.message)
            })
    },*/
    showEa(item){
      //this.entityData = item
      //this.isDialogOpen = true
      this.$emit('show-ea-form',item.value)
    },
    closeDialog(){
      this.isDialogOpen = false
      this.entityData = {}
      this.resetValidation()
    }

  }
}
</script>