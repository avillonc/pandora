<template>
  <div>
  <v-card-text class="mt-5">
        <v-form ref="form"
          v-model="valid"
          @submit="showMessageConfirm" 
          @submit.prevent="validate">
          <v-row>
            <v-col cols="12" md="3" >
              <v-text-field
                label="PIDM"
                name="pidm"
                id="pidm"
                v-model="entityData.spriden_pidm"
                readonly
                variant="filled"
                density="compact"
                hide-details="auto"
              ></v-text-field>
            </v-col>
            <v-col cols="12" md="3">
              <v-text-field
                label="First name"
                v-model="entityData.first_name"
                readonly
                variant="filled"
                density="compact"
                hide-details="auto"
              ></v-text-field>
            </v-col> 
            <v-col cols="12" md="3" >
              <v-text-field
                label="Last name"
                v-model="entityData.last_name"
                readonly
                variant="filled"
                density="compact"
                hide-details="auto"
              ></v-text-field>
            </v-col>
            <v-col cols="12" md="3" >
              <v-text-field
                label="E-mail"
                v-model="entityData.email"
                readonly
                variant="filled"
                density="compact"
                hide-details="auto"
                :rules="[validators.required]"
              ></v-text-field>
            </v-col>
          </v-row>
          <v-row>
            <v-col cols="12"  md="6">
              <v-text-field
                label="Address"
                v-model="entityData.address"
                readonly
                variant="filled"
                density="compact"
                hide-details="auto"
              ></v-text-field>
            </v-col>
            <v-col cols="12"  md="3">
              <v-text-field
                label="Telephone: (Home)"
                v-model="entityData.telcasa"
                readonly
                variant="filled"
                density="compact"
                hide-details="auto"
              ></v-text-field>
            </v-col>
            <v-col cols="12" md="3">
              <v-text-field
                label="Business or Cellular"
                v-model="entityData.cell_phone"
                readonly
                variant="filled"
                density="compact"
                hide-details="auto"               
              ></v-text-field>
            </v-col>
          </v-row>
          <v-row>
            <v-col cols="12" md="3">
              <v-text-field
                  label="Social security number"
                  v-model="entityData.ssn"
                  readonly
                  variant="filled"
                  density="compact"
                  hide-details="auto"
                ></v-text-field>
            </v-col>
            <v-col cols="12" md="3">
                <v-text-field
                    label="Date of birth"
                    v-model="entityData.birth_date"
                    type="date"
                    readonly
                    variant="filled"
                    density="compact"
                    hide-details="auto"
                  ></v-text-field>
              </v-col>
              <v-col cols="12"  md="3" >
                  <v-text-field
                    label="Parent/Guardian: Last Name"
                    v-model="entityData.parent_lastname"
                    density="compact"
                    readonly
                    variant="filled"
                    hint="If student is under 18"
                    persistent-hint
                  ></v-text-field>
              </v-col> 
              <v-col cols="12"  md="3" >
                <v-text-field
                  label="Parent/Guardian: First Name"
                  v-model="entityData.parent_firstname"
                  density="compact"
                  readonly
                  variant="filled"
                  hint="If student is under 18"
                  persistent-hint
                ></v-text-field>
              </v-col>
          </v-row>
          <v-row>
            <v-col cols="12"> <v-divider></v-divider></v-col>
          </v-row> 

          <v-row class="pb-0">
            <v-col cols="12" md="8" class="pb-0">
              <h4 class="mb-2">Program Information: </h4>
              <v-radio-group
                    class="pb-0 "
                    v-model="entityData.program_title"
                    column
                    readonly
                    name="rbProgram"
                    density="compact"
                    :rules="[validators.required]"
                  >
                    <v-radio
                      v-for="n in programs"
                      :key="n.id"
                      :label="n.program_name"
                      color="primary"
                      :credit_hours="n.credit_hours"
                      :value="n.majr_code"
                      class="text-sm"
                      :disabled="entityData.program_title!=n.majr_code"
                    >
                    <template v-slot:label>
                     {{ n.program_name }} &nbsp;<i class="text-body-2">credit hours: <strong class="text-primary">  {{n.credit_hours}}</strong></i>
                    </template>
                  </v-radio>
              </v-radio-group>
            </v-col>
            <v-col cols="12" md="2" class="pb-0">
              <h4 class="mb-2">Program Modality: </h4>
                <v-radio-group v-model="entityData.modality" :rules="[validators.required]">
                  <v-radio label="Online" value="1" key="1"></v-radio>
                  <v-radio label="In Classroom" value="2" key="2"></v-radio>
                </v-radio-group>
            </v-col>

            <v-col cols="12" md="2">
              <h4 class="mb-2">Language: </h4>
                <v-radio-group  v-model="entityData.language"  :rules="[validators.required]" >
                  <v-radio label="English" value="E" ></v-radio>
                  <v-radio label="Spanish" value="S" ></v-radio>
                </v-radio-group>
            </v-col>
          </v-row>
        <v-row >
          <v-col cols="12" class="pb-1">
          <h4 >Class Schedule: </h4>
        </v-col>
        </v-row>
        <v-row class="pt-1">
          <v-col cols="12" md="2">
                <v-checkbox
                  v-model="entityData.cla_sch" 
                  label="Full time"
                  value="1"
                  id="chkSch_1"
                  :rules="[validators.sch_required(entityData.cla_sch)]"
                ></v-checkbox>
          </v-col>
          <v-col cols="12" md="2">
                <v-checkbox
                  v-model="entityData.cla_sch"
                  label="Part time"
                  value="2"
                  id="chkSch_2"    
                  :rules="[validators.sch_required(entityData.cla_sch)]"            
                ></v-checkbox>
          </v-col>
          <v-col cols="12" md="2">
                <v-checkbox
                  v-model="entityData.cla_sch"
                  label="Day classes"
                  value="3"
                  id="chkSch_3"
                  :rules="[validators.sch_required(entityData.cla_sch)]"
                ></v-checkbox>
          </v-col>
          <v-col cols="12" md="2">
                <v-checkbox
                  v-model="entityData.cla_sch"                
                  label="Evening classes"
                  value="4"
                  id="chkSch_4"
                  :rules="[validators.sch_required(entityData.cla_sch)]"
                ></v-checkbox>
          </v-col>
          <v-spacer></v-spacer>
        </v-row>
          
          <v-row>
            <v-col cols="12" md="3">
              <v-text-field
                  label="Total of credits to be taken"
                  v-model="entityData.total_credits"
                  variant="filled"
                  readonly
                  density="compact"
                  hide-details="auto"                  
                ></v-text-field>
            </v-col>
            <v-col cols="12" md="3">
              <v-text-field
                  label="Price Credit"
                  v-model="entityData.price_credit"
                  min="0"
                step=".1"
                type="number"
                  readonly
                  variant="filled"
                  density="compact"
                  hide-details="auto"
                  :rules="[validators.required]"
                ></v-text-field>
            </v-col>
            <v-col cols="12" md="3">
              <v-text-field 
                  label="Start Date"
                  v-model="entityData.sta_dat"
                  readonly
                  variant="filled"
                  density="compact"
                  type="date"
                  hide-details="auto"
                  :rules="[validators.required]"
                ></v-text-field>
            </v-col>
            <v-col cols="12" md="3">
              <v-text-field
                  label="Anticipated Ending Date"
                  v-model="entityData.ant_end_dat"
                  type="date"
                  readonly
                  variant="filled"
                  density="compact"
                  hide-details="auto"
                  :rules="[validators.required]"
                ></v-text-field>
            </v-col>
          </v-row>
          <v-row>
            <v-col cols="12">
              <h4 >Costs: </h4>
            </v-col>
          </v-row>
          
          <v-row>
            <v-col cols="12" md="3">
              <v-text-field
                  label="Tuition"
                  v-model="entityData.tuition"
                  density="compact"
                  readonly
                  variant="filled"
                  min="1"
                  type="number"
                  hide-details="auto"
                  :rules="[validators.minNumber(entityData.tuition, 10)]"
                ></v-text-field>                   
            </v-col>
            <v-col cols="12" md="3">
              <v-text-field
                  label="Registration Fee"
                  v-model="entityData.payment"
                  variant="outlined"
                  v-on:keyup="calcularCuotasPagos"
                  density="compact"
                  type="number"
                  hide-details="auto"
                ></v-text-field>
            </v-col>
            <v-col cols="12" md="3">
              <v-text-field
                  label="Books & Supplies"
                  v-model="entityData.books_supplies"
                  variant="outlined"
                  density="compact"
                  min="0"
                  type="number"
                  hide-details="auto"
                  v-on:keyup="calcularCuotasPagos"
                ></v-text-field>
            </v-col>
            <v-col cols="12" md="3">
              <v-text-field
                  label="Other Costs and Fees"
                  v-model="entityData.other_costs_fees"
                  variant="outlined"
                  density="compact"
                  min="0"
                  type="number"
                  hide-details="auto"
                  v-on:keyup="calcularCuotasPagos"
                ></v-text-field>
            </v-col>
            <v-col cols="12" md="3">
              <v-text-field
                  label="Convalidated credits"
                  v-model="entityData.creditos_convalidados"
                  variant="outlined"
                  v-on:keyup="calcularTuition"
                  density="compact"
                  type="number"
                  hide-details="auto"
                ></v-text-field>
            </v-col>
            <v-col cols="12" md="3">
              <v-text-field
                  label="Total Program Price"
                  v-model="entityData.total_program_price"
                  density="compact"
                  readonly
                  id="totPp"
                  variant="filled"
                  type="number"
                  hide-details="auto"
                ></v-text-field>
            </v-col>
          </v-row>
          <!-- <v-row>
            <v-col cols="12"> <v-divider></v-divider></v-col>
          </v-row> -->  
          <v-row>
            <v-col
              cols="12"
              sm="12"
              md="12"
            >
            <div class="text-sm">
            <!--<h4>Payment methods: </h4>-->
            <v-select
                  label="Payment methods"
                  v-model="entityData.payment_method"
                  variant="outlined"
                  density="compact"
                  :items="methods"
                  item-title="descripcion"
                  item-value="id"
                  :rules="[validators.requiredObject]"
                  :menu-props="{ offsetY: true }"
                  hide-details="auto"
                  @update:modelValue="changeVal"
                  single-line
                ></v-select>
            </div>
            </v-col>
          </v-row>  
          
          <v-row>
            <v-spacer></v-spacer>
            <v-col cols="12" md="3">
              <v-btn  block color="primary" type="button" @click="vistaPrevia">
                  <v-icon
                            left
                            dark
                            icon="mdi-refresh"
                          >
                          </v-icon>
                  {{ entityData.status == 1 ? 'Refrescar vista previa' : 'Ver vista previa' }}
                </v-btn>
            </v-col>
            <v-col cols="12" md="3">
              <v-btn  block color="success" type="submit">
                <v-icon
                  left
                  dark
                  icon="mdi-content-save"
                >
                </v-icon>
                Generar EA
              </v-btn>
            </v-col>
          </v-row>

          <v-row>
            <v-col cols="12" md="12">
              <h3>VISTA PREVIA </h3>
              </v-col>
              <v-divider></v-divider>
          </v-row>
          <v-row>
            <v-col cols="12" md="12">
              <iframe id="frameEa" src="/enrollment/to-pdf" frameborder="1" style="width: 100%; height: 450vh;"></iframe>
            </v-col>
          </v-row>
          
        </v-form>
  </v-card-text>

  <UCDialogQuestion
        :visible="activemsgConfirm"
        :message="msgConfirm"
        title="Confirmación"
        @cancel="closemsgConfirm"
        @ok="onSubmit"
  ></UCDialogQuestion>

  </div>
</template>

<script>
import UCDialogQuestion from '@/components/UCDialogQuestion.vue'
import useAppConfig from '@core/@app-config/useAppConfig'
import { getFieldDb, isEmpty } from '@core/utils/index'
import { alphaDasNameValidator, maxlengthValidator, minNumber, required, requiredObject, sch_required } from '@core/utils/validation.js'
import { ref } from 'Vue'

export default {
  components: {
    UCDialogQuestion
  },
  props: {
    entityData: {
      type: Object,
      required: true,
    },
    
  },
  setup() {
    const valid = ref(false)
    const form = ref(null)
    const validate = () => {
      form.value.validate()
    }

    var { overlay } = useAppConfig()

    const enabled = {
      2: 'Inactivo',
      1: 'Activo',
    }

    let programs = ref([])
    let methods = ref([])
    let activemsgConfirm = ref(false)

    return {
      valid,
      form,
      validate,
      validators: { 
        required, 
        alphaDasNameValidator, 
        requiredObject, 
        maxlengthValidator, 
        minNumber, 
        sch_required},
      getFieldDb,
      isEmpty,
      programs,
      methods,
      cuotas_quin: 0,
      cuotas_men: 0,
      monto_quin: 0,
      monto_men: 0,
      cuotas_men_isil: 0,
      cuotas_quin_isil: 0,
      cuotas_men_lbl: 0,
      cuotas_quin_lbl: 0,
      overlay,
      enabled,
      checked: false,
      msgConfirm: '',
      activemsgConfirm,
    }
  },
  beforeMount(){
    this.cuotas = 1
    this.entityData.modality = "1"
    this.entityData.program_id = ""
    this.entityData.cla_sch = []
    
    this.entityData.beginning_on = "2023-09-05"
    this.entityData.books_supplies = 0
    this.entityData.other_costs_fees = 0
    if(this.entityData.flag_administrativo == 'H2'){
      this.entityData.es_administrativo = "2"
    }else{
      this.entityData.es_administrativo = "1"
    }
    this.entityData.first_name = this.entityData.first_name.trim() ?? ''
    this.entityData.last_name = this.entityData.last_name.trim() ?? ''
    //this.entityData.payment_method = ''
    /*if(this.entityData.language == 'E'){
      this.entityData.language = null
    }*/
    //console.log(this.entityData.sta_dat)
    this.initialize()
  },
  /*computed: {
    validateCheckbox () {
      return [this.selectedValues.length > 0 || "Eligeme ..."]
    }
  },*/
  
  methods: {
    initialize() {
      
      this.overlay = true
      var data = {
        lang: this.entityData.language
      }
      
      this.$http.post('enrollment/programs', data)
        .then(response => {
            this.programs = response.data
            this.$forceUpdate()
        })
      this.$http.post('enrollment/payment-methods')
        .then(response => {
          var _methods = [{id: '', descripcion: 'Choose...'}]
          response.data.forEach(async (item) => {
            _methods.push(item);
          });
          this.methods = _methods
          this.$forceUpdate()
      })
      data = {
        pidm: this.entityData.spriden_pidm,
        majr_code: this.entityData.program_title,
        term_code: this.entityData.term_code,
        es_administrativo: this.entityData.es_administrativo,
      }
      this.$http.post('enrollment/otros-datos', data)
        .then(response => {
          //console.log(response.data)
            this.entityData.total_credits = response.data.credit_hours 
            this.entityData.program_id = response.data.program_id 
            this.entityData.sta_dat = response.data.periodo_start
            this.entityData.ant_end_dat = response.data.periodo_end
            this.entityData.beginning_on = response.data.periodo_start
            
            //total cuotas
            this.cuotas_men = response.data.total_meses;
            this.cuotas_quin = response.data.total_quincenas;
           
            this.cuotas_men_isil = response.data.total_meses_isil;
            this.cuotas_quin_isil = response.data.total_quincenas_isil;
            //mas datos de estudiante
            this.entityData.email = response.data.email;
            this.entityData.address = response.data.address;
            this.entityData.cell_phone = response.data.cell_phone;
            
            this.calcularTuition();
            this.$forceUpdate()
            this.overlay = false
        })
        window.scrollTo({ top: 0, behavior: 'smooth' });
        
        this.$forceUpdate()

    },
    calcularTuition(){
      if(this.entityData.price_credit == 0){
        this.loadAlert('No tiene categoría registrada o precio registrado para esta carrera');
        this.entityData.tuition = 0;
      }else{
        this.entityData.tuition = ((this.entityData.total_credits - this.entityData.creditos_convalidados) * this.entityData.price_credit).toFixed(2);
        this.calcularCuotasPagos()
      }  
    },
    calcularCuotasPagos(){
      if(this.entityData.books_supplies == ''){
        this.entityData.books_supplies = 0
      }
      if(this.entityData.other_costs_fees == ''){
        this.entityData.other_costs_fees = 0
      }
      this.entityData.total_program_price = parseFloat(this.entityData.tuition) + parseFloat(this.entityData.books_supplies) + parseFloat(this.entityData.other_costs_fees)
      this.entityData.total_program_price = this.entityData.total_program_price.toFixed(2)
      
      var mensual = 0;
      var quincenal = 0;

      if(this.entityData.es_administrativo == '1'){
        mensual = this.entityData.total_program_price / this.cuotas_men;
        quincenal = this.entityData.total_program_price / this.cuotas_quin;

        this.cuotas_men_lbl = this.cuotas_men;
        this.cuotas_quin_lbl = this.cuotas_quin;

        mensual = this.entityData.total_program_price / this.cuotas_men;
        quincenal = this.entityData.total_program_price / this.cuotas_quin;

      }else{
        mensual = this.entityData.total_program_price / this.cuotas_men_isil;
        quincenal = this.entityData.total_program_price / this.cuotas_quin_isil;

        this.cuotas_men_lbl = this.cuotas_men_isil;
        this.cuotas_quin_lbl = this.cuotas_quin_isil;
        //this.cuotas_men = this.cuotas_men_isil;
        //this.cuotas_quin = this.cuotas_quin_isil;
        mensual = this.entityData.total_program_price / this.cuotas_men_isil;
        quincenal = this.entityData.total_program_price / this.cuotas_quin_isil;
      } 
      
      this.monto_quin = quincenal.toFixed(2);
      this.monto_men = mensual.toFixed(2);

      document.querySelector("#totPp").value = this.entityData.total_program_price
      this.cambiaCuota();

    },
    cambiaCuota(e){
      //console.log(this.entityData.cuotas)
      this.entityData.weekly = this.entityData.cuotas
      
      this.entityData.num_payments1 = 0
      this.entityData.amount_each_pay1 = 0
      
    },
    regresar(){
      this.$emit('on-backward')
    },
    loadAlert(text, type="error", title="Advertencia"){
      //this.$store.commit('appConfig/TOGGLE_SNACKBAR', {show: true, text: text, color: type})
      this.$swal.fire({
              title: title,
              text: text,
              icon: type,
              confirmButtonText: 'OK',
            }).then((result) => {
              if (result.isConfirmed) {
                //document.querySelectorAll("#btnRegresar").forEach(el=>el.click())
                //document.querySelectorAll("#btnConsultar").forEach(el=>el.click())
                
              }
            })
    },
    showMessageConfirm(){
      if (this.valid) {
        this.msgConfirm = "Seguro de generar y enviar EA para el estudiante: "+ this.entityData.full_name
        this.activemsgConfirm= true
      }
    },
    closemsgConfirm(){
      this.activemsgConfirm = false
    },
    onSubmit(){
      this.closemsgConfirm()
      console.log(this.valid)
        if (this.valid) {
          this.overlay = true
          this.$http.post('enrollment/generar-ea', this.entityData)
              .then(response => {
                  window.scrollTo({ top: 0, behavior: 'smooth' });
                  this.overlay = false
                  this.$forceUpdate();
                  this.loadAlert(response.data.mensaje, 'success', 'Éxito')
                
              }).catch(function(err){
                  if(err.response.status == 422) {                  
                    this.loadAlert('Elegir al menos un program schedule');
                    this.overlay = false
                  
                    this.$forceUpdate();
                }
            });
              /*.catch(error => {     
                    this.overlay = false
                    this.$emit('load-alert', error.response.data.message)
            }) */      
        } else {
          this.validate()
          this.loadAlert('Tiene campos incompletos');
          let elementsInErrors = document.getElementsByClassName('error--text');
            if (elementsInErrors && elementsInErrors.length > 0) {
              elementsInErrors[0].scrollIntoView({ behavior: 'smooth', block: 'center' });
          }
        }
    },
    changeVal(){
      this.validate()
    },
    vistaPrevia(){
      this.validate()
        if (this.valid) { 
          this.overlay = true
          this.$http.post('enrollment/guardar-pdf', this.entityData)
            .then(response => {
              document.getElementById('frameEa').src = '/enrollment_send/Enrollment agreement_' + this.entityData.term_code + '_' + this.entityData.program_title + '_' + this.entityData.first_name.trim() + '_' + this. entityData.last_name.trim() + '.pdf';
                this.overlay = false
  
            })
            .catch(error => {     
                  this.overlay = false
                  this.$emit('load-alert', error.response.data.message)
            }) 
        } else {
          this.validate()
          this.loadAlert('Tiene campos incompletos');
          let elementsInErrors = document.getElementsByClassName('error--text');
          if (elementsInErrors && elementsInErrors.length > 0) {
              elementsInErrors[0].scrollIntoView({ behavior: 'smooth', block: 'center' });
          }
        }
    }
  }
}
</script>
