
<template>
  <div>
    <v-card-text class="my-6">
      <v-row>
        <v-col
          cols="12"
          md="6"
        >
        <span>Total de Registros: {{items.length}}</span>
          </v-col>
        <v-spacer></v-spacer>
      </v-row>
    </v-card-text>
    <v-data-table
      class="mb-4"
      :headers="headers"
      :items="items"
      :loading="isLoading"
      :items-per-page="itemsPerPage"
      density="compact"
      no-data-text="No hay datos para mostrar"
      loading-text="Cargando..."
      :page="page"
      :items-length="itemTotal"
      @item-selected="select"
      @update:itemsPerPage="changeItemPerPage"
      @update:page="changePage"
    >
      <template #[`item.options`]="{ item }">
        <v-tooltip location="top" text="Ver Admisión" >
          <template v-slot:activator="{ props }">
            <v-avatar size="28" color="primary" v-bind="props" class="mr-2">
              <v-icon size="20"  
                @click="showAdmission(item)"
                icon="mdi-eye-outline"></v-icon>
            </v-avatar>
          </template>
        </v-tooltip>

        <v-tooltip location="top" text="Regenerar Cuotas">
          <template v-slot:activator="{ props }">
            <v-avatar size="28" color="success" v-bind="props">
              <v-icon size="20"  
                @click="regenerarCuotas(item)"
                icon="mdi-reload"></v-icon>
            </v-avatar>
          </template>
        </v-tooltip>

      </template>
      
      <template #[`item.full_name`]="{item}">
        <slot name="nombres">
            <span class="text-primary">{{item.raw.full_name}}</span>
        </slot>
      </template>

      <template #[`item.admission_status`]="{item}">
        <v-chip
          density="compact"
          small
          :color="statusColor[item.raw.admission_status]"
          class="v-chip-light-bg"
        >
          {{ status[item.raw.admission_status] }}
        </v-chip>
      </template>

      <template #[`item.created_at`]="{item}">
         {{ formatDate(item.raw.created_at) }}
      </template>

      <template #[`item.entry_date`]="{item}">
         {{ formatDateTime(item.raw.entry_date) }}
      </template>

    </v-data-table>
    <!--<UCDialogQuestion
        :visible="activemsgConfirm"
        :message="msgConfirm"
        title="Confirmación"
        @cancel="closemsgConfirm"
        @ok="generarEa"
    ></UCDialogQuestion>-->
  </div>
</template>

<script>
import { ref } from 'vue'
import {Functions} from "@core/libs/lib.js"
import UCDialogQuestion from '@/components/UCDialogQuestion.vue'
import useAppConfig from '@core/@app-config/useAppConfig'
import { required, requiredObject } from '@core/utils/validation.js'

export default {
  components: {
    UCDialogQuestion
  },
  props: {
    items: {
      type: Array,
      default: []
    },
    isLoading: {
      type: Boolean,
      default: false,
    },
    headers: {
      type: Array,
      required: true
    },
    sortBy: {
      type: String,
      default: "id"
    },
    showSelect: {
      type: Boolean,
      default: false
    },
    nameAction: {
      type: String,
      default: 'Guardar'
    },
    itemKey: {
      type: String,
      default: 'id'
    },
    search: {
      type: String,
      default: ''
    },
    itemTotal: {
      type: Number,
      default: null
    },
    itemsPage: {
      type: Number,
      default: 25
    },
    page: {
      type: Number,
      default: 1
    }
  },
  setup(props) {
    const statusColor = {
      1: 'success',
      0: 'error',
    }
    const status = {
      1: 'Admitido',
      0: 'Pendiente',
    }

    var { overlay } = useAppConfig()

    const valid = ref(false)
    const form = ref(null)
    const validate = () => {
      form.value.validate()
    }

    const resetValidation = ()=> {
      form.value.resetValidation()
    }

    const entityData = ref({})

    let valueSelected = ref([])
    let page = ref(props.page)
    let itemsPerPage = ref(props.itemsPage)

    return {
      page,
      itemsPerPage,
      status,
      statusColor,
      icons: {
        mdiEyeOutline: null,
        mdiReload: null
      },
      valueSelected,
      msgConfirm: '',
      activemsgConfirm: false,
      msgConfirmReenvio: '',
      overlay,
      valid,
      form,
      validate,
      resetValidation,
      isDialogOpen: false,
      validators: { required, requiredObject},
      entityData,
    }
  },
  watch: {
    page(value) {
      console.log('value:' +value)
      this.$emit('change-page', this.page)
      console.log('pagesss:'+ this.page)
      console.log('pagecount:'+ this.pageCount)
    },
  },
  methods: {
    loadAlert(text, type="error", title="Advertencia"){
      this.$swal.fire({
              title: title,
              text: text,
              icon: type,
              confirmButtonText: 'OK',
            })
    },
    formatDate(created_at) {
        return this.$moment(created_at).format('DD/MM/YYYY');
    },
    formatDateTime(fecha) {
      if(fecha==null) return ''
      return this.$moment(fecha).format('DD/MM/YYYY HH:mm');
    },
    changePage(value){
      this.entityData = {}
      this.$emit('change-page', value)
    },
    changeItemPerPage(item){
      this.entityData = {}
      this.$emit('item-per-page', item)
    },

    select(select){
      console.log(select)
      if(select.value) {

          var pidm = null
          if(select.item != undefined) {
            pidm = select.item.pidm
          } else {
            if(select.currentItem != undefined)  pidm = select.currentItem.pidm
          }
          
          if(pidm != null) {
            var index = this.valueSelected.indexOf(pidm);
            if (index == -1) {
              this.valueSelected.push(pidm)
            }
          }
          
      } else {
 
          var pidm = null
          if(select.item != undefined) {
            pidm = select.item.pidm
          } else {
            if(select.currentItem != undefined)  pidm = select.currentItem.pidm
          }
          
          if(pidm != null) {
            var index = this.valueSelected.indexOf(select.item.pidm);
            if (index > -1) {
                this.valueSelected.splice(index, 1);
            }
          }

      }
      this.$forceUpdate()
    },
    selectAll(select){
      select.items.map((item) => {
          const index = this.valueSelected.indexOf(item.pidm);
          if (index > -1) {
              if(!select.value) {
                this.valueSelected.splice(index, 1);
              }
          } else {
            if(select.value) {
              this.valueSelected.push(item.pidm)
            }
          }
      })
      this.$forceUpdate()
    },
    showMessageConfirm(){
      if (this.valid) {
        this.msgConfirm = "Seguro de generar y enviar EA para el alumno: "+ this.entityData.full_name

        this.activemsgConfirm= true
      }
    },
    closemsgConfirm(){
      this.activemsgConfirm = false
    },
    generarEa(){

    },

    regenerarCuotas(item){
      //this.entityData = item
      //this.isDialogOpen = true
      this.$emit('regenerar-cuotas',item)
    },

    showAdmission(item){
      //this.entityData = item
      //this.isDialogOpen = true
      this.$emit('show-ea-form',item)
    },
    closeDialog(){
      this.isDialogOpen = false
      this.entityData = {}
      this.resetValidation()
    },
    cancelar(){

    }
  }
}
</script>