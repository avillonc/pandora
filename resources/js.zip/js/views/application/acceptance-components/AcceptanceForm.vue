  <template>
  <div>
    <v-card-text class="mt-5">
          <v-form ref="form"
            v-model="valid"
            id="formSend"
            @submit="showMessageConfirm" 
            @submit.prevent="validate">
            <v-row>
              <v-col
                  cols="3"
                >
                  <v-text-field
                    label="PIDM"
                    v-model="entityData.pidm"
                    variant="filled"
                    readonly
                    density="compact"
                    hide-details="auto"
                  ></v-text-field>
                </v-col>
                <v-col
                  cols="3" 
                >
                  <v-text-field
                    label="Nombres"
                    v-model="entityData.first_name"
                    readonly
                    variant="filled"
                    density="compact"
                    hide-details="auto"
                  ></v-text-field>
                </v-col> 
                <v-col
                  cols="3"
                >
                  <v-text-field
                    label="Apellidos"
                    v-model="entityData.last_name"
                    readonly
                    variant="filled"
                    density="compact"
                    hide-details="auto"
                  ></v-text-field>
                </v-col>
              <v-col cols="3">
                <v-text-field
                    label="ID"
                    v-model="entityData.ssn"
                    placeholder="ID"
                    readonly
                    variant="filled"
                    density="compact"
                    hide-details="auto"
                  ></v-text-field>
                </v-col>
                <v-col cols="3">
                <v-text-field
                    label="Periodo"
                    v-model="entityData.term_code"
                    readonly
                    variant="filled"
                    density="compact"
                    hide-details="auto"
                  ></v-text-field>
                </v-col>
                <v-col cols="3">
                <v-text-field
                    label="Código"
                    v-model="entityData.program_title"
                    readonly
                    variant="filled"
                    density="compact"
                    hide-details="auto"
                  ></v-text-field>
                </v-col>
                <v-col cols="6">
                <v-text-field
                    label="Programa"
                    v-model="entityData.program_name"
                    readonly
                    variant="filled"
                    density="compact"
                    hide-details="auto"
                  ></v-text-field>
                </v-col>
            </v-row>
            <v-row>
              <v-col cols="3">
                <v-text-field
                    label="Email"
                    v-model="entityData.email"
                    readonly
                    variant="filled"
                    density="compact"
                    hide-details="auto"
                  ></v-text-field>
                </v-col>
              <v-col cols="3" v-if="entityData.admission_status==0" >
                  <v-file-input
                    v-model="files"
                    name="file"
                    label="Adjuntar Enrollment Agreement"
                    ref="fileEa"
                    prepend-inner-icon="mdi-paperclip"
                    :prepend-icon="null"
                    id="fileEA"
                    density="compact"
                    @update:modelValue="uploadFiles"
                    :rules="[validators.required]"
                    show-size
                  ></v-file-input>
              </v-col>
              <v-col cols="6">
                  <a :href="entityData.url_file" target="_blank">
                    {{entityData.file}}
                  </a>
              </v-col>
            </v-row>
            <v-row>
              
              <v-col
                offset-md="9"
                cols="12"
                md="3"
              >

                <v-btn v-if="entityData.admission_status==0" block color="success" type="submit">
                  <v-icon
                            left
                            dark
                            icon="mdi-check-outline"
                          >
                          </v-icon>
                  Admitir
                </v-btn>
              </v-col>
              
            </v-row>
            <v-row v-if="entityData.admission_status!=0">
              <v-col
                  cols="12"
                >
                <h4 class="mb-2">CUOTAS GENERADAS </h4>
                <v-table >
                        <thead>
                          <tr>
                            <th class="text-center">
                              CÓDIGO
                            </th>
                            <th class="text-center">
                              N° TRANSACCIÓN
                            </th>
                            <th class="text-center">
                              FECHA EMISIÓN
                            </th>
                            <th class="text-center">
                              FECHA VENCIMIENTO
                            </th>
                            <th class="text-center">
                              MONTO
                            </th>
                            <th class="text-center">
                              SALDO
                            </th>
                          </tr>
                        </thead>
                        <tbody>
                          
                          <tr
                            v-for="(item) in cuotas"
                            :key="item.tbraccd_tran_number"
                          >
                            <td align="center"><strong>{{ item.tbraccd_detail_code }}</strong></td>
                            <td align="center">{{ item.tbraccd_tran_number }}</td>
                            <td align="center">{{ item.entry_date }}</td>
                            <td align="center">{{ item.eff_date }}</td>
                            <td align="center"><strong>{{ item.tbraccd_amount }}</strong></td>
                            <td align="center">{{ item.tbraccd_balance }} </td>
                          </tr> 
                        </tbody>
                    </v-table>
              </v-col>
            </v-row>
          </v-form>
    </v-card-text>

    <UCDialogQuestion
        :visible="activemsgConfirm"
        :message="msgConfirm"
        title="Confirmación"
        @cancel="closemsgConfirm"
        @ok="onSubmit"
    ></UCDialogQuestion>
  </div>
  </template>

<script>
import { ref, watch } from 'vue'
import { isEmpty, getFieldDb } from '@core/utils/index'
import { required, alphaDasNameValidator, requiredObject, maxlengthValidator } from '@core/utils/validation.js'
import useAppConfig from '@core/@app-config/useAppConfig'
import UCDialogQuestion from '@/components/UCDialogQuestion.vue'

export default {
  components: {
    UCDialogQuestion
  },
  props: {
    entityData: {
      type: Object,
      required: true,
    },
  },

  setup() {
    const valid = ref(false)
    const form = ref(null)
    const validate = () => {
      form.value.validate()
    }

    var { overlay } = useAppConfig()

    const enabled = {
      2: 'Inactivo',
      1: 'Activo',
    }

    let files = ref(null)

    let activemsgConfirm = ref(false)

    let cuotas = ref([])

    return {
      valid,
      form,
      validate,
      validators: { required, alphaDasNameValidator, requiredObject, maxlengthValidator},
      getFieldDb,
      isEmpty,
      overlay,
      enabled,
      files,
      msgConfirm: '',
      activemsgConfirm,
      cuotas
    }
  },
  beforeMount(){
      this.initialize()
  },
  methods: {
    initialize() {
      this.overlay = true
      this.$http.post('admission/get-cuotas', this.entityData)
        .then(response => {
          //console.log(response.data)
            this.cuotas = response.data
            this.overlay = false
            this.$forceUpdate()
        })
    },
    showMessageConfirm(){
      if (this.valid) {
        this.msgConfirm = "Seguro de Admitir al estudiante: "+ this.entityData.full_name
        this.activemsgConfirm = true
      }
    },
    closemsgConfirm(){
      this.activemsgConfirm = false
    },
    onSubmit(){
      this.closemsgConfirm()
      if (this.valid) {
        this.overlay = true
        //this.entityData.admission_status = 1
        this.$http.post('admission/admission', this.entityData)
            .then(response => {


              if(response.status == 200){
                this.$emit('create', response.data)
                this.$emit('load-alert', response.data, 'success', 'Éxito', 1)
                

              }else{
                this.$swal.fire({
                  title: 'Revisar',
                  html: response.data.mensaje,
                  icon: 'warning',
                  confirmButtonText: 'OK',
                })
              }
              this.entityData.admission_status = 0
              this.overlay = false


            })
            .catch(error => {  
                this.entityData.admission_status = 0
                this.overlay = false 
                this.$emit('load-alert', error.response.data.message)
            })
      } else {
         this.validate()
      }
    },
    uploadFiles(event){

      const file = Array.isArray(event) ? event[0] : event 

      if(this.files == null) {
        this.entityData.file  = null
        this.entityData.urlfile  = "/"
      }

      if(this.isEmpty(this.files)) return

      if(file.type != "application/pdf"){
        this.$emit('load-alert', 'Debe adjuntar un archivo PDF', 'error');
        //document.querySelector('#formSend').reset();
        //this.$refs.fileEa.value = null;
        this.entityData.file  = null
        this.entityData.urlfile  = "/"
        return;
      }

      if(file.size > (2048 * 1024)){ 
        this.$emit('load-alert', 'El archivo no debe exceder de 2MB', 'error');
        return;
      }

      this.overlay = true
      var formData = new FormData()

      formData.append("inputfile[0]", Array.isArray(this.files) ? this.files[0] : this.files);

        this.$http.post('admission/files', formData, {
            headers: {
            'Content-Type': 'multipart/form-data'
            }
        })
        .then(response => {
          this.$emit('load-alert', 'Acuerdo Adjuntado Correctamente', 'success', 'Éxito')

          this.entityData.file = response.data
          this.entityData.url_file = "/uploads_agreement/"+response.data
          this.$forceUpdate();
          this.overlay = false
        })
        .catch(error => {     
          this.overlay = false 
          this.$emit('load-alert', error.response.data.message)
        })
    },
  }
}
</script>
