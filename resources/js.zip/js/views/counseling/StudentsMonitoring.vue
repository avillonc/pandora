<template>
    <div>
      <v-card>
        <v-card-title class="text-wrap">
          <h4 class="py-2"><strong>
          {{ isShowEntityActive ? 'Estudiante: '+ valueSelected.name : 'Monitoreo de Estudiantes'}}</strong></h4>
        </v-card-title>
      <UCToolbar v-if="isShowEntityActive"
        @on-read="createEntityOrClose"></UCToolbar>
      <v-divider v-if="!isShowEntityActive"></v-divider>
        <v-card-text v-if="!isShowEntityActive" class="my-4">
          <v-form ref="form"
            v-model="valid"
            @submit="onSubmitGeneral" 
            @submit.prevent="validate"
            >
            <v-row>
              <v-col cols="12" md="3">
                  <v-autocomplete
                    variant="outlined"
                    density="compact"
                    label="Periodo"
                    v-model="entityData.term_code"
                    :items="periodos"
                    item-title="period_desc"
                    item-value="period_val"
                    :menu-props="{ offsetY: true }"
                    hide-details="auto"
                    :rules="[validators.required]"
                  ></v-autocomplete>
              </v-col> 
              <v-col cols="12" md="3">
                  <v-autocomplete
                    label="Carrera"
                    v-model="entityData.majr_code"
                    variant="outlined"
                    density="compact"
                    :items="programs"
                    item-title="name"
                    item-value="majr_code"
                    :menu-props="{ offsetY: true }"
                    hide-details="auto"
                    single-line
                  ></v-autocomplete>
              </v-col>
              <v-col
                cols="12"
                md="3"
              >
                <v-text-field
                  label="ID Banner"
                  v-model="entityData.idbanner"
                  variant="outlined"
                  density="compact"
                  small
                  hide-details="auto"
                ></v-text-field>
              </v-col>  
              <v-col
                cols="12"
                md="3"
              >
                <v-text-field
                  label="Asesor"
                  v-model="entityData.counselor"
                  variant="outlined"
                  density="compact"
                  hide-details="auto"
                  class="text-capitalize"
                ></v-text-field>
              </v-col>
              <v-col cols="12" md="3">
                <v-select
                  multiple
                  label="Admisión"
                  v-model="entityData.admission"
                  variant="outlined"
                  density="compact"
                  :items="admission"
                  item-title="text"
                  item-value="id"
                  :menu-props="{ offsetY: true }"
                  hide-details="auto"
                  :key="unique"
                ></v-select>
              </v-col>
              <v-col cols="12" md="3">
                <v-select
                  label="Riesgo"
                  v-model="entityData.risk_gen"
                  variant="outlined"
                  density="compact"
                  :items="riesgos"
                  item-title="text"
                  item-value="id"
                  :menu-props="{ offsetY: true }"
                  hide-details="auto"
                ></v-select>
              </v-col>
              
              
            </v-row>
            <v-row>
              <v-spacer></v-spacer>
                  <!--<v-col
                    cols="12"
                    md="2"
                  >
                    <v-btn block color="info" @click="exportResult" variant="outlined"> 
                    <v-icon
                      left
                      dark
                      icon="mdi-file-excel"
                    >
                    </v-icon>
                    Exportar </v-btn>
                  </v-col>-->
                  <v-col
                    cols="12"
                    md="3"
                  > 
                    <v-btn  block color="success" type="submit" :loading="isLoading">
                    <v-icon
                      left
                      dark
                      id="btnConsultar"
                      icon="mdi-magnify"
                    >
                    </v-icon>
                      Consultar
                    </v-btn>
                  </v-col>
            </v-row>
          </v-form>
        </v-card-text>
        <u-c-datatable  v-if="!isShowEntityActive"
              class="mt-4 row-pointer"
              :items="items" 
              :key="tableKey"
              :isLoading="isLoading"
              :headers="headers"
              :itemTotal="itemTotal"
              :itemsPage="itemsPerPage"
              :page="page"
              @show-form="showForm"
              @change-page="changePage"
              @item-per-page="changeItemPerPage"
        ></u-c-datatable>
  
        <student-view
          v-if="isShowEntityActive"
          :valueSelected="valueSelected"
          :typesobservation="typesobservation"
          >
        </student-view>
    </v-card>
  
    </div>
</template>

<script setup>

  //import { ref, inject } from 'vue'
  import UCToolbar from '@/components/UCToolbarOnBack.vue';
import useAppConfig from '@core/@app-config/useAppConfig';
import { required, requiredObject } from '@core/utils/validation.js';
import studentView from './monitoring-components/studentView.vue';
import UCDatatable from './monitoring-components/studentsTable.vue';

  //variables de sistema
  let { overlay } = useAppConfig()
  const $http = inject('http')

  let periodos = ref([])
  let programs = ref([])
  let typesobservation = ref([])

  let  riesgos = [{id: 'A', text: 'Riesgo Alto'}, 
    {id: 'M', text: 'Riesgo Medio'},
    {id: 'B', text: 'Riesgo Bajo'}, 
    {id: 'T', text:'Todos'}]
  let  admission = [{id: 'N', text: 'Nuevos'}, 
    {id: 'A', text:'Antiguos'}]
  let  validators = { required, 
    requiredObject}
  let headers = [
          { title: 'ID', key: 'dni', sortable: false, width: '70px',cellClass:'text-xs', align:'center'},
          { title: 'Nombre', key: 'name', sortable: false, width: '180px', cellClass:'text-xs'},
          { title: 'Riesgo', key: 'risk_gen', sortable: false, width: '50px', cellClass:'text-xs', align:'center'},
          { title: 'Estado', key: 'status', sortable: false, cellClass:'text-xs', align:'center' },
          { title: 'Faltas', key: 'risk_fal', sortable: false, width: '80px', cellClass:'text-xs', align:'center'},
          { title: 'Desaprob', key: 'risk_des', sortable: false, width: '80px', cellClass:'text-xs', align:'center'},
          { title: 'Deuda', key: 'risk_deb', sortable: false, cellClass:'text-xs', align:'center'},
          { title: 'Retiros', key: 'risk_ret', sortable: false, cellClass:'text-xs', align:'center'},
          { title: 'Carrera', key: 'major', sortable: false, cellClass:'text-xs', align:'center'},
          { title: 'Admisión', key: 'padmission', sortable: false, cellClass:'text-xs', align:'center'},
          { title: 'Asesor', key: 'counselor', sortable: false, cellClass:'text-xs text-center'}
        ]

  const valid = ref(false)
  const form = ref(null)
  let page = ref(1)
  let itemsPerPage = ref(25)
  let itemTotal = ref(0)
  let isLoading = ref(false)
  let tableKey = 0
  let isShowEntityActive = ref(false)
  
  let entityData = ref({ risk_gen: 'A', 
                          admission: ['N']})
  let items = ref([])
  let valueSelected = ref({})

  const validate = () => {
    form.value.validate()
  }

  const setOverlay = (value) => {
    overlay = value
  }

  function  initialize() {
    setOverlay(true)
    $http.get('/data/termcode')
        .then(response => {
      periodos.value = response.data

      $http.get('/data/currentTermCode')
        .then(resp => {
          entityData.value.term_code = resp.data.termcode
          setOverlay(false)
      })
    })
  }

  function  onSubmitGeneral() {
    page.value = 1
    onSubmit()
  }

  function  onSubmit() 
  {
    if (!valid.value) {
      return
    }          
    isLoading.value = true
      //items.value = []  
      entityData.value.itemsPerPage = itemsPerPage.value
      entityData.value.page = page.value          
      $http.post('/counseling/getdata', entityData.value)
      .then(response => {
          items.value = response.data.data
          itemTotal.value = Number(response.data.rows)
          //this.valueSelected = {}
          isLoading.value = false          
          tableKey++
      })
      .catch(error => {
            isLoading.value = false
      })
  }

  function changePage(pagenum){
    page.value = pagenum
    onSubmit()
  }

  function changeItemPerPage(perpage) {
    itemsPerPage.value = perpage
    page.value = 1
    onSubmit()
  }

  function getPrograms() {
    $http.get('/data/getPrograms')
    .then(response => {
        programs.value = response.data
    })
  }

  function geTypeobservation(){
    $http.get('/data/getTypeObservation')
      .then(response => {
          typesobservation.value = response.data
      })
  }

  function showForm(selected){
    valueSelected.value = selected
    isShowEntityActive.value = true
  }

  function createEntityOrClose(){
    valueSelected.value = {}
    isShowEntityActive.value = !isShowEntityActive.value
  }

  onBeforeMount(() => {
    initialize()
    getPrograms()
    geTypeobservation()
  })

</script>
 
 <script>
 </script>

  <style>

  .row-pointer:hover {
    cursor: pointer;
  }

  </style>
  