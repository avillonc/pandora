<template>
  <div>

  <v-row class="mb-3">
    <v-col cols="12"
          sm="12"
          align="center">
      <v-divider class="mb-2"></v-divider>
      <span class="th text-uppercase text-xs font-weight-bold" style="color: red">CARTERA</span>
      <u-c-datatable
      class="mt-2"
      :headers="headers"
      :items="entityData.debt"
      :itemsPage="10"
      >
      </u-c-datatable>
    </v-col>
  </v-row>

  <v-row class="mb-3">
    <v-col cols="12"
          sm="12"
          align="center">
      <v-divider class="mb-2"></v-divider>
      <span class="th text-uppercase text-xs font-weight-bold" style="color: red">BENEFICIO</span>
      <v-table density="compact" :key="key1" class="mt-2">
        <template v-slot:default>
          <thead>
            <tr>
              <th class="text-center text-xs" >
                Periodo
              </th>
              <th class="text-center text-xs" width="80">
                Categoría
              </th>
              <th class="text-center text-xs" width="50">
                Fecha
              </th>
              <th class="text-center text-xs" width="80" >
                Usuario
              </th>
              <th class="text-center text-xs">
                Beneficio
              </th>
              <th class="text-center text-xs" width="80" >
                % Dscto
              </th>
            </tr>
          </thead>
          <tbody>
            <tr v-if="entityData.benefit.length == 0">
              <td colspan="6" align="center" class="text-xs">
                No hay datos para mostrar
              </td>
            </tr>
            <tr
              v-for="(item, i) in entityData.benefit"
              :key="i"
            >
              <td class="text-center text-xs">{{ item.periodo }}</td>
              <td class="text-center text-xs">
                {{ item.categoria}}
              </td>
              <td class="text-center text-xs">
                {{ formatDate(item.fecha)}}
              </td>
              <td class="text-center text-xs">
                {{ item.usuario }}
              </td>
              <td class="text-center text-xs">
                {{ item.descripcion }}
              </td>
              <td class="text-center text-xs">
                {{ item.porcentaje }}
              </td>
            </tr>
          </tbody>
        </template>
      </v-table>
    </v-col>
  </v-row>

  <v-row class="mb-3">
    <v-col cols="12"
          sm="12"
          align="center">
      <v-divider class="mb-2"></v-divider>
      <span class="th text-uppercase text-xs font-weight-bold" style="color: red">CUENTA CORRIENTE</span>
      <u-c-datatable
      class="mt-2"
      :headers="headersSummary"
      :items="entityData.summary"
      :singleexpand="false"
      :showexpand="false"
      :itemsPage="10"
      >
      </u-c-datatable>
    </v-col>
  </v-row>

  </div>
</template>

<script>
  import { ref } from 'vue'
  import useAppConfig from '@core/@app-config/useAppConfig'
  import  UCDatatable  from '@/components/UCDataTable.vue'

  export default {
    components: {
      UCDatatable
    },
    props: {
      pidm : {
        type: String,
        required: true
      },
      termcode: {
        type: String,
        required: true
      }
    },
    setup() {

      var { overlay } = useAppConfig()
      let  entityData = ref({summary: [], benefit: [], debt: []})
      return {
      entityData,
      overlay,
      key1: 0,
      headers: [
        {
          title: 'Fecha',
          align: 'start',
          key: 'femision',
          cellClass:'title-xs'
        },
        { title: 'Periodo', key: 'periodo', cellClass:'title-xs' },
        { title: 'Concepto', key: 'concepto', cellClass:'title-xs'  },
        { title: 'Documento', key: 'documento',  cellClass:'title-xs'  },
        { title: 'Vcto', key: 'fvencimiento',  cellClass: 'title-xs'},
        { title: 'Importe', key: 'importe',  cellClass:'title-xs' },
        { title: 'Saldo', key: 'saldo',  cellClass:'title-xs' },
        { title: 'Gasto', key: 'gasto',  cellClass:'title-xs' },
        { title: 'Mora', key: 'mora',  cellClass:'title-xs' },
      ],
       headersSummary: [
        {
          title: 'Fecha.',
          align: 'start',
          cellClass:'title-xs',
          key: 'femision',
        },
        { title: 'Periodo', key: 'periodo',  cellClass:'title-xs' },
        { title: 'Concepto', key: 'concepto',  cellClass:'title-xs'  },
        { title: 'Documento', key: 'documento',  cellClass:'title-xs'  },
        { title: 'Importe', key: 'importe',  cellClass:'title-xs'  },
        { title: 'Pago', key: 'pagos',  cellClass:'title-xs'  },
        { title: 'Saldo', key: 'saldo',  cellClass: 'title-xs'},
        { title: 'Usuario', key: 'usuario',  cellClass: 'title-xs'},
      ],
      }
    },
    mounted(){
      this.onSubmit()
    },
    methods: {
      loadAlert(text, type="error", title="Advertencia"){
        this.$swal.fire({
                title: title,
                text: text,
                icon: type,
                confirmButtonText: 'OK',
              })
      },
      
      onSubmit() {          
          var data = {pidm: this.pidm, termcode: this.termcode}
          this.overlay = true
          this.$http.post('counseling/debt', data)
          .then(response => {   
              this.entityData.debt = response.data.debt
              this.entityData.summary = response.data.summary
              this.entityData.benefit = response.data.benefit
              this.key1++
              this.overlay = false   
              this.$forceUpdate() 
          })
          .catch(error => {
                this.overlay = false
                this.loadAlert(error.response.data.message)
          })

      },

      formatDate(created_at) {
        if (created_at === null) return
        return this.$moment(created_at).format('DD/MM/YYYY');
      },
    },
  }
</script>