
<template>
  <div class="text-sm">
     <v-divider></v-divider>
    <v-card-text class="my-6">
      <v-row>
        <v-col
          cols="12"
          md="6"
        >
        <span>Total de Registros: {{itemTotal}}</span>
          </v-col>
        <v-spacer></v-spacer>
        
      </v-row>
    </v-card-text>
    <v-data-table-server
      class="pb-4"
      density="comfortable"
      :headers="headers"
      :items="items"
      :loading="isLoading"
      :page="page"
      :items-per-page="itemsPerPage"
      items-per-page-text="Items por Página"
      :search="search"
      no-data-text="No hay datos para mostrar"
      :items-length="itemTotal"
      @click:row="selectRow"
      @update:itemsPerPage="changeItemPerPage"
      @update:page="changePage"
    >

      <template v-slot:item.name="{item}">
        <span class="text-primary">{{item.value.name}}</span>
      </template>

      <template #[`item.major`]="{item}">
            <span class="primary-text">{{item.value.major}}</span>
      </template>

      <template #[`item.status`]="{item}">
        <v-chip
          small
          :color="enabledColor(item.value.status)"
          :class="`${enabledColor(item.value.status)}-text`"
          class="v-chip-light-bg"
        >
          {{ item.value.status }}
        </v-chip>
      </template>

      <template v-slot:loading>
        <div class="text-center py-4">
          <p>Obteniendo Data ...</p>
        </div>
      </template>

    </v-data-table-server>
    
  </div>
</template>
<script>
import { ref } from 'vue'
//import * as moment from 'moment'
import {Functions} from "@core/libs/lib.js"
import useAppConfig from '@core/@app-config/useAppConfig'
import { required, requiredObject } from '@core/utils/validation.js'

export default {
  props: {
    items: {
      type: Array,
      required: true
    },
    isLoading: {
      type: Boolean,
      default: false,
    },
    headers: {
      type: Array,
      required: true
    },
    sortBy: {
      type: String,
      default: "id"
    },
    showSelect: {
      type: Boolean,
      default: true
    },
    nameAction: {
      type: String,
      default: 'Guardar'
    },
    search: {
      type: String,
      default: ''
    },
    itemTotal: {
      type: Number,
      default: null
    },
    itemsPage: {
      type: Number,
      default: 25
    },
    page: {
      type: Number,
      default: 1
    }
  },

  setup(props) {

    const enabledColor = (value) => {
        switch (value) {
        case 'AS':
          return 'info';
        case 'RP':
          return 'error';
        case 'IS':
          return 'primary';
        default:
          return 'secondary';
      }
    }

    var { overlay } = useAppConfig()

    const valid = ref(false)
    const form = ref(null)
    const validate = () => {
      form.value.validate()
    }

    const resetValidation = ()=> {
      form.value.resetValidation()
    }

    const entityData = ref({})

    return {
      page: props.page,
      pageCount: 0,
      itemsPerPage: props.itemsPage,
      enabledColor,
      valueSelected: {},
      msgConfirm: '',
      activemsgConfirm: false,
      msgConfirmReenvio: '',
      overlay,
      valid,
      form,
      validate,
      resetValidation,
      validators: { required, requiredObject}
    }
  },
  methods: {
    loadAlert(text, type="error", title="Advertencia"){
      this.$swal.fire({
              title: title,
              text: text,
              icon: type,
              confirmButtonText: 'OK',
            })
    },
    changeItemPerPage(item){
      this.valueSelected = {}
      this.$emit('item-per-page', item)
    },
    selectRow(event, row){
      this.$emit('show-form',row.item.value)
    },
    changePage(value){
      this.valueSelected = {}
      this.$emit('change-page', value)
    }
  }
}
</script>