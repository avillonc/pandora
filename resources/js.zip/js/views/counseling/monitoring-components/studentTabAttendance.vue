<template>
  <div>

  <v-row class="mb-3">
    <v-col cols="12"
          sm="12"
          align="center">
      <v-divider class="mb-2"></v-divider>
      <span class="th text-uppercase text-xs font-weight-bold" style="color: red">RESUMEN</span>
      <v-data-table
      class="mt-2"
      density="compact"
      :headers="headers"
      :items="entityData.summary"
      :items-per-page="100"
      no-data-text="No hay datos para mostrar"
      page.sync="1"
      hide-default-footer
      item-key="code"
    >
      <template v-slot:bottom>
      </template>
    </v-data-table>
    </v-col>
  </v-row>

  <v-row class="mb-3">
    <v-col cols="12"
          sm="12"
          align="center">
      <v-divider class="mb-2"></v-divider>
      <span class="th text-uppercase text-xs font-weight-bold" style="color: red">DETALLE</span>
      <u-c-datatable
      class="mt-2"
      :headers="headersDetail"
      :items="entityData.details"
      >
      </u-c-datatable>
    </v-col>
  </v-row>

  </div>
</template>

<script>
  import { ref } from 'vue'
  import useAppConfig from '@core/@app-config/useAppConfig'
  import  UCDatatable  from '@/components/UCDataTable.vue'

  export default {
    components: {
      UCDatatable
    },
    props: {
      pidm : {
        type: String,
        required: true
      },
      termcode: {
        type: String,
        required: true
      }
    },
    setup() {

      var { overlay } = useAppConfig()

      let entityData = ref({summary: [], details: []})

      return {
      entityData,
      overlay,
      key1: 0,
      key2: 0,
      headers: [
        {
          title: 'Código',
          align: 'start',
          cellClass:'text-xs',
          key: 'cod',
        },
        { title: 'Curso', key: 'curso', cellClass:'text-xs' },
        { title: 'NRC', key: 'nrc', cellClass:'text-xs'  },
        { title: 'Faltas', key: 'falto',  cellClass:'text-xs'  },
        { title: 'Total', key: 'total',  cellClass: 'text-xs'},
        { title: '%', key: 'porc',  cellClass:'text-xs' },
      ],
       headersDetail: [
        {
          title: 'Fecha',
          align: 'start',
          cellClass:'text-xs',
          key: 'fecha',
        },
        { title: 'Tipo', key: 'tipo',  cellClass:'text-xs' },
        { title: 'Código', key: 'cod',  cellClass:'text-xs'  },
        { title: 'Curso', key: 'curso',  cellClass:'text-xs'  },
        { title: 'NRC', key: 'nrc',  cellClass: 'text-xs'},
      ],
      nrcs: []

      }
    },
    mounted(){
      this.onSubmit()
    },
    methods: {
      loadAlert(text, type="error", title="Advertencia"){
        //this.$store.commit('appConfig/TOGGLE_SNACKBAR', {show: true, text: text, color: type})
        this.$swal.fire({
                title: title,
                text: text,
                icon: type,
                confirmButtonText: 'OK',
              })
      },
      
      onSubmit() {          
          var data = {pidm: this.pidm, termcode: this.termcode}
          this.overlay = true
          this.$http.post('counseling/attendance', data)
          .then(response => {   

              this.entityData.summary = response.data.summary
              this.entityData.details = response.data.details
              this.key1++
              this.key2++
              this.overlay = false   
              this.$forceUpdate() 
          })
          .catch(error => {
                this.overlay = false
                this.loadAlert(error.response.data.message)
          })

      },
    },
  }
</script>