<template>
  <div id="user-view">
    <v-row>
      <v-expand-x-transition>
      <v-col cols="12" :md="show ? 4 : 1" class="overflow-hidden">
        <v-card-actions>
          <v-spacer></v-spacer>
          <v-tooltip :text="show ? 'Ocultar resumen' : 'Mostrar resumen'">
            <template v-slot:activator="{ props }">
              <v-btn v-bind="props"
                :icon="show ? 'mdi-chevron-left' : 'mdi-chevron-right'"
                @click="show = !show"
              ></v-btn>
            </template>
          </v-tooltip>
        </v-card-actions>
        <v-expand-x-transition>
          <div v-show="show">
            <student-tab-bio-panel
            :user-data="valueSelected"
            :is-plan-upgrade-dialog-visible.sync="isPlanUpgradeDialogVisible"
          ></student-tab-bio-panel>
          </div>
        </v-expand-x-transition>
      </v-col>
      </v-expand-x-transition>
      <v-col cols="12" :md="show ? 8 : 11" >
        <VTabs 
          v-model="userTab"
          show-arrows
          class="user-tabs"
        >
          <v-tab 
            v-for="tab in tabs" 
            :key="tab.title"
            :value="tab.tab"
            >
            <span>{{ tab.title }}</span>
          </v-tab>
        </VTabs>
        <VDivider />
        <VWindow
          v-model="userTab"
          class="mt-5 disable-tab-transition"
        >
          <VWindowItem value="observation">
            <student-tab-observations 
              :pidm="valueSelected.pidm"
              :items="valueSelected.observations"
              :types="typesobservation"
              @reload-observ="loadObserv">
            </student-tab-observations>
          </VWindowItem>
    
          <VWindowItem value="curricular">
            <student-tab-curricular 
              :pidm="valueSelected.pidm"
              :termcode="valueSelected.termcode">
            </student-tab-curricular>
          </VWindowItem>
    
          <VWindowItem value="schedule">
            <student-tab-schedule
              :pidm="valueSelected.pidm"
              :termcode="valueSelected.termcode"
            ></student-tab-schedule>
          </VWindowItem>

          <VWindowItem value="attendance">
            <student-tab-attendance
              :pidm="valueSelected.pidm"
              :termcode="valueSelected.termcode"
            ></student-tab-attendance>
          </VWindowItem>

          <VWindowItem value="score">
            <student-tab-score
            :pidm="valueSelected.pidm"
            :termcode="valueSelected.termcode">
            </student-tab-score>
          </VWindowItem>

          <VWindowItem value="debt">
            <student-tab-debt
            :pidm="valueSelected.pidm"
            :termcode="valueSelected.termcode">
            </student-tab-debt>
          </VWindowItem>

        </VWindow>
        <!--<v-tabs-items id="user-tabs-content" v-model="userTab" >
          <v-tab-item>
            
            
          </v-tab-item>

          <v-tab-item>
            
          </v-tab-item>
          <v-tab-item>
            
          </v-tab-item>
          <v-tab-item>
            
          </v-tab-item>
          <v-tab-item>
            
          </v-tab-item>
          <v-tab-item>
            
          </v-tab-item>
        </v-tabs-items>-->
      </v-col>
    </v-row>
  </div>
</template>
<script setup>

</script>

<script>

import { required, maxlengthValidator } from '@core/utils/validation.js'
import { ref } from 'vue'
import  studentTabObservations  from './studentTabObservations.vue';
import  studentTabCurricular  from './studentTabCurricular.vue';
import  studentTabSchedule  from './studentTabSchedule.vue';
import  studentTabAttendance  from './studentTabAttendance.vue';
import  studentTabDebt  from './studentTabDebt.vue';
import  studentTabScore  from './studentTabScore.vue';
import studentTabBioPanel from './studentTabBioPanel.vue'
import useAppConfig from '@core/@app-config/useAppConfig'

export default {
  components: {
      studentTabBioPanel,
      studentTabObservations,
      studentTabCurricular,
      studentTabSchedule,
      studentTabAttendance,
      studentTabScore,
      studentTabDebt
  },
  props: {
    valueSelected: {
      type: Object,
      required: true,
    },
    typesobservation: {
      type: Array,
      required: true,
    }
  },
  setup() {

    const entityData = ref({})

    var { overlay } = useAppConfig()

    const valid = ref(false)
    const form = ref(null)
    const validate = () => {
      form.value.validate()
    }

    const resetValidation = ()=> {
      form.value.resetValidation()
    }

    const isPlanUpgradeDialogVisible = ref(false)

    let userTab = ref('observation') 

    let show = ref(true)

    return {
      validators: { required},
      valid,
      form,
      validate,
      resetValidation,
      entityData,
      validators: { required, maxlengthValidator},
      isPlanUpgradeDialogVisible,
      tabs: [
      { title: 'Observaciones', tab: 'observation' },
      { title: 'Avance Curricular', tab: 'curricular'  },
      { title: 'Horario', tab: 'schedule'  },
      { title: 'Asistencia', tab: 'attendance'  },
      { title: 'Notas', tab: 'score'  },
      { title: 'Deuda', tab: 'debt'  },
      ],
      overlay,
      collapseOnScroll: true,
      userTab,
      show
    }
  },
  mounted(){
    this.blankentityData()
    this.valueSelected.observations = []
    this.loadObserv()
  },
  methods: {
    loadAlert(text, type="error", title="Advertencia"){
      this.$swal.fire({
              title: title,
              text: text,
              icon: type,
              confirmButtonText: 'OK',
            })
    },
    blankentityData(){
      this.entityData = {}
    },
    loadObserv(){
      this.overlay = true
      this.$http.get('counseling/observations/'+this.valueSelected.pidm)
          .then(response => {
              this.valueSelected.observations = response.data    
              this.$forceUpdate()       
              this.overlay = false            
          })
          .catch(error => {
              this.overlay = false
          })
    },
  }
}
</script>
<style lang="scss">

</style>