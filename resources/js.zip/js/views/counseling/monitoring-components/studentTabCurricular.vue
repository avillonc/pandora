<template>
  <div>
  <v-row class="mb-3">
    <v-col cols="12"
          sm="4"  align="center">
          <span class="info--text text-md">Créditos Aprobados </span>{{entityData.cred.creditos_aprobados == undefined ? 0 : entityData.cred.creditos_aprobados}}
    </v-col>
    <v-col cols="12"
          sm="4"  align="center">
          <span class="info--text text-md">Créditos Totales </span> {{entityData.cred.creditos_totales == undefined ? 0 : entityData.cred.creditos_totales}}
    </v-col>
    <v-col cols="12"
          sm="4" align="center">
          <span class="info--text text-md"> Por Definir </span> {{entityData.cred.creditos_restantes == undefined ? 0 : entityData.cred.creditos_restantes}}
    </v-col>
  </v-row>

  <v-row class="mb-3">
    <v-col cols="12"
          sm="6">
      <v-table density="compact" :key="key1">
        <template v-slot:default>
          <thead>
            <tr>
              <th colspan="4" class="text-center"><span style="color: green">{{entityTwoData.crtf1}}</span></th>
            </tr>
            <tr>
              <th class="text-xs" width="300">
                Curso
              </th>
              <th class="text-center text-xs" >
                Cred
              </th>
              <th class="text-center text-xs" >
                Periodo
              </th>
              <th class="text-center text-xs px-1">
                Nota
              </th>
            </tr>
          </thead>
          <tbody>
            <tr
              v-for="item in entityData.crtf1"
              :key="item.curso"
            >
              <td class="text-xs px-1">{{ item.curso }}</td>
              <td class="text-center text-xs px-1">
                {{ item.creditos }}
              </td>
              <td class="text-center text-xs px-1">
                {{ item.periodo }}
              </td>
              <td class="text-center text-xs px-1">
                {{ item.nota }}
              </td>
            </tr>
          </tbody>
          <tfoot>
            <tr ><th colspan="4" class="text-xs">{{entityData.crtf1.length}} Items</th>
            </tr>
          </tfoot>
        </template>
      </v-table>
    </v-col>
    <v-col cols="12"
          sm="6">
      <v-table density="compact" :key="key2">
        <template v-slot:default>
          <thead>
            <tr>
              <th colspan="4" class="text-center"><span style="color: blue">{{entityTwoData.crtf2}}</span></th>
            </tr>
            <tr>
              <th class="text-xs" width="300">
                Curso
              </th>
              <th class="text-center text-xs">
                Cred
              </th>
              <th class="text-center text-xs">
                Periodo
              </th>
              <th class="text-center text-xs">
                Nota
              </th>
            </tr>
          </thead>
          <tbody>
            <tr
              v-for="item in entityData.crtf2"
              :key="item.curso"
            >
              <td class="text-xs">{{ item.curso }}</td>
              <td class="text-center text-xs">
                {{ item.creditos }}
              </td>
              <td class="text-center text-xs">
                {{ item.periodo }}
              </td>
              <td class="text-center text-xs">
                {{ item.nota }}
              </td>
            </tr>
          </tbody>
          <tfoot>
            <tr ><th colspan="4" class="text-xs">{{entityData.crtf2.length}} Items</th>
            </tr>
          </tfoot>
        </template>
      </v-table>
    </v-col>
  </v-row>
  <v-row class="mb-3">
    <v-col cols="12"
          sm="6">
      <v-table density="compact" :key="key3">
        <template v-slot:default>
          <thead>
            <tr>
              <th colspan="4" class="text-center"><span style="color: purple;">{{entityTwoData.crtf3}}</span></th>
            </tr>
            <tr>
              <th class="text-xs" width="300">
                Curso
              </th>
              <th class="text-center text-xs">
                Cred
              </th>
              <th class="text-center text-xs">
                Periodo
              </th>
              <th class="text-center text-xs">
                Nota
              </th>
            </tr>
          </thead>
          <tbody>
            <tr
              v-for="item in entityData.crtf3"
              :key="item.curso"
            >
              <td class="text-xs">{{ item.curso }}</td>
              <td class="text-center text-xs">
                {{ item.creditos }}
              </td>
              <td class="text-center text-xs">
                {{ item.periodo }}
              </td>
              <td class="text-center text-xs">
                {{ item.nota }}
              </td>
            </tr>
          </tbody>
          <tfoot>
            <tr ><th colspan="4" class="text-xs">{{entityData.crtf3.length}} Items</th>
            </tr>
          </tfoot>
        </template>
      </v-table>
    </v-col>
    <v-col cols="12"
          sm="6">
      <v-table density="compact" :key="key4">
        <template v-slot:default>
          <thead>
            <tr>
              <th colspan="4" class="text-center"><span style="color: orange;">{{entityTwoData.tab4}}</span></th>
            </tr>
            <tr>
              <th class="text-xs" width="300">
                Curso
              </th>
              <th class="text-center text-xs">
                Cred
              </th>
              <th class="text-center text-xs">
                Periodo
              </th>
              <th class="text-center text-xs">
                Nota
              </th>
            </tr>
          </thead>
          <tbody>
            <tr
              v-for="item in entityData.tab4"
              :key="item.curso"
            >
              <td class="text-xs">{{ item.curso }}</td>
              <td class="text-center text-xs">
                {{ item.creditos }}
              </td>
              <td class="text-center text-xs">
                {{ item.periodo }}
              </td>
              <td class="text-center text-xs">
                {{ item.nota }}
              </td>
            </tr>
          </tbody>
          <tfoot>
            <tr ><th colspan="4" class="text-xs">{{entityData.tab4.length}} Items</th>
            </tr>
          </tfoot>
        </template>
      </v-table>
    </v-col>
  </v-row>
  <v-row class="mb-3">
    <v-col cols="12"
          sm="6">
      <v-table density="compact" :key="key5">
        <template v-slot:default>
          <thead>
            <tr>
              <th colspan="4" class="text-center"><span style="color: red;">{{entityTwoData.tab5}}</span></th>
            </tr>
            <tr>
              <th class="text-xs" width="300">
                Curso
              </th>
              <th class="text-center text-xs">
                Cred
              </th>
              <th class="text-center text-xs">
                Periodo
              </th>
              <th class="text-center text-xs">
                Nota
              </th>
            </tr>
          </thead>
          <tbody>
            <tr
              v-for="item in entityData.tab5"
              :key="item.curso"
            >
              <td class="text-xs">{{ item.curso }}</td>
              <td class="text-center text-xs">
                {{ item.creditos }}
              </td>
              <td class="text-center text-xs">
                {{ item.periodo }}
              </td>
              <td class="text-center text-xs">
                {{ item.nota }}
              </td>
            </tr>
          </tbody>
          <tfoot>
            <tr ><th colspan="4" class="text-xs">{{entityData.tab5.length}} Items</th>
            </tr>
          </tfoot>
        </template>
      </v-table>
    </v-col>
    <v-col cols="12"
          sm="6">
      <v-table density="compact" :key="key6">
        <template v-slot:default>
          <thead>
            <tr>
              <th colspan="4" class="text-center">{{entityTwoData.tab6}}</th>
            </tr>
            <tr>
              <th class="text-xs" width="300">
                Curso
              </th>
              <th class="text-center text-xs">
                Cred
              </th>
              <th class="text-center text-xs">
                Periodo
              </th>
              <th class="text-center text-xs">
                Nota
              </th>
            </tr>
          </thead>
          <tbody>
            <tr
              v-for="item in entityData.tab6"
              :key="item.curso"
            >
              <td class="text-xs">{{ item.curso }}</td>
              <td class="text-center text-xs">
                {{ item.creditos }}
              </td>
              <td class="text-center text-xs">
                {{ item.periodo }}
              </td>
              <td class="text-center text-xs">
                {{ item.nota }}
              </td>
            </tr>
          </tbody>
          <tfoot>
            <tr ><th colspan="4" class="text-xs">{{entityData.tab6.length}} Items</th>
            </tr>
          </tfoot>
        </template>
      </v-table>
    </v-col>
  </v-row>
  


  </div>
</template>

<script>
  import { ref } from 'vue'
  import useAppConfig from '@core/@app-config/useAppConfig'

  export default {
    props: {
      pidm : {
        type: String,
        required: true
      },
      termcode: {
        type: String,
        required: true
      }
    },
    setup() {

      var { overlay } = useAppConfig()
      let entityData = ref({crtf1: [], crtf2: [], crtf3: [], tab4: [], tab5: [], tab6: [], cred: []})
      let entityTwoData = ref({})
      return {
      entityData,
      entityTwoData,
      overlay,
      key1: 0,
      key2: 0,
      key3: 0,
      key4: 0,
      key5: 0,
      key6: 0,
      }
    },
    mounted(){
      this.onSubmit()
    },
    methods: {
      loadAlert(text, type="error", title="Advertencia"){
        //this.$store.commit('appConfig/TOGGLE_SNACKBAR', {show: true, text: text, color: type})
        this.$swal.fire({
                title: title,
                text: text,
                icon: type,
                confirmButtonText: 'OK',
              })
      },
      
      onSubmit() {          
          var data = {pidm: this.pidm, termcode: this.termcode}
          this.overlay = true
          this.$http.post('counseling/curriculum', data)
          .then(response => {   

              this.entityTwoData = response.data.titles.length == 1 ? response.data.titles[0] : [] 
              this.entityData.crtf1 = response.data.crtf1
              this.entityData.crtf2 = response.data.crtf2
              this.entityData.crtf3 = response.data.crtf3
              this.entityData.tab4= response.data.tab4
              this.entityData.tab5 = response.data.tab5
              this.entityData.tab6 = response.data.tab6
              this.entityData.cred = response.data.cred.length == 1 ? response.data.cred[0] : []  
              this.key1++
              this.key2++
              this.key3++
              this.key4++
              this.key5++
              this.key6++
              this.overlay = false   
              this.$forceUpdate() 
          })
          .catch(error => {
                this.overlay = false
                this.loadAlert(error.response.data.message)
          })

      },
    },
  }
</script>