<template>
  <v-row class="user-bio-panel">
    <!-- user profile -->
    <v-col cols="12">
      <v-card class="pt-3 ml-2 mb-2" variant="tonal"
        color="primary">
        <v-card-title class="text-center flex-column">
          <v-avatar
            :color="userData.avatar ? '' : 'primary'"
            :class="userData.avatar ? '' : 'v-avatar-light-bg primary--text'"
            size="150"
            rounded
            class="mb-2"
          >
            
            <span v-if="!userData.photo || userData.photo.length==0" class="font-weight-semibold text-5xl">{{ avatarTextNew(userData.name) }}</span>
            <v-img v-else :src="userData.photo" style="background: rgb(var(--v-theme-on-white))"></v-img>
          </v-avatar>

          <p class="text-sm text-center">{{ userData.name }}</p>
        </v-card-title>

        <v-card-text>
          <span class="text-sm info--text font-weight-semibold">Datos Personales</span>

          <v-divider></v-divider>

          <v-list class ="mb-4" style="overflow-y: hidden;" density="compact">
            <v-list-item  class="px-0 mb-n5">
              <span class="font-weight-medium me-2">ID:</span>
              <span class="text--secondary">{{ userData.dni }}</span>
            </v-list-item>

            <v-list-item  class="px-0 mb-n5">
              <span class="font-weight-medium text-no-wrap me-2">Sexo:</span>
              <span class="text--secondary">{{ userData.sex }}</span>
            </v-list-item>

            <v-list-item  class="px-0 mb-n5">
              <span class="font-weight-medium me-2">Edad:</span>
              <span class="text--secondary">{{ userData.age }}</span>
            </v-list-item>
            <v-list-item  class="px-0 mb-n5">
              <span class="font-weight-medium me-2">Correo:</span>
              <span class="text--secondary">{{ userData.email }}</span>
            </v-list-item>

            <v-list-item  class="px-0 mb-n5">
              <span class="font-weight-medium me-2">Telefono:</span>
              <span class="text--secondary">+1 {{ userData.phone }}</span>
            </v-list-item>
          </v-list>

          <span class="text-sm mt-3 info--text font-weight-semibold">Datos Académicos</span>

          <v-divider></v-divider>

          <v-list class ="mb-4" style="overflow-y: hidden;" density="compact">
            <v-list-item  class="px-0 mb-n5">
              <span class="font-weight-medium me-3">PIDM:</span>
              <span class="text--secondary">{{ userData.pidm }}</span>
            </v-list-item>

            <v-list-item  class="px-0 mb-n5">
              <span class="font-weight-medium me-3">Carrera:</span>
              <span class="text--secondary">{{ userData.major }}</span>
            </v-list-item>

            <v-list-item  class="px-0 mb-n5">
              <span class="font-weight-medium text-no-wrap me-2">Admisión:</span>
              <span class="text--secondary">{{ userData.padmission }}</span>
            </v-list-item>

            <v-list-item  class="px-0 mb-n5">
              <span class="font-weight-medium me-2">Estado:</span>
              <span class="text--secondary">{{ userData.status }}</span>
            </v-list-item>

            <v-list-item  class="px-0 mb-n5">
              <span class="font-weight-medium me-2">Categoría:</span>
              <span class="text--secondary">{{ userData.category }}</span>
            </v-list-item>

            <v-list-item  class="px-0 mb-n5">
              <span class="font-weight-medium me-2">Riesgo:</span>
              <span class="text--secondary">+1 {{ userData.risk_gen }}</span>
            </v-list-item>

            <v-list-item  class="px-0 mb-n5">
              <span class="font-weight-medium me-3">Faltas:</span>
              <span class="text--secondary">{{ userData.risk_fal }}</span>
            </v-list-item>

            <v-list-item  class="px-0 mb-n5">
              <span class="font-weight-medium text-no-wrap me-2">Desaprobado:</span>
              <span class="text--secondary">{{ userData.risk_des }}</span>
            </v-list-item>

            <v-list-item  class="px-0 mb-n5">
              <span class="font-weight-medium me-2">Retiro:</span>
              <span class="text--secondary">{{ userData.risk_ret }}</span>
            </v-list-item>
            
            <v-list-item  class="px-0 mb-n5">
              <span class="font-weight-medium me-2">Ultima Asistencia:</span>
              <span class="text--secondary">{{ formatDate(userData.last_asis) }}</span>
            </v-list-item>

            <v-list-item  class="px-0 mb-n5">
              <span class="font-weight-medium me-2">Asesor:</span>
              <span class="text--secondary text-capitalize">{{ userData.counselor.toLowerCase() }}</span>
            </v-list-item>
          </v-list>

          <span class="text-sm mt-3 info--text font-weight-semibold">Datos Financieros</span>

          <v-divider></v-divider>

          <v-list style="overflow-y: hidden;" density="compact">
            <v-list-item  class="px-0 mb-n5">
              <span class="font-weight-medium me-3">Beneficio:</span>
              <span class="text--secondary">{{ userData.benefit }}</span>
            </v-list-item>

            <v-list-item  class="px-0 mb-n5">
              <span class="font-weight-medium text-no-wrap me-2">Deuda:</span>
              <span class="text--secondary">{{ userData.risk_deb }}</span>
            </v-list-item>
          </v-list>
        </v-card-text>

        <v-card-actions class="justify-center">
        </v-card-actions>
      </v-card>

    </v-col>

  </v-row>
</template>

<script>

import { avatarTextNew } from '@core/utils/filter'
import { ref } from 'vue'
//import * as moment from 'moment'

export default {
  props: {
    userData: {
      type: Object,
      required: true,
    },
    isPlanUpgradeDialogVisible: {
      type: Boolean,
      required: true,
    },
  },
  setup() {

    const isBioDialogOpen = ref(false)


    return {
      avatarTextNew,
    }
  },
  mounted(){
    this.loadPhoto()
  },
  methods: {
    formatDate(date) {
        if (date !== null) {
          return moment(date).format('DD/MM/YY');
        } 

        return '-';
    },
    loadPhoto(){
      this.$http.get('counseling/photo/'+this.userData.dni)
          .then(response => {
              this.userData.photo = response.data          
          })
    },
  }
}
</script>