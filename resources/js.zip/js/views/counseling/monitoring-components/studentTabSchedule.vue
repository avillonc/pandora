<template>
  <div>

  <v-row class="mb-3">
    <v-col cols="12"
          sm="12"
          align="center">
      <v-divider class="mb-2"></v-divider>
      <span class="th text-uppercase text-xs font-weight-bold" style="color: red">CURSOS PROYECTADOS Y MATRICULADOS</span>
      <v-data-table
      class="mt-2"
      density="compact"
      :headers="headers"
      :items="entityData.nrcs"
      :items-per-page="1000"
      no-data-text="No hay datos para mostrar"
      page.sync="1"
      hide-default-footer
      :single-expand="true"
      show-expand
    >
    <template v-slot:bottom>
    </template>
      
    </v-data-table>
    </v-col>
  </v-row>

  <v-row class="mb-3">
    <v-col cols="12"
          sm="12"
          align="center">
      <v-divider class="mb-2"></v-divider>
      <span class="th text-uppercase text-xs font-weight-bold" style="color: red">HORARIO</span>
      <v-table  density="compact" :key="key1" class="mt-2">
        <template v-slot:default>
          <thead>
            <tr>
              <th class="text-center text-xs" width="30" >
                Hora
              </th>
              <th class="text-center text-xs" width="100">
                Lunes
              </th>
              <th class="text-center text-xs" width="100">
                Martes
              </th>
              <th class="text-center text-xs" width="100" >
                Miercoles
              </th>
              <th class="text-center text-xs" width="100" >
                Jueves
              </th>
              <th class="text-center text-xs" width="100" >
                Viernes
              </th>
            </tr>
          </thead>
          <tbody>
            <tr v-if="entityData.schedule.length == 0">
              <td colspan="6" align="center" class="text-xs">
                No hay datos para mostrar
              </td>
            </tr>
            <tr
              v-for="item in entityData.schedule"
              :key="item.horden"
            >
              <td class="text-center text-xs">{{ item.hora }}</td>
              <td class="text-center text-xs">
                {{ item.lun }}
              </td>
              <td class="text-center text-xs">
                {{ item.mar}}
              </td>
              <td class="text-center text-xs">
                {{ item.mie }}
              </td>
              <td class="text-center text-xs">
                {{ item.jue }}
              </td>
              <td class="text-center text-xs">
                {{ item.vie }}
              </td>
            </tr>
          </tbody>
        </template>
      </v-table>
    </v-col>
  </v-row>

  </div>
</template>

<script>
  import { ref } from 'vue'
  import useAppConfig from '@core/@app-config/useAppConfig'

  export default {
    props: {
      pidm : {
        type: String,
        required: true
      },
      termcode: {
        type: String,
        required: true
      }
    },
    setup() {

      var { overlay } = useAppConfig()

      let entityData = ref({nrcs: [], schedule: []})

      return {
      entityData,
      overlay,
      key1: 0,
      key2: 0,
      headers: [
        {
          title: 'Código',
          align: 'start',
          sortable: false,
          key: 'codigo',
        },
        { title: 'Descripción', key: 'descripcion', sortable: false, cellClass:'text-xs' },
        { title: 'Usuario', key: 'usuario', sortable: false, cellClass:'text-xs'  },
        { title: 'NRC', key: 'nrc', sortable: false, cellClass:'text-xs'  },
        { title: 'Modalidad', key: 'modalidad', sortable: false, cellClass: 'text-xs'},
        { title: 'Estado', key: 'options', sortable: false, cellClass:'text-xs' },
      ],
      nrcs: []

      }
    },
    mounted(){
      this.onSubmit()
    },
    methods: {
      loadAlert(text, type="error", title="Advertencia"){
        //this.$store.commit('appConfig/TOGGLE_SNACKBAR', {show: true, text: text, color: type})
        this.$swal.fire({
                title: title,
                text: text,
                icon: type,
                confirmButtonText: 'OK',
              })
      },
      
      onSubmit() {          
          var data = {pidm: this.pidm, termcode: this.termcode, tipo: 'CLAS'}
          this.overlay = true
          this.$http.post('counseling/schedule', data)
          .then(response => {   

              this.entityData.nrcs = response.data.nrcs
              this.entityData.schedule = response.data.schedule
              this.key1++
              this.key2++
              this.overlay = false   
              this.$forceUpdate() 
          })
          .catch(error => {
                this.overlay = false
                this.loadAlert(error.response.data.message)
          })

      },
    },
  }
</script>