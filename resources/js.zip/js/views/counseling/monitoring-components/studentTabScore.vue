<template>
  <div>

  <v-row class="mb-3">
    <v-col cols="12"
          sm="12"
          align="center">
      <v-divider class="mb-2"></v-divider>
      <span class="th text-uppercase text-xs font-weight-bold" style="color: red">CURSOS POR PERIODO</span>
      <u-c-datatable
      class="mt-2"
      :headers="headers"
      :items="entityData"
      :isTable="false"
      :itemsPage="5"
      :canSee="true"
      :canEdit="false"
      :canDelete="false"
      @see="selectRow"
      >
      </u-c-datatable>
    </v-col>
  </v-row>

  <v-row class="mb-3">
    <v-col cols="12"
          sm="12"
          align="center">
      <v-divider class="mb-2"></v-divider>
      <span class="th text-uppercase text-xs font-weight-bold" style="color: red">DETALLE DE NOTA POR CURSO {{course}}</span>
      <v-table density="compact" :key="key2" class="mt-2">
        <template v-slot:default>
          <thead>
            <tr>
              <th class="text-center text-xs" >
                Componente
              </th>
              <th class="text-center text-xs" width="80">
                %
              </th>
              <th class="text-center text-xs" >
                Subcomponente
              </th>
              <th class="text-center text-xs" width="80" >
                %
              </th>
              <th class="text-center text-xs" width="80" >
                Nota
              </th>
            </tr>
          </thead>
          <tbody>
            <tr
              v-for="item in entityScore"
              :key="item.shrscom_seq_no"
            >
              <td class="text-xs">{{ item.shrgcom_name }}</td>
              <td class="text-center text-xs">
                {{ item.shrgcom_weight}}
              </td>
              <td class="text-xs">
                {{ item.shrscom_description}}
              </td>
              <td class="text-center text-xs">
                {{ item.peso }}
              </td>
              <td class="text-center text-xs">
                {{ item.shrsmrk_score }}
              </td>
            </tr>
          </tbody>
        </template>
      </v-table>
    </v-col>
  </v-row>
  </div>
</template>

<script>
  import { ref } from 'vue'
  import useAppConfig from '@core/@app-config/useAppConfig'
  import  UCDatatable  from '@/components/UCDataTableOptions.vue'

  export default {
    components: {
      UCDatatable
    },
    props: {
      pidm : {
        type: String,
        required: true
      },
      termcode: {
        type: String,
        required: true
      }
    },
    setup() {

      var { overlay } = useAppConfig()
      let entityData = ref([])
      let entityScore = ref([])

      return {
      entityData,
      entityScore,
      nrc: "",
      course: "",
      overlay,
      key1: 0,
      key2: 0,
      headers: [
        { title: 'Periodo', key: 'periodo',  cellClass:'text-xs' },
        { title: 'Fecha', key: 'fecha',  cellClass:'text-xs' },
        { title: 'Curso', key: 'curso',  cellClass:'text-xs'  },
        { title: 'Titulo', key: 'start', value: 'titulo',  cellClass:'text-xs', width: '80' },
        { title: 'NRC', key: 'nrc',  cellClass: 'text-xs'},
        { title: 'PF', key: 'nota',  cellClass:'text-xs' },
        { title: '', key: 'options',  cellClass:'text-xs' }
      ]
      }
    },
    mounted(){
      this.onSubmit()
    },
    methods: {
      loadAlert(text, type="error", title="Advertencia"){
        //this.$store.commit('appConfig/TOGGLE_SNACKBAR', {show: true, text: text, color: type})
        this.$swal.fire({
                title: title,
                text: text,
                icon: type,
                confirmButtonText: 'OK',
              })
      },
      
      onSubmit() {          
          var data = {pidm: this.pidm, termcode: this.termcode}
          this.overlay = true
          this.$http.post('counseling/nrcs', data)
          .then(response => {   

              this.entityData= response.data
              this.key1++
              this.overlay = false   
              this.$forceUpdate() 
          })
          .catch(error => {
                this.overlay = false
                this.loadAlert(error.response.data.message)
          })

      },
      selectRow(i){
        this.nrc = i.value.nrc
        this.course = i.value.curso
        var data = {pidm: this.pidm, termcode: i.value.periodo, nrc: i.value.nrc}
        this.overlay = true 
        this.entityScore = []
        this.key2++
        this.$http.post('counseling/score', data)
        .then(response => {   
            this.entityScore= response.data
            this.key2++
            this.overlay = false   
            this.$forceUpdate() 
        })
        .catch(error => {
              this.overlay = false
              this.loadAlert(error.response.data.message)
        })
      }
    },
  }
</script>
<style>

  .row-pointer:hover {
    cursor: pointer;
  }

  </style>