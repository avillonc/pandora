<template>
  <div>
  <v-row><v-spacer></v-spacer>
    <v-col cols="12"
    align="center"
           sm="3">
      <v-dialog
          v-model="dialog"
          max-width="500px"
        >
          <template v-slot:activator="{ props }">
            <v-btn
              color="success"
              dark
              class="mb-2"
              v-bind="props"
            >
              Agregar Obs.
            </v-btn>
          </template>
          <v-form ref="form"
          v-model="valid"
          @submit="onSubmit" 
          @submit.prevent="validate">
          <v-card>
            <v-card-title>
              <span class="text-h5">{{ formTitle }}</span>
            </v-card-title>

            <v-card-text>
              <v-container>
                <v-row>
                  <v-col
                    cols="12"
                    md="12"
                  >
                    <v-autocomplete
                      label="Tipo contacto"
                      v-model="entityData.code"
                      variant="outlined"
                      density="compact"
                      :items="types"
                      item-title="dec"
                      item-value="tipo"
                      :menu-props="{ offsetY: true }"
                      hide-details="auto"
                      :rules="[validators.required]"
                    ></v-autocomplete>
                  </v-col>
                  <v-col
                    cols="12"
                    md="12"
                  >
                    <v-textarea
                      solo
                      v-model="entityData.obs"
                      label="Observación"
                      rows = 8
                      :rules="[validators.required, validators.maxlengthValidator(entityData.obs, 4000)]"
                    ></v-textarea>
                  </v-col>
                  
                </v-row>
              </v-container>
            </v-card-text>

            <v-card-actions v-if="entityData.id == undefined">
              <v-spacer></v-spacer>
              <v-btn
                color="error"
                text
                @click="close"
              >
                Cerrar
              </v-btn>
              <v-btn
                color="success"
                type="submit"
                variant="tonal"
              >
                Guardar
              </v-btn>
            </v-card-actions>
          </v-card>
          </v-form>
  </v-dialog>
  </v-col>
  </v-row>
  <u-c-data-table-options 
        :key="tableKey"
        :items="items"
        :headers="headers"
        :search="search"
        itemKey="id"
        :canEdit="false"
        :canSee="true"
        :canDelete="false"
        :isTable="false"
        sortBy="id"
        :itemsPage="5"
        @see="editItem">
  </u-c-data-table-options>
  </div>
</template>

<script>
  import UCDataTableOptions from '@/components/UCDataTableOptions.vue'
import useAppConfig from '@core/@app-config/useAppConfig'
import { maxlengthValidator, required } from '@core/utils/validation.js'
import { ref } from 'vue'

  export default {
    components: {
      UCDataTableOptions
    },
    props: {
      items: {
        type: Array,
        required: true,
      },
      types: {
        type: Array,
        required: true,
      },
      pidm : {
        type: String,
        required: true
      }
    },
    setup() {

      var { overlay } = useAppConfig()
      const valid = ref(false)
      const form = ref(null)
      const validate = () => {
        form.value.validate()
      }
  
      const resetValidation = ()=> {
        form.value.resetValidation()
      }

      let entityData = ref({})
  
      return {
        validators: { required,
        maxlengthValidator  },
        valid,
        form,
        validate,
        resetValidation,
        overlay,
        entityData
      }
    },
    data: () => ({
      dialog: false,
      headers: [
        {
          title: 'Fecha',
          align: 'start',
          sortable: false,
          key: 'fecha',
        },
        { title: 'Rubro', key: 'rubro', sortable: false, Class:'text-sm' },
        { title: 'Usuario', key: 'usuario', sortable: false, cellClass:'text-xs'  },
        { title: 'Tipo', key: 'tipo', sortable: false, cellClass:'text-xs', width: '50px'  },
        { title: 'Observación', key: 'obs', sortable: false, align:'justify', width: '200px'},
        { title: '', key: 'options', sortable: false, cellClass:'text-xs' },
      ],
      editedIndex: -1,
      tableKey: 1,
      search: '',
      validators: { required, maxlengthValidator},
    }),

    computed: {
      formTitle () {
        return this.entityData.id == undefined ? 'Nueva Observación' : 'Ver Observación'
      },
    },

    watch: {
      dialog (val) {
        val || this.close()
      },
    },

    methods: {
      loadAlert(text, type="error", title="Advertencia"){
        //this.$store.commit('appConfig/TOGGLE_SNACKBAR', {show: true, text: text, color: type})
        this.$swal.fire({
                title: title,
                text: text,
                icon: type,
                confirmButtonText: 'OK',
              })
      },
      editItem (item) {
        this.entityData = item.raw
        this.dialog = true
      },

      close () {
        this.dialog = false
        this.entityData = {}
        this.resetValidation()
      },

      onSubmit () {
        if (!this.valid) {
          return
        }
          
          this.overlay = true
          this.entityData.pidm = this.pidm
          this.$http.post('counseling/observations', this.entityData)
          .then(response => {   
              this.close ()        
              this.overlay = false  
              this.$emit('reload-observ')     
              this.loadAlert('Observación registrada Correctamente', 'success', 'Éxito')     
          })
          .catch(error => {
                this.overlay = false
                this.loadAlert(error.response.data.message)
          })
      },
    },
  }
</script>
<style type="text/css">


</style>