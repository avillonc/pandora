<template>
  <v-card-text class="mt-5">
        <v-form ref="form"
          v-model="valid"
          @submit="onSubmit" 
          @submit.prevent="validate"
          > 
          <v-row>
            <input type="hidden" v-model="valueSelected.spriden_pidm"> 
            <v-col cols="12" md="3" >
              <v-text-field
                label="ID"
                name="id"
                id="id"
                v-model="valueSelected.spriden_id"
                outlined
                readonly
                variant="solo-filled"
                density="compact"
                hide-details="auto"
              ></v-text-field>
            </v-col>
            <v-col cols="12" md="3">
              <v-text-field
                label="First name"
                v-model="valueSelected.first_name"
                outlined
                readonly
                variant="solo-filled"
                density="compact"
                hide-details="auto"
              ></v-text-field>
            </v-col> 
            <v-col cols="12" md="3" >
              <v-text-field
                label="Last name"
                v-model="valueSelected.last_name"
                outlined
                readonly
                variant="solo-filled"
                density="compact"
                hide-details="auto"
              ></v-text-field>
            </v-col>
            <v-col cols="12" md="3" >
              <v-text-field
                label="Género"
                v-model="valueSelected.sex"
                outlined
                readonly
                variant="solo-filled"
                density="compact"
                hide-details="auto"
              ></v-text-field>
            </v-col>
          </v-row>
          <v-row>
            <v-col cols="12" md="3" >
              <v-text-field
                label="Fecha Inscripción"
                v-model="valueSelected.entry_date"
                outlined
                readonly
                variant="solo-filled"
                density="compact"
                hide-details="auto"
              ></v-text-field>
            </v-col>
            <v-col cols="12" md="3">
              <v-text-field
                label="Programa"
                v-model="valueSelected.program_title"
                outlined
                readonly
                variant="solo-filled"
                density="compact"
                hide-details="auto"
              ></v-text-field>
            </v-col> 
            <v-col cols="12" md="3" >
              <v-text-field
                label="Semestre"
                v-model="valueSelected.term_code"
                outlined
                readonly
                variant="solo-filled"
                density="compact"
                hide-details="auto"
              ></v-text-field>
            </v-col>
            <!--<v-col cols="12" md="3" >
              <v-text-field
                label="Proveniencia"
                v-model="valueSelected.email"
                outlined
                readonly
                variant="solo-filled"
                density="compact"
                hide-details="auto"
              ></v-text-field>
            </v-col>-->
            <v-col cols="12" md="3" >
              <v-text-field
                label="Categoría"
                v-model="valueSelected.categ"
                outlined
                readonly
                variant="solo-filled"
                density="compact"
                hide-details="auto"
              ></v-text-field>
            </v-col>
          </v-row>
          <v-row>
            <v-col cols="12" md="3" >
              <v-text-field
                label="Tipo"
                v-model="valueSelected.subcate"
                outlined
                readonly
                variant="solo-filled"
                density="compact"
                hide-details="auto"
              ></v-text-field>
            </v-col>
            <v-col cols="12" md="3" >
              <v-text-field
                label="Estatus EA"
                v-model="valueSelected.ea_status_lbl"
                outlined
                readonly
                variant="solo-filled"
                density="compact"
                hide-details="auto"
              ></v-text-field>
            </v-col>
          </v-row>
          <v-row>
              <v-col cols="12"> <v-divider></v-divider></v-col>
          </v-row>
          <!--
          <v-row>
              <v-col cols="12"> <h4>Estatus</h4></v-col>
          </v-row>  -->
          <v-row>
              <v-col cols="12" md="3" >
                  <v-select
                      label="Estado "
                      v-model="valueSelected.estado_gene"
                      outlined
                      density="compact"
                      :items="estados_gen"
                      item-title="text"
                      item-value="id"
                      :menu-props="{ offsetY: true }"
                      hide-details="auto"
                      ></v-select>
              </v-col>
          </v-row>
          <v-row>
              <v-col cols="12" md="3" >
                  <v-select
                      label="Solicitud de requisitos"
                      v-model="valueSelected.solicitud_req"
                      outlined
                      density="compact"
                      :items="estados"
                      item-title="text"
                      item-value="id"
                      :menu-props="{ offsetY: true }"
                      hide-details="auto"
                      ></v-select>
              </v-col>
              <v-col cols="12" md="3" >
                  <v-select
                      label="Reunión realizada"
                      v-model="valueSelected.reunion"
                      outlined
                      density="compact"
                      :items="estados"
                      item-title="text"
                      item-value="id"
                      :menu-props="{ offsetY: true }"
                      hide-details="auto"
                      ></v-select>
              </v-col>
              <v-col cols="12" md="3" >
                  <v-select
                      label="Documentos completos"
                      v-model="valueSelected.docs_compl"
                      outlined
                      density="compact"
                      :items="estados"
                      item-title="text"
                      item-value="id"
                      :menu-props="{ offsetY: true }"
                      hide-details="auto"
                      ></v-select>
              </v-col>
              <v-col cols="12" md="3" >
                  <v-select
                      label="EA generado"
                      v-model="valueSelected.ea_gen"
                      outlined
                      density="compact"
                      readonly
                      variant="solo-filled"
                      :items="estados"
                      item-title="text"
                      item-value="id"
                      :menu-props="{ offsetY: true }"
                      hide-details="auto"
                      ></v-select>
              </v-col>
          </v-row>
          <v-row>
              <v-col cols="12" md="3" >
                  <v-select 
                      label="EA firmado"
                      v-model="valueSelected.ea_firm"
                      outlined
                      readonly
                      variant="solo-filled"
                      density="compact"
                      :items="estados"
                      item-title="text"
                      item-value="id"
                      :menu-props="{ offsetY: true }"
                      hide-details="auto"
                      ></v-select>
              </v-col>
              <v-col cols="12" md="3" >
                  <v-select
                      label="Homologación en proceso"
                      v-model="valueSelected.homolg_proc"
                      outlined
                      density="compact"
                      :items="estados"
                      item-title="text"
                      item-value="id"
                      :menu-props="{ offsetY: true }"
                      hide-details="auto"
                      ></v-select>
              </v-col>
              <v-col cols="12" md="3" >
                  <v-select
                      label="Homologación finalizada"
                      v-model="valueSelected.homolg_fin"
                      outlined
                      density="compact"
                      :items="estados"
                      item-title="text"
                      item-value="id"
                      :menu-props="{ offsetY: true }"
                      hide-details="auto"
                      ></v-select>
              </v-col>
              <v-col cols="12" md="3" >
                  <v-select
                      label="Algo pendiente"
                      v-model="valueSelected.algo_pendiente"
                      outlined
                      density="compact"
                      :items="estados"
                      item-title="text"
                      item-value="id"
                      :menu-props="{ offsetY: true }"
                      hide-details="auto"
                      ></v-select>
              </v-col> 
              <v-col cols="12" md="6" >
                  <v-text-field
                  label="Universidad"
                  v-model="valueSelected.universidad"
                  outlined                    
                  density="compact"
                  hide-details="auto"
                  ></v-text-field>
              </v-col>
          </v-row>
          <v-row class="mb-0">
              <v-col cols="12" > <h4>Comentarios</h4></v-col>
          </v-row> 
          <v-row class="mt-0">
              <v-col
                  cols="12"
                  md="12" 
                >
                  <v-textarea
                    solo
                    density="compact"
                    v-model="valueSelected.comentarios1"
                    label="Comentarios"
                    rows = 3
                  ></v-textarea>
                </v-col>
          </v-row>
          <v-row class="mt-0 pt-0">
              <v-col cols="12"> <h4>Información adicional</h4></v-col>
          </v-row> 
          <v-row>
              <v-col cols="12" md="3" >
                  <v-select
                      label="DNI-ID"
                      v-model="valueSelected.dniid"
                      outlined
                      density="compact"
                      :items="estados"
                      item-title="text"
                      item-value="id"
                      :menu-props="{ offsetY: true }"
                      hide-details="auto"
                      ></v-select>
              </v-col>
              <v-col cols="12" md="3" >
                  <v-select
                      label="Titulo / Diploma"
                      v-model="valueSelected.titdiploma"
                      outlined
                      density="compact"
                      :items="estados"
                      item-title="text"
                      item-value="id"
                      :menu-props="{ offsetY: true }"
                      hide-details="auto"
                      ></v-select>
              </v-col>
              <v-col cols="12" md="3" >
                  <v-select
                      label="Calificaciones"
                      v-model="valueSelected.calif"
                      outlined
                      density="compact"
                      :items="estados"
                      item-title="text"
                      item-value="id"
                      :menu-props="{ offsetY: true }"
                      hide-details="auto"
                      ></v-select>
              </v-col>
              <v-col cols="12" md="3" >
                  <v-select
                      label="Recomendaciones"
                      v-model="valueSelected.recomend"
                      outlined
                      density="compact"
                      :items="estados"
                      item-title="text"
                      item-value="id"
                      :menu-props="{ offsetY: true }"
                      hide-details="auto"
                      ></v-select>
              </v-col>
          </v-row>
          <v-row>
              <v-col cols="12" md="3" >
                  <v-select
                      label="Curriculum Vitae"
                      v-model="valueSelected.cv"
                      outlined
                      density="compact"
                      :items="estados"
                      item-title="text"
                      item-value="id"
                      :menu-props="{ offsetY: true }"
                      hide-details="auto"
                      ></v-select>
              </v-col>
              <v-col cols="12" md="3" >
                  <v-select
                      label="Calificaciones oficiales"
                      v-model="valueSelected.califofic"
                      outlined
                      density="compact"
                      :items="estados"
                      item-title="text"
                      item-value="id"
                      :menu-props="{ offsetY: true }"
                      hide-details="auto"
                      ></v-select>
              </v-col>
              <v-col cols="12" md="3" >
                  <v-select
                      label="Evaluación / reporte recibido"
                      v-model="valueSelected.evareprecib"
                      outlined
                      density="compact"
                      :items="estados"
                      item-title="text"
                      item-value="id"
                      :menu-props="{ offsetY: true }"
                      hide-details="auto"
                      ></v-select>
              </v-col> 
              <v-col cols="12" md="3" >
                  <v-select
                      label="Convalidación de créditos"
                      v-model="valueSelected.convcredits"
                      outlined
                      density="compact"
                      :items="estados"
                      item-title="text"
                      item-value="id"
                      :menu-props="{ offsetY: true }"
                      hide-details="auto"
                      ></v-select>
              </v-col> 
          </v-row>
          <v-row justify='end'>
              <v-col cols="12" md="3">
              <v-btn  block color="success" type="submit">
                  <v-icon
                  left
                  dark
                  icon="mdi-content-save"
                  >
                  </v-icon>
                  Guardar información
              </v-btn>
              </v-col>
        </v-row>
        </v-form>
  </v-card-text>
</template>

<script>
import useAppConfig from '@core/@app-config/useAppConfig'
import { required } from '@core/utils/validation.js'
import { ref } from 'vue'

export default {

  props: {
    valueSelected: {
      type: Object,
      required: true,
    },
  },
  setup() {
    var { overlay } = useAppConfig()
    const valid = ref(false)
    const form = ref(null)
    const validate = () => {
      form.value.validate()
    }

    return {
      valid,
      form,
      validate,
      validators: { required},
      estados: [{id: 1, text: 'SI'}, {id: 2, text: 'NO'}, {id: 3, text:'NO APLICA'}],
      estados_gen: [
          {id: 1, text: 'Pagado'}, 
          {id: 0, text: 'Pendiente de pago'}, 
          {id: 2, text:'Postergado'},
          {id: 3, text:'Admisión portergada'},
          {id: 4, text:'Retirados'},
      ],
      eaStatus: {
                null: 'No Generado',
                1: 'Enviado',
                2: 'Firmado'
              },
      overlay,
      checked: false
    }
  },

  data: () => ({
      tableKey: 1,
      validators: { required},
    }),

  beforeMount(){
    this.initialize()      
    this.valueSelected.ea_status_lbl = this.eaStatus[this.valueSelected.ea_status]
    //alert(this.valueSelected.ea_status_lbl)
//console.log(this.valueSelected.solicitud_req)

  },
  
  methods: {
    initialize() {
       
      
      this.valueSelected.solicitud_req = (this.valueSelected.solicitud_req == null|| isNaN(this.valueSelected.solicitud_req)) ? '' : parseInt(this.valueSelected.solicitud_req) 
      this.valueSelected.reunion = (this.valueSelected.reunion == null || isNaN(this.valueSelected.reunion)) ? '' : parseInt(this.valueSelected.reunion)
      this.valueSelected.docs_compl = (this.valueSelected.docs_compl == null|| isNaN(this.valueSelected.docs_compl)) ? '' : parseInt(this.valueSelected.docs_compl)
      this.valueSelected.ea_gen = (this.valueSelected.ea_gen == null|| isNaN(this.valueSelected.ea_gen)) ? '' : parseInt(this.valueSelected.ea_gen)
      this.valueSelected.ea_firm = (this.valueSelected.ea_firm == null|| isNaN(this.valueSelected.ea_firm)) ? '' : parseInt(this.valueSelected.ea_firm)
      this.valueSelected.homolg_fin = (this.valueSelected.homolg_fin == null|| isNaN(this.valueSelected.homolg_fin)) ? '' : parseInt(this.valueSelected.homolg_fin)
      this.valueSelected.homolg_proc = (this.valueSelected.homolg_proc == null|| isNaN(this.valueSelected.homolg_proc)) ? '' : parseInt(this.valueSelected.homolg_proc)
      
      this.valueSelected.algo_pendiente = (this.valueSelected.algo_pendiente == null|| isNaN(this.valueSelected.algo_pendiente)) ? '' : parseInt(this.valueSelected.algo_pendiente)
      this.valueSelected.dniid = (this.valueSelected.dniid == null|| isNaN(this.valueSelected.dniid)) ? '' : parseInt(this.valueSelected.dniid)
      this.valueSelected.titdiploma = (this.valueSelected.titdiploma == null|| isNaN(this.valueSelected.titdiploma)) ? '' : parseInt(this.valueSelected.titdiploma)
      this.valueSelected.calif = (this.valueSelected.calif == null|| isNaN(this.valueSelected.calif)) ? '' : parseInt(this.valueSelected.calif)
      this.valueSelected.recomend = (this.valueSelected.recomend == null|| isNaN(this.valueSelected.recomend)) ? '' : parseInt(this.valueSelected.recomend)
      this.valueSelected.cv = (this.valueSelected.cv == null|| isNaN(this.valueSelected.cv)) ? '' : parseInt(this.valueSelected.cv)
      this.valueSelected.califofic = (this.valueSelected.califofic == null|| isNaN(this.valueSelected.califofic)) ? '' : parseInt(this.valueSelected.califofic)
      this.valueSelected.convcredits = (this.valueSelected.convcredits == null|| isNaN(this.valueSelected.convcredits)) ? '' : parseInt(this.valueSelected.convcredits)
      this.valueSelected.evareprecib = (this.valueSelected.evareprecib == null|| isNaN(this.valueSelected.evareprecib)) ? '' : parseInt(this.valueSelected.evareprecib)
      this.valueSelected.estado_gene = (this.valueSelected.estado_gene == null|| isNaN(this.valueSelected.estado_gene)) ? '' : parseInt(this.valueSelected.estado_gene)
      //alert(this.valueSelected.reunion)
      //console.log((this.valueSelected.dniid) ? '' : parseInt(this.valueSelected.dniid))
      //console.log(this.valueSelected.solicitud_req)
      console.log(this.valueSelected.reunion)
      
      
      window.scrollTo({ top: 0, behavior: 'smooth' });
      
      this.overlay = false

    },

    regresar(){
      this.$emit('on-backward')
    },
    loadAlert(text, type="error", title="Advertencia"){
      this.$swal.fire({
              title: title,
              text: text,
              icon: type,
              confirmButtonText: 'OK',
            }).then((result) => {
              if (result.isConfirmed) {
                
              }
            })
    },
    onSubmit(){
      //this.validate()
      //console.log(this.valid)
     // return
      /*if (!this.valid) {
        alert("1")
          return
        }
        alert("2")*/
      this.overlay = true
      //this.entityData.pidm = this.valueSelected.pidm
      this.$http.post('dailystatus/save', this.valueSelected)
      .then(response => {   
          //this.close ()        
          this.overlay = false  
          this.loadAlert('Datos registrados Correctamente', 'success', 'Éxito')  
          this.$emit('on-backward')
          window.scrollTo({ top: 0, behavior: 'smooth' });  
      })
      .catch(error => {
            this.overlay = false
            this.loadAlert(error.response.data.message)
      })
      /*this.overlay = true
      
      if (this.valid) {
          this.overlay = true
          this.$http.post('dailystatus/save', this.valueSelected)
              .then(response => {
                  this.loadAlert(response.data.mensaje, 'success', 'Éxito')
                  window.scrollTo({ top: 0, behavior: 'smooth' });
                  this.overlay = false
                  
                  
              }).catch(function(err){
                  if(err.response.status == 422) {                  
                  this.loadAlert('Elegir al menos un program schedule');
                  this.overlay = false
                  
                  
                  }
              });

      } else {
          this.overlay = false
          this.validate()
          this.loadAlert('Tiene campos incompletos');
          let elementsInErrors = document.getElementsByClassName('error--text');
          if (elementsInErrors && elementsInErrors.length > 0) {
              elementsInErrors[0].scrollIntoView({ behavior: 'smooth', block: 'center' });
          }
      }*/
    },
  }
}
</script>
