
<template>
  <div class="text-sm">
    <v-card-text class="my-6">
      <v-row>
        <v-col
          cols="12"
          md="6"
        >
        <span>Total de Registros: {{itemTotal}}</span>
          </v-col>
        <v-spacer></v-spacer>
      </v-row>
    </v-card-text>
    <v-data-table-server
      class="pb-4"
      density="compact"
      :headers="headers"
      :items="items"
      :loading="isLoading"
      :page="page"
      :items-per-page="itemsPerPage"
      items-per-page-text="Items por Página"
      :search="search"
      no-data-text="No hay datos para mostrar"
      hide-default-footer
      :items-length="itemTotal"
      @update:itemsPerPage="changeItemPerPage"
      @update:page="changePage"
      @click:row="selectRow"
    >

      <template v-slot:header="{ props: { headers } }">
        <thead>
          <tr>
            <th v-for="h in headers" v-bind:key="h.title">
             <v-tooltip bottom>
              <template v-slot:activator="{ on }">
                <span v-on="on">{{h}}</span>
              </template>
              <span>{{h}}</span>
            </v-tooltip>
            </th>
          </tr>
        </thead>
      </template>

        <template #[`item.full_name`]="{item}">
          <slot name="nombres">
              <span class="text-primary">{{item.value.full_name}}</span>
          </slot>
        </template>

        <template #[`item.solicitud_req`]="{item}">
          <v-tooltip location="top"  >
            <template v-slot:activator="{ on, props }">
              <v-chip v-bind="props" v-on="on" v-if="item.value.solicitud_req!=null" 
                small
                :color="flgStatusColor[item.value.solicitud_req]"
                :class="`${flgStatusColor[item.value.solicitud_req]}--text`"
                class="v-chip-light-bg row-pointer"
              >
                {{ flgStatus[item.value.solicitud_req] }}
              </v-chip>
            </template>
            <span v-if="item.value.solicitud_usr_updated!=null">Actualizado por: <strong>{{item.value.solicitud_usr_updated}}</strong><br></span>
            <span v-if="item.value.solicitud_updated!=null">Fecha de actualizacion: <strong>{{item.value.solicitud_updated}}</strong></span>
          </v-tooltip>
        </template>  
        
        <template #[`item.reunion`]="{item}">
          <v-tooltip location="top"  >
            <template v-slot:activator="{ on, props }">
              <v-chip v-bind="props" v-on="on" v-if="item.value.reunion!=null" 
                small
                :color="flgStatusColor[item.value.reunion]"
                :class="`${flgStatusColor[item.value.reunion]}--text`"
                class="v-chip-light-bg row-pointer"
              >
                {{ flgStatus[item.value.reunion] }}
              </v-chip>
            </template>
            <span v-if="item.value.reunion_usr_updated!=null">Actualizado por: <strong>{{item.value.reunion_usr_updated}}</strong><br></span>
            <span v-if="item.value.reunion_updated!=null">Fecha de actualizacion: <strong>{{item.value.reunion_updated}}</strong></span>
          </v-tooltip>
        </template>     
      
        <template #[`item.docs_compl`]="{item}">
          <v-tooltip location="top"  >
            <template v-slot:activator="{ on, props }">
              <v-chip v-bind="props" v-on="on" v-if="item.value.docs_compl!=null" 
                small
                :color="flgStatusColor[item.value.docs_compl]"
                :class="`${flgStatusColor[item.value.docs_compl]}--text`"
                class="v-chip-light-bg row-pointer"
              >
                {{ flgStatus[item.value.docs_compl] }}
              </v-chip>
            </template>
            <span v-if="item.value.docs_usr_updated!=null">Actualizado por: <strong>{{item.value.docs_usr_updated}}</strong><br></span>
            <span v-if="item.value.docs_updated!=null">Fecha de actualizacion: <strong>{{item.value.docs_updated}}</strong></span>
          </v-tooltip>
        </template>  
        <!---->

        <template #[`item.ea_gen`]="{item}">
          <v-chip
            small
            :color="flgStatusColor[item.value.ea_gen]"
            :class="`${flgStatusColor[item.value.ea_gen]}--text`"
            class="v-chip-light-bg row-pointer"
          >
            {{ flgStatus[item.value.ea_gen] }}
          </v-chip>
        </template>

        <template #[`item.ea_firm`]="{item}">
          <v-chip
            small
            :color="flgStatusColor[item.value.ea_firm]"
            :class="`${flgStatusColor[item.value.ea_firm]}--text`"
            class="v-chip-light-bg row-pointer"
          >
            {{ flgStatus[item.value.ea_firm] }}
          </v-chip>
        </template>
        
        <template #[`item.homolg_proc`]="{item}">
          <v-tooltip location="top"  >
            <template v-slot:activator="{ on, props }">
              <v-chip v-bind="props" v-on="on" v-if="item.value.homolg_proc!=null" 
                small
                :color="flgStatusColor[item.value.homolg_proc]"
                :class="`${flgStatusColor[item.value.homolg_proc]}--text`"
                class="v-chip-light-bg row-pointer"
              >
                {{ flgStatus[item.value.homolg_proc] }}
              </v-chip>
            </template>
            <span v-if="item.value.homolg_proc_usr_updated!=null">Actualizado por: <strong>{{item.value.homolg_proc_usr_updated}}</strong><br></span>
            <span v-if="item.value.homolg_proc_updated!=null">Fecha de actualizacion: <strong>{{item.value.homolg_proc_updated}}</strong></span>
          </v-tooltip>
        </template>  

        

        <template #[`item.homolg_fin`]="{item}">
          <v-tooltip location="top"  >
            <template v-slot:activator="{ on, props }">
              <v-chip v-bind="props" v-on="on" v-if="item.value.homolg_fin!=null" 
                small
                :color="flgStatusColor[item.value.homolg_fin]"
                :class="`${flgStatusColor[item.value.homolg_fin]}--text`"
                class="v-chip-light-bg row-pointer"
              >
                {{ flgStatus[item.value.homolg_fin] }}
              </v-chip>
            </template>
            <span v-if="item.value.homolg_fin_usr_updated!=null">Actualizado por: <strong>{{item.value.homolg_fin_usr_updated}}</strong><br></span>
            <span v-if="item.value.homolg_fin_updated!=null">Fecha de actualizacion: <strong>{{item.value.homolg_fin_updated}}</strong></span>
          </v-tooltip>
        </template>  


        <template #[`item.dniid`]="{item}">
          <v-tooltip location="top"  >
            <template v-slot:activator="{ on, props }">
              <v-chip v-bind="props" v-on="on" v-if="item.value.dniid!=null" 
                small
                :color="flgStatusColor[item.value.dniid]"
                :class="`${flgStatusColor[item.value.dniid]}--text`"
                class="v-chip-light-bg row-pointer"
              >
                {{ flgStatus[item.value.dniid] }}
              </v-chip>
            </template>
            <span v-if="item.value.dniid_usr_updated!=null">Actualizado por: <strong>{{item.value.dniid_usr_updated}}</strong><br></span>
            <span v-if="item.value.dniid_updated!=null">Fecha de actualizacion: <strong>{{item.value.dniid_updated}}</strong></span>
          </v-tooltip>
        </template>  

        <template #[`item.titdiploma`]="{item}">
          <v-tooltip location="top"  >
            <template v-slot:activator="{ on, props }">
              <v-chip v-bind="props" v-on="on" v-if="item.value.titdiploma!=null" 
                small
                :color="flgStatusColor[item.value.titdiploma]"
                :class="`${flgStatusColor[item.value.titdiploma]}--text`"
                class="v-chip-light-bg row-pointer"
              >
                {{ flgStatus[item.value.titdiploma] }}
              </v-chip>
            </template>
            <span v-if="item.value.titdiploma_usr_updated!=null">Actualizado por: <strong>{{item.value.titdiploma_usr_updated}}</strong><br></span>
            <span v-if="item.value.titdiploma_updated!=null">Fecha de actualizacion: <strong>{{item.value.titdiploma_updated}}</strong></span>
          </v-tooltip>
        </template>  


        <template #[`item.calif`]="{item}">
          <v-tooltip location="top"  >
            <template v-slot:activator="{ on, props }">
              <v-chip v-bind="props" v-on="on" v-if="item.value.calif!=null" 
                small
                :color="flgStatusColor[item.value.calif]"
                :class="`${flgStatusColor[item.value.calif]}--text`"
                class="v-chip-light-bg row-pointer"
              >
                {{ flgStatus[item.value.calif] }}
              </v-chip>
            </template>
            <span v-if="item.value.calif_usr_updated!=null">Actualizado por: <strong>{{item.value.calif_usr_updated}}</strong><br></span>
            <span v-if="item.value.calif_updated!=null">Fecha de actualizacion: <strong>{{item.value.calif_updated}}</strong></span>
          </v-tooltip>
        </template>  

        <template #[`item.recomend`]="{item}">
          <v-tooltip location="top"  >
            <template v-slot:activator="{ on, props }">
              <v-chip v-bind="props" v-on="on" v-if="item.value.recomend!=null" 
                small
                :color="flgStatusColor[item.value.recomend]"
                :class="`${flgStatusColor[item.value.recomend]}--text`"
                class="v-chip-light-bg row-pointer"
              >
                {{ flgStatus[item.value.recomend] }}
              </v-chip>
            </template>
            <span v-if="item.value.recomend_usr_updated!=null">Actualizado por: <strong>{{item.value.recomend_usr_updated}}</strong><br></span>
            <span v-if="item.value.recomend_updated!=null">Fecha de actualizacion: <strong>{{item.value.recomend_updated}}</strong></span>
          </v-tooltip>
        </template>  

        <template #[`item.cv`]="{item}">
          <v-tooltip location="top"  >
            <template v-slot:activator="{ on, props }">
              <v-chip v-bind="props" v-on="on" v-if="item.value.cv!=null" 
                small
                :color="flgStatusColor[item.value.cv]"
                :class="`${flgStatusColor[item.value.cv]}--text`"
                class="v-chip-light-bg row-pointer"
              >
                {{ flgStatus[item.value.cv] }}
              </v-chip>
            </template>
            <span v-if="item.value.cv_usr_updated!=null">Actualizado por: <strong>{{item.value.cv_usr_updated}}</strong><br></span>
            <span v-if="item.value.cv_updated!=null">Fecha de actualizacion: <strong>{{item.value.cv_updated}}</strong></span>
          </v-tooltip>
        </template>  

        <template #[`item.califofic`]="{item}">
          <v-tooltip location="top"  >
            <template v-slot:activator="{ on, props }">
              <v-chip v-bind="props" v-on="on" v-if="item.value.califofic!=null" 
                small
                :color="flgStatusColor[item.value.califofic]"
                :class="`${flgStatusColor[item.value.califofic]}--text`"
                class="v-chip-light-bg row-pointer"
              >
                {{ flgStatus[item.value.califofic] }}
              </v-chip>
            </template>
            <span v-if="item.value.califofic_usr_updated!=null">Actualizado por: <strong>{{item.value.califofic_usr_updated}}</strong><br></span>
            <span v-if="item.value.califofic_updated!=null">Fecha de actualizacion: <strong>{{item.value.califofic_updated}}</strong></span>
          </v-tooltip>
        </template>  

        <template #[`item.evareprecib`]="{item}">
          <v-tooltip location="top"  >
            <template v-slot:activator="{ on, props }">
              <v-chip v-bind="props" v-on="on" v-if="item.value.evareprecib!=null" 
                small
                :color="flgStatusColor[item.value.evareprecib]"
                :class="`${flgStatusColor[item.value.evareprecib]}--text`"
                class="v-chip-light-bg row-pointer"
              >
                {{ flgStatus[item.value.evareprecib] }}
              </v-chip>
            </template>
            <span v-if="item.value.evareprecib_usr_updated!=null">Actualizado por: <strong>{{item.value.evareprecib_usr_updated}}</strong><br></span>
            <span v-if="item.value.evareprecib_updated!=null">Fecha de actualizacion: <strong>{{item.value.evareprecib_updated}}</strong></span>
          </v-tooltip>
        </template>  
        

        <template #[`item.convcredits`]="{item}">
          <v-tooltip location="top"  >
            <template v-slot:activator="{ on, props }">
              <v-chip v-bind="props" v-on="on" v-if="item.value.convcredits!=null" 
                small
                :color="flgStatusColor[item.value.convcredits]"
                :class="`${flgStatusColor[item.value.convcredits]}--text`"
                class="v-chip-light-bg row-pointer"
              >
                {{ flgStatus[item.value.convcredits] }}
              </v-chip>
            </template>
            <span v-if="item.value.convcredits_usr_updated!=null">Actualizado por: <strong>{{item.value.convcredits_usr_updated}}</strong><br></span>
            <span v-if="item.value.convcredits_updated!=null">Fecha de actualizacion: <strong>{{item.value.convcredits_updated}}</strong></span>
          </v-tooltip>
        </template>  

        <template #[`item.algo_pendiente`]="{item}">
          <v-tooltip location="top"  >
            <template v-slot:activator="{ on, props }">
              <v-chip v-bind="props" v-on="on" v-if="item.value.algo_pendiente!=null" 
                small
                :color="flgStatusColor[item.value.algo_pendiente]"
                :class="`${flgStatusColor[item.value.algo_pendiente]}--text`"
                class="v-chip-light-bg row-pointer"
              >
                {{ flgStatus[item.value.algo_pendiente] }}
              </v-chip>
            </template>
            <span v-if="item.value.algo_pendiente_usr_updated!=null">Actualizado por: <strong>{{item.value.algo_pendiente_usr_updated}}</strong><br></span>
            <span v-if="item.value.algo_pendiente_updated!=null">Fecha de actualizacion: <strong>{{item.value.algo_pendiente_updated}}</strong></span>
          </v-tooltip>
        </template>  

        <template #[`item.entry_date`]="{item}">
           {{ formatDate(item.value.effective_date) }}
        </template>

        <template #[`item.estado_gene`]="{item}">
          {{ status[item.value.estado_gene] }}
        </template>
    </v-data-table-server>
  </div>
</template>
<script>
import useAppConfig from '@core/@app-config/useAppConfig';
import { required, requiredObject } from '@core/utils/validation.js';
import moment from 'moment';
import { ref } from 'vue';

export default {
  props: {
    items: {
      type: Array,
      required: true
    },
    isLoading: {
      type: Boolean,
      default: false,
    },
    headers: {
      type: Array,
      required: true
    },
    sortBy: {
      type: String,
      default: "id"
    },
    showSelect: {
      type: Boolean,
      default: true
    },
    nameAction: {
      type: String,
      default: 'Guardar'
    },
    search: {
      type: String,
      default: ''
    },
    itemTotal: {
      type: Number,
      default: null
    },
    itemsPage: {
      type: Number,
      default: 25
    },
    page: {
      type: Number,
      default: 1
    }
},

  setup(props) {
    const flgStatusColor = {
        1: 'primary',
        2: 'error',
        3: 'default',
      }
      const flgStatus = {
        1: 'Si',
        2: 'No',
        3: 'N/a'
      }

      const statusColor = {
        1: 'primary',
        2: 'secondary',
        3: 'default',
        4: 'secondary',
        5: 'error'
      }
      const status = {
        1: 'Pagado',
        0: 'Pendiente de pago',
        2: 'Postergado',
        3: 'Admisión postergada',
        4: 'Retirado'
      }
    const enabledColor = (value) => {
        switch (value) {
        case 'AS':
          return 'info';
        case 'RP':
          return 'error';
        case 'IS':
          return 'primary';
        default:
          return 'secondary';
      }
    }

    var { overlay } = useAppConfig()

    const valid = ref(false)
    const form = ref(null)
    const validate = () => {
      form.value.validate()
    }

    const resetValidation = ()=> {
      form.value.resetValidation()
    }

    const entityData = ref({})

    return {
      page: props.page,
      pageCount: 0,
      itemsPerPage: props.itemsPage,
      enabledColor,
      flgStatusColor,
      flgStatus,
      statusColor,
      status,
      valueSelected: {},
      msgConfirm: '',
      activemsgConfirm: false,
      msgConfirmReenvio: '',
      overlay,
      equipos: [],
      valid,
      form,
      validate,
      resetValidation,
      isDialogOpen: false,
      validators: { required, requiredObject}
    }
},
mounted(){
      //console.log(this.statusColor)
    },
  methods: {
    loadAlert(text, type="error", title="Advertencia"){
      this.$swal.fire({
              title: title,
              text: text,
              icon: type,
              confirmButtonText: 'OK',
            })
    },
    formatDate(created_at) {
        return moment(created_at).format('DD/MM/YY');
    },
    formatDateTime(fecha) {
      if(fecha==null) return ''
      return moment(fecha).format('DD/MM/YY HH:mm');
    },
    changeItemPerPage(item){
      this.valueSelected = {}
      this.$emit('item-per-page', item)
    },
    selectRow(event, row){
      this.$emit('ver-detalles',row.item.value)
    },    
    changePage(value){
      this.valueSelected = {}
      this.$emit('change-page', value)
    }
  }
}
</script>