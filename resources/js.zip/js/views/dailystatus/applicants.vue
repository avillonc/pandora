<template>
  <v-card>
    <v-card-title >
      <h4><strong>Estatus Diario de Aplicantes</strong></h4>
    </v-card-title>
    <v-toolbar flat v-if="isShowEntityActive"
        style="background: rgb(var(--v-theme-on-white))">
        <v-btn 
        variant="tonal"
        color="secondary"
        id="btnRegresar"
        class="mb-2"
        @click="createEntityOrClose"
        > 
            <v-icon left icon="mdi-arrow-left">
            </v-icon>
            Regresar
        </v-btn>
        <v-divider></v-divider>
      </v-toolbar>
      <v-divider v-if="!isShowEntityActive"></v-divider>
      <v-card-text v-if="!isShowEntityActive" class="my-4">
        <v-form ref="form"
        v-model="valid"
        @submit="onSubmit" 
        @submit.prevent="validate">
        <v-row>
              <v-col cols="12" md="4">
                <v-autocomplete
                  label="Periodo"
                  v-model="entityData.term_code"
                  outlined
                  density="compact"
                  :items="periodos"
                  item-title="period_desc"
                  item-value="period_val"
                  :menu-props="{ offsetY: true }"
                  hide-details="auto"
                  :rules="[validators.required]"
                  @change="periodoChange"
                ></v-autocomplete>
            </v-col>
            <v-col cols="12" md="4">
              <v-autocomplete
                  label="Carrera"
                  v-model="entityData.majr_code"
                  variant="outlined"
                  density="compact"
                  :items="programs"
                  item-title="name"
                  item-value="majr_code"
                  :menu-props="{ offsetY: true }"
                  hide-details="auto"
                  single-line
                  
                ></v-autocomplete>
            </v-col>
            
            <v-col
              cols="12"
              md="4"
            >
              <v-text-field
                label="ID Banner"
                v-model="entityData.idbanner"
                outlined
                density="compact"
                small
                hide-details="auto"
              ></v-text-field>
            </v-col>  

              <v-col
              cols="12"
              md="4"
              >
              <v-text-field
                  label="Apellidos"
                  v-model="entityData.last_name"
                  outlined
                  density="compact"
                  hide-details="auto"
              ></v-text-field>
              </v-col>
            <v-col
            cols="12"
            md="4"
            >
                <v-text-field
                    label="Nombres"
                    v-model="entityData.first_name"
                    outlined
                    density="compact"
                    hide-details="auto"
                ></v-text-field>
            </v-col>
          </v-row>
          <v-row>
            <v-spacer></v-spacer>
            <v-col
              cols="12"
              md="3"
              >
              <v-btn block color="success" type="button" @click="exportResult" outlined :disabled="!termSelected"> 
              <v-icon
                  left
                  dark
                  icon="mdi-file-excel"
              >
              </v-icon>
              Exportar resultados</v-btn>
            </v-col>
            <v-col
              cols="12"
              md="3"
              >
              <v-btn block color="secondary" @click="ExportTotales" :disabled="!termSelected"> 
              <v-icon
                  left
                  dark  
                  icon="mdi-file-excel"
              >
              </v-icon>
              Exportar totales</v-btn>
            </v-col>
            <v-col
              cols="12"
              md="3"
              > 
              <v-btn  block color="success" type="submit" :loading="isLoading">
                  <v-icon
                  left
                  dark
                  id="btnConsultar"
                  icon="mdi-magnify"
              >
              </v-icon>
                  Consultar
              </v-btn>
            </v-col>
          </v-row>
        </v-form>
    </v-card-text>
    <u-c-datatable v-if="!isShowEntityActive"
              class="mt-4 row-pointer"
              :items="items" 
              :key="tableKey"
              :isLoading="isLoading"
              :headers="headers"
              :itemTotal="itemTotal"
              :itemsPage="itemsPerPage"
              :page="page"
              @change-page="changePage"
              @item-per-page="changeItemPerPage"
              @ver-detalles="verDetalles"
        ></u-c-datatable>
        <applicant-form v-if="isShowEntityActive"
        :from_date="from_date"
        :to_date="to_date"
        :valueSelected="valueSelected">
        </applicant-form>
  </v-card>
</template>

<script setup>
import useAppConfig from '@core/@app-config/useAppConfig';
import { required, requiredObject } from '@core/utils/validation.js';
import moment from 'moment';
import UCDatatable from './applicants-components/AplicantsTabla.vue';
import ApplicantForm from './applicants-components/ApplicantForm.vue';

  //variables de sistema
  let { overlay } = useAppConfig()
  const $http = inject('http')
  let  validators = { required, 
    requiredObject}
  let periodos = ref([])
  let programs = ref([])
  let headers = [
    { title: 'Inscripción', key: 'entry_date', cellClass:'text-xs', width:'60px', sortable: false},
    { title: 'Nombres', key: 'full_name', filterable: true, width: '250px', cellClass:'text-xs nowrap', sortable: false},
    { title: 'Id Banner', key: 'spriden_id', filterable: true , cellClass:'text-xs', sortable: false},
    { title: 'Programa', key: 'program_title', cellClass:'text-xs font-weight-medium', align: 'center', sortable: false  },
    { title: 'Semestre', key: 'period_desc', cellClass:'text-xs font-weight-medium', sortable: false  },
    { title: 'Estado', key: 'estado_gene', filterable: true, cellClass:'text-xs font-weight-medium', align: 'center', sortable: false},
    { title: 'Categoría', key: 'categ', filterable: true, cellClass:'text-xs', align: 'center', sortable: false},
    { title: 'SubCategoría', key: 'subcate', filterable: true, cellClass:'text-xs', align: 'center', sortable: false},
    { title: 'Solicitud Req', key: 'solicitud_req', vtitle: 'SOLICITUD DE REQUISITOS',filterable: true, cellClass:'text-xs', align: 'center', sortable: false},
    { title: 'Reunión', key: 'reunion', vtitle: 'REUNIÓN REALIZADA', filterable: true, cellClass:'text-xs', align: 'center', sortable: false},
    { title: 'Docs Compl', key: 'docs_compl', vtitle: 'DOCUMENTOS COMPLETOS', filterable: true, cellClass:'text-xs', align: 'center', sortable: false},
    { title: 'EA gen', key: 'ea_gen', vtitle: 'EA GENERADO', filterable: true, cellClass:'text-xs', align: 'center', sortable: false},
    { title: 'EA firm', key: 'ea_firm', vtitle: 'EA FIRMADO', filterable: true, cellClass:'text-xs', align: 'center', sortable: false},
    { title: 'Homolog Proc', key: 'homolg_proc', vtitle: 'HOMOLOGACIÓN EN PROCESO', filterable: true, cellClass:'text-xs', align: 'center', sortable: false},
    { title: 'Homolog Fin', key: 'homolg_fin', vtitle: 'HOMOLOGACIÓN FINALIZADA', filterable: true, cellClass:'text-xs', align: 'center', sortable: false},
    { title: 'Algo Pend', key: 'algo_pendiente', vtitle: 'ALGO PENDIENTE', filterable: true, cellClass:'text-xs', align: 'center', sortable: false},
    { title: 'Dni-id', key: 'dniid', vtitle: 'DNI-ID', filterable: true, cellClass:'text-xs', align: 'center', sortable: false},
    { title: 'Tit/dipl', key: 'titdiploma', vtitle: 'TITULO/DIPLOMA', filterable: true, cellClass:'text-xs', align: 'center', sortable: false},
    { title: 'Calif', key: 'calif', vtitle: 'CALIFICACIONES', filterable: true, cellClass:'text-xs', align: 'center', sortable: false},
    { title: 'Recom', key: 'recomend', vtitle: 'RECOMENDACIONES', filterable: true, cellClass:'text-xs', align: 'center', sortable: false},
    { title: 'CV', key: 'cv', vtitle: 'CURRÍCULUM VITAE', filterable: true, cellClass:'text-xs', align: 'center', sortable: false},
    { title: 'Calif Of', key: 'califofic', vtitle: 'CALIFICACIONES OFICIALES', filterable: true, cellClass:'text-xs', align: 'center', sortable: false},
    { title: 'Eva/rep', key: 'evareprecib', vtitle: 'EVALUACIÓN REPORTE RECIBIDO', filterable: true, cellClass:'text-xs', align: 'center', sortable: false},
                              
    { title: 'Conv cred', key: 'convcredits', vtitle: 'CONVALIDACIÓN DE CRÉDITOS', filterable: true, cellClass:'text-xs', align: 'center', sortable: false},
  ]

  const valid = ref(false)
  const form = ref(null)
  let page = ref(1)
  let itemsPerPage = ref(25)
  let itemTotal = ref(0)
  let isLoading = ref(false)
  let tableKey = 0
  let itemSelected= ref({})
  let isShowEntityActive= ref(false)
  let termSelected= ref(false)
  let entityData = ref({ from_date: moment().format('YYYY-MM-DD'), 
                          to_date: moment().format('YYYY-MM-DD')})
  let items = ref([])
  let valueSelected = ref({})
  let from_date = ref()
  let to_date = ref()
  
  const validate = () => {
    form.value.validate()
  }

  const setOverlay = (value) => {
    overlay = value
  }

  function  initialize() {
    setOverlay(true)
    $http.get('/data/termcode')
        .then(response => {
          response.data.push({period_val: '2023', period_desc: 'Año 2023'});
          response.data.push({period_val: '2024', period_desc: 'Año 2024'});
          periodos.value = response.data
      
      $http.get('/data/currentTermCode')
        .then(resp => {
          entityData.value.term_code = resp.data.termcode
          setOverlay(false)
      })
    })
    getPrograms()
    setOverlay(false)
   
  }

  function  onSubmitGeneral() {
    page.value = 1
    onSubmit()
  }

  function  onSubmit() 
  {
    if (!valid.value) {
      return
    }          
    isLoading.value = true
      //items.value = []  
      entityData.value.itemsPerPage = itemsPerPage.value
      entityData.value.page = page.value          
      $http.post('dailystatus/list', entityData.value)
        .then(response => {
            if(response.data.data.length>0){
              termSelected = true
            }else{
              termSelected = false
            }
            isLoading.value = false      
            items.value = response.data.data
            itemTotal.value = Number(response.data.rows)
            tableKey++
        })
        .catch(error => {
            isLoading.value = false
        })
  }

  function periodoChange(){
    termSelected = true
  }
  function getPrograms() {
        $http.get('data/getPrograms')
        .then(response => {
            var _programs = [{majr_code: '', name: 'TODOS'}]
            response.data.forEach(async (item) => {
              _programs.push(item);
            });
            programs = _programs
            setOverlay(false)
        })
      }
  function ExportTotales(){
      window.open('/dailystatus/export-totales/?per=' + entityData.value.term_code)
    }
  function exportResult(){
      window.open('/dailystatus/export-tabla/?term_code=' + entityData.value.term_code+'&majr_code='+(entityData.value.majr_code ?? '')+'&last_name='+(entityData.value.last_name ?? '')+'&first_name='+(entityData.value.first_name ?? ''))
    }

  function changePage(pagenum){
    page.value = pagenum
    onSubmit()
  }

  function changeItemPerPage(perpage) {
    itemsPerPage.value = perpage
    page.value = 1
    onSubmit()
  }

  function createEntityOrClose(){
    valueSelected.value = {}
    isShowEntityActive.value = !isShowEntityActive.value
  }


  onBeforeMount(() => {
    initialize()
  })
  function verDetalles(selected){ 
    valueSelected.value = selected
    from_date.value = entityData.value.from_date
    to_date.value = entityData.value.to_date
    isShowEntityActive.value = true
    
  }

</script>
 
  <style>

  .row-pointer:hover {
    cursor: pointer;
  }

  </style>
  