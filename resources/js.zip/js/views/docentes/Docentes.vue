<template>
    <div>
      <v-card>
        <v-card-title >
          <h4><strong>{{ isShowEntityActive ? (modeForm==2 ? 'Nuevo Docente Harson ' : 'Datos de docente Harson')  : 'Registro de Docentes Harson'}}</strong></h4>
        </v-card-title>
        <v-toolbar flat v-if="isShowEntityActive">
          <v-btn 
          color="secondary"
          id="btnRegresar"
          class="mb-2"
          @click="createEntityOrClose"
          > 
              <v-icon left>
              {{ icons.mdiArrowLeft}}
              </v-icon>
              Regresar
          </v-btn>
          <v-divider></v-divider>
        </v-toolbar>
        <v-divider v-if="!isShowEntityActive"></v-divider>
        <v-card-text v-if="!isShowEntityActive" class="my-4">
          <v-form ref="form"
            v-model="valid"
            @submit="onSubmit" 
            @submit.prevent="validate">
            <v-row>
              <v-col
                cols="12"
                md="4"
              >
                <v-text-field
                  label="SSN"
                  v-model="entityData.ssn"
                  outlined
                  dense
                  hide-details="auto"
                ></v-text-field>
              </v-col>
              <v-col
                cols="12"
                md="4"
              >
                <v-text-field
                  label="First name"
                  v-model="entityData.first_name"
                  outlined
                  dense
                  hide-details="auto"
                ></v-text-field>
              </v-col>
              <v-col
                cols="12"
                md="4"
              >
                <v-text-field
                  label="Last name"
                  v-model="entityData.last_name"
                  outlined
                  dense
                  hide-details="auto"
                ></v-text-field>
              </v-col>          
            </v-row>
            <v-row>
              <v-spacer></v-spacer>
                  <v-col
                    cols="12"
                    md="3"
                  >
                    <v-btn block color="info" @click="exportResult" outlined> 
                    <v-icon
                      left
                      dark
                    >
                      {{icons.mdiFileExcel}}
                    </v-icon>
                    Exportar</v-btn>
                  </v-col>
                  <v-col
                    cols="12"
                    md="3"
                  > 
                    <v-btn  block color="primary" @click="showDocentesForm" >
                      <v-icon
                      left
                      dark
                      showDocentesForm
                      id="btnNuevo"
                    >
                      {{icons.mdiAccount}}
                    </v-icon>
                      Nuevo Docente
                    </v-btn>
                  </v-col>
                  <v-col
                    cols="12"
                    md="3"
                  > 
                    <v-btn block color="success" type="submit" :loading="isLoading">
                      <v-icon
                      left
                      dark
                      id="btnConsultar"
                    >
                      {{icons.mdiMagnify}}
                    </v-icon>
                      Consultar
                    </v-btn>
                  </v-col>
            </v-row>
          </v-form>
        </v-card-text>
        <UCDatatable v-if="!isShowEntityActive"
              class="mt-4"
              :key="tableKey"
              :items="items" 
              :isLoading="isLoading"
              :headers="headers"
              :itemTotal="itemTotal"
              :itemsPage="itemsPerPage"
              @show-detail-form="showDetailForm"
              @enviar-correo="enviarCorreo"
              @on-submit="onSubmit"
              @change-page="changePage"
              @item-per-page="changeItemPerPage"
        ></UCDatatable><!-- itemKey="pidm" -->
        <docentes-form v-if="isShowEntityActive"
        :entityData="itemSelected">
        </docentes-form>        
      </v-card>
    </div>
  </template>
  

  <script>
  // eslint-disable-next-line object-curly-newline
  import { mdiMagnify, mdiFileExcel, mdiArrowLeft, mdiAccount} from '@mdi/js'
  import { ref } from '@vue/composition-api'
  import  UCDatatable  from './docentes-components/DocentesTabla.vue';
  import UCToolbar from '@/components/UCToolbar.vue'
  import  DocentesForm  from './docentes-components/DocentesForm.vue';
  import  DocentesDet  from './docentes-components/DocentesDet.vue';
  import { required } from '@core/utils/validation.js'
  import useAppConfig from '@core/@app-config/useAppConfig'
  import {Functions} from "@core/libs/lib.js"
  import * as moment from 'moment'
  
  export default {
    components: {
      UCToolbar,
      UCDatatable,
      DocentesForm,
      DocentesDet
    },
    setup() {
      var { overlay } = useAppConfig()
      const valid = ref(false)
      const form = ref(null)
      const validate = () => {
        form.value.validate()
      }  
      return {
        headers: [
          { text: 'ID', value: 'documento', filterable: true },
          { text: 'NOMBRES', value: 'full_name', filterable: true },
          { text: 'SSN', value: 'ssn', filterable: true },
          { text: 'ROL', value: 'rol', filterable: true },
          { text: 'EMAIL HARSON', value: 'email', filterable: true   },
          { text: '', value: 'options', sortable: false },
        ],
        valid,
        form,
        validate,
        items: [],
        itemsPerPage: 25,
        itemTotal: 0,
        page: 1,
        periodos: [],
        isLoading: false,
        overlay,
        tableKey: 0,
        entityData: {},
        origen: 1,
        modeForm: 1,
        validators: { required},
        icons: {mdiMagnify, mdiFileExcel, mdiArrowLeft, mdiAccount},
        menu1: false,
        itemSelected: {},
        isShowEntityActive: false,
        isShowEntityDetActive: false,
      }
   },
  
    beforeMount(){
      this.initialize()
    },
    methods: {
      loadAlert(text, type="error", title="Advertencia"){
        //this.$store.commit('appConfig/TOGGLE_SNACKBAR', {show: true, text: text, color: type})
        this.$swal.fire({
                title: title,
                text: text,
                icon: type,
                confirmButtonText: 'OK',
              })
      },
      initialize() {
        
        this.overlay = true
        this.overlay = false
      },
      changePage(page){
        this.page = page
        this.onSubmit()
      },
      changeItemPerPage(itemperpage) {
        this.itemsPerPage = itemperpage
        this.page = 1
        this.onSubmit()
      },
      showEaForm(item){
        this.itemSelected = item
        this.isShowEntityActive = true
      },
      onSubmit() {
          
        if (!this.valid) {
          return
        }
        this.isLoading = true
        this.items = []

        this.entityData.itemsPerPage = this.itemsPerPage
        this.entityData.page = this.page

        this.$http.post('docentes/get-docentes', this.entityData)
        .then(response => {
            this.items = response.data.data
            //console.log(response.data)
            this.itemTotal = Number(response.data.rows)
            //this.tableKey++                
            this.isLoading = false              
        })
        .catch(error => {
              this.isLoading = false
        })

      },
      showDocentesForm(item){
        //this.itemSelected = item
        
        this.isShowEntityActive = true
      },
      showDetailForm(item){
        //alert("aa")
        this.overlay = true
        this.itemSelected = item
        //console.log(item)
        //this.isShowEntityDetActive = true
        this.isShowEntityActive = true
      },
      enviarCorreo(item){
        //console.log(item)
        this.$swal.fire({
          title: "Confirmación de envío de correo",
          text: "¿desea enviar el correo de bienvenida al docente?",
          icon: "warning",
          showCancelButton: true,
          confirmButtonText: 'Continuar',
          cancelButtonText: 'En otro momento',      
        }).then((result) => {
          if (result.isConfirmed) {
            this.overlay = true
        
            var dataSend= {
              document: item.documento,
              emailhar: item.email,
              emailper: item.email_per
            }
            this.$http.post('docentes/enviar-correo', dataSend)
            .then(response => {
              this.$swal.fire({
                title: 'Listo!',
                text: 'Se envió el correo de bienvenida al docente',
                icon: 'success',
                confirmButtonText: 'OK',
              })
              this.overlay = false
            })
            .catch(error => {
                  this.isLoading = false
            })
          }
          
        })
      },      
      createEntityOrClose(){
        this.itemSelected = {}
        this.isShowEntityActive = false
      },
      onBackward(){
        alert("sdsds");
        this.isShowEntityActive = !this.isShowEntityActive
        //this.tableKey++
      },
      exportResult(){
        
        if(this.items.length==0) return
  
        const headers = this.headers
        var arrData = []
  
        const replacef = function (string) {
          return Functions.replaceChar(string)
        }
  
        this.items.map(function (element) {
            const row = new Object ()
            headers.map(function (header) {
              if(header.value!='options') {
  
                const value = header.value.split('.');
                if(value.length == 1) {
                  row[header.text] = element[header.value] == undefined ? '' :  element[header.value]
                } else if (value.length == 2) {
                  row[header.text] = element[value[0]] == undefined ? '' :  element[value[0]][value[1]]
                } else {
                  row[header.text] = ''
                }
  
                row[header.text] = isNaN(row[header.text]) ? replacef(row[header.text]) : row[header.text]
  
                if(header.value == 'payment_status') {
                  const status = {
                    1: 'Pagado',
                    0: 'Pendiente',
                  }
                  row[header.text] = status[element[header.value]]
                }
                if(header.value == 'ea_status') {
                  const eaStatus = {
                    null: 'No Generado',
                    1: 'Enviado',
                    2: 'Firmado'
                  }
                  row[header.text] = eaStatus[element[header.value]]
                }
                if(header.value == 'gaston_pidm') {
                  //alert(element[header.value])
                  row[header.text] = element[header.value] !== null ? ' SI' : ' NO'
                }
                
              } 
  
            })
            arrData.push(row)
        })
  
        Functions.downloadFileCsvEncode(arrData, 'Listado_Docentes_Harson.csv');
      }
  
    }
  }
  </script>
  