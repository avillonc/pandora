<template>
    <v-card-text class="mt-5">
          <v-form ref="form"
            v-model="valid"
            @submit="onSubmit" 
            @submit.prevent="validate">
            <v-row>
                <v-col cols="12" md="6">
                <v-text-field
                    label="First name"
                    v-model="entityData.first_name"
                    outlined                  
                    dense
                    hide-details="auto"
                    :rules="[validators.required]"
                ></v-text-field>
                </v-col> 
                <v-col cols="12" md="6" >
                <v-text-field
                    label="Last name"
                    v-model="entityData.last_name"
                    outlined
                    dense
                    hide-details="auto"
                    :rules="[validators.required]"
                ></v-text-field>
                </v-col>
            </v-row>
            <v-row>
              <v-col cols="12" md="6" >
                <v-text-field
                  label="E-mail"
                  v-model="entityData.email"
                  outlined
                  dense
                  hide-details="auto"
                  :rules="[validators.required]"
                ></v-text-field>
              </v-col>
              <v-col cols="12" md="6" >
                <v-text-field
                  label="Harson E-mail"
                  v-model="entityData.email_harson"
                  outlined
                  dense
                  hide-details="auto"
                  :rules="[validators.required]"
                ></v-text-field>
              </v-col>
            </v-row>
            <v-row>
              <v-col cols="12" md="6" >
                <v-text-field
                  label="Cell phone"
                  v-model="entityData.cell_phone"
                  outlined
                  dense
                  hide-details="auto"
                  :rules="[validators.required]"
                ></v-text-field>
              </v-col>
              <v-col cols="12" md="6" >
                <v-radio-group v-model="entityData.gender" :rules="[validators.required]">
                    <v-radio label="Male" value="M" key="M"></v-radio>
                    <v-radio label="Female" value="F" key="F"></v-radio>
                  </v-radio-group>
              </v-col>
            </v-row>
            <v-input></v-input>
  
          </v-form>
    </v-card-text>
  </template>
    
    <script>
    import { ref, watch } from '@vue/composition-api'
    import { mdiContentSave} from '@mdi/js'
    import { isEmpty, getFieldDb } from '@core/utils/index'
    import { required, alphaDasNameValidator, requiredObject, maxlengthValidator, minNumber, sch_required } from '@core/utils/validation.js'
    import useAppConfig from '@core/@app-config/useAppConfig'
    
    export default {
      props: {
        entityData: {
            type: Object,
            required: true,
          },
      },
      setup() {
        const valid = ref(false)
        const form = ref(null)
        const validate = () => {
          form.value.validate()
        }
    
        var { overlay } = useAppConfig()
    
        const enabled = {
          2: 'Inactivo',
          1: 'Activo',
        }
    
        return {
          valid,
          form,
          validate,
          validators: { required, alphaDasNameValidator, requiredObject, maxlengthValidator, minNumber, sch_required},
          getFieldDb,
          isEmpty,
          icons: {
            mdiContentSave
          },
          overlay,
          enabled,
          checked: false
    
        }
      },
      beforeMount(){
        //this.cuotas = 1
  
        this.initialize()
      },
      
      methods: {
        initialize() {
          
          this.overlay = false
            window.scrollTo({ top: 0, behavior: 'smooth' });
            
            this.$forceUpdate()
    
        },
        
        regresar(){
          this.$emit('on-backward')
        },
        loadAlert(text, type="error", title="Advertencia"){
          //this.$store.commit('appConfig/TOGGLE_SNACKBAR', {show: true, text: text, color: type})
          this.$swal.fire({
                  title: title,
                  text: text,
                  icon: type,
                  confirmButtonText: 'OK',
                }).then((result) => {
                  if (result.isConfirmed) {
                    //document.querySelectorAll("#btnRegresar").forEach(el=>el.click())
                    //document.querySelectorAll("#btnConsultar").forEach(el=>el.click())
                    
                  }
                })
        },
        onSubmit(){
          if (this.valid) {
            this.overlay = true
            this.$http.post('docentes/guardar', this.entityData)
                .then(response => {
                    this.loadAlert(response.data.mensaje, 'success', 'Éxito')
                    window.scrollTo({ top: 0, behavior: 'smooth' });
                    this.overlay = false
                    this.$forceUpdate();
                    
                }).catch(function(err){
                    if(err.response.status == 422) {                  
                      this.loadAlert('Elegir al menos un program schedule');
                      this.overlay = false
                      
                      this.$forceUpdate();
                    }
                });
                /*.catch(error => {     
                      this.overlay = false
                      this.$emit('load-alert', error.response.data.message)
                }) */      
          } else {
            this.validate()
            this.loadAlert('Tiene campos incompletos');
             let elementsInErrors = document.getElementsByClassName('error--text');
            if (elementsInErrors && elementsInErrors.length > 0) {
                elementsInErrors[0].scrollIntoView({ behavior: 'smooth', block: 'center' });
            }
          }
        },
      }
    }
    </script>
    