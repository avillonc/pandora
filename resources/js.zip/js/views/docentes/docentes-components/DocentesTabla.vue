
<template>
    <div>
      <v-card-text class="my-6">
        <v-row>
          <v-col
            cols="12"
            md="6"
          >
          <span>Total de Registros: {{itemTotal}}</span>
            </v-col>
          <v-spacer></v-spacer>
          <v-col
            cols="12"
            md="3"
          >
          
          </v-col>
        </v-row>
      </v-card-text>
      <v-data-table
        :headers="headers"
        :items="items"
        :loading="isLoading"
        :items-per-page="itemsPerPage"
        :search="search"
        no-data-text="No hay datos para mostrar"
        loading-text="Cargando..."
        :sortBy = "sortBy"
        :sortDesc = "true"
        :page.sync="page"
        hide-default-footer
        @page-count="pageCount = $event"
        :server-items-length="itemTotal"
        :show-select="showSelect"
        @item-selected="select"
        @toggle-select-all="selectAll"
        :item-key="itemKey"
        :single-expand="true"
      >
        <template #[`item.options`]="{ item }">
          <v-tooltip top color="primary">
            <template v-slot:activator="{ on, attrs }">
              <v-avatar size="28" class="v-avatar-light-bg primary--text" 
                v-bind="attrs"
                v-on="on">
                  <v-icon size="20" @click="showFormDetalle(item)" color="primary">
                      {{ icons.mdiEyeOutline  }}
                  </v-icon>
              </v-avatar>
            </template>
            <span>Ver Detalles</span>
          </v-tooltip>
          <v-tooltip top color="primary">
            <template v-slot:activator="{ on, attrs }">
              <v-avatar size="28" class="v-avatar-light-bg primary--text" 
                v-bind="attrs"
                v-on="on">
                  <v-icon size="20" @click="enviarCorreo(item)" color="info">
                      {{ icons.mdiEmail  }}
                  </v-icon>
              </v-avatar>
            </template>
            <span>¿Enviar correo de bienvenida?</span>
          </v-tooltip>
        </template>
        
        <template #[`item.full_name`]="{item}">
          <slot name="nombres">
              <span class="primary--text">{{item.full_name}}</span>
          </slot>
        </template>
  
        <template #[`item.payment_status`]="{item}">
          <v-chip
            small
            :color="statusColor[item.payment_status]"
            :class="`${statusColor[item.payment_status]}--text`"
            class="v-chip-light-bg"
          >
            {{ status[item.payment_status] }}
          </v-chip>
        </template>

  
        <template #[`item.entry_date`]="{item}">
           {{ formatDate(item.effective_date) }}
        </template>
  
      </v-data-table>
      <v-card-text class="pt-2">
        <v-row>
          <v-col
            lg="2"
            cols="3"
          >
            <v-select
              v-model="itemsPerPage"
              :items="[5, 25, 50, 100]"
              label="Items por Página"
              hide-details
              @change="changeItemPerPage"
            ></v-select>
          </v-col>
  
          <v-col
            lg="10"
            cols="9"
            class="d-flex justify-end"
          >
            <v-pagination
              v-model="page"
              total-visible="7"
              :length="pageCount"
            ></v-pagination>
          </v-col>
        </v-row>
      </v-card-text>
      <UCDialogQuestion
          :visible="activemsgConfirm"
          :message="msgConfirm"
          title="Confirmación"
          @cancel="closemsgConfirm"
          
      ></UCDialogQuestion>
    </div>
  </template>
  
  <script>
  import { ref } from '@vue/composition-api'
  import { mdiEyeOutline, mdiEmail } from '@mdi/js'
  import * as moment from 'moment'
  import {Functions} from "@core/libs/lib.js"
  import UCDialogQuestion from '@/components/UCDialogQuestion.vue'
  import useAppConfig from '@core/@app-config/useAppConfig'
  import { required, requiredObject } from '@core/utils/validation.js'
  
  export default {
    components: {
      UCDialogQuestion
    },
    props: {
      items: {
        type: Array,
        default: []
      },
      isLoading: {
        type: Boolean,
        default: false,
      },
      headers: {
        type: Array,
        required: true
      },
      sortBy: {
        type: String,
        default: "id"
      },
      showSelect: {
        type: Boolean,
        default: false
      },
      nameAction: {
        type: String,
        default: 'Guardar'
      },
      itemKey: {
        type: String,
        default: 'id'
      },
      search: {
        type: String,
        default: ''
      },
      itemTotal: {
        type: Number,
        default: null
      },
      itemsPage: {
        type: Number,
        default: 25
      },
    },
    setup(props) {
      const statusColor = {
        1: 'success',
        0: 'error',
      }
      const status = {
        1: 'Pagado',
        0: 'Pendiente',
      }
  
      const eaStatusColor = {
        null: 'error',
        1: 'success',
        2: 'Firmado'
        
      }
      const eaStatus = {
        null: 'No Generado',
        1: 'Enviado',
        2: 'Firmado'
      }
  
      var { overlay } = useAppConfig()
  
      const valid = ref(false)
      const form = ref(null)
      const validate = () => {
        form.value.validate()
      }
  
      const resetValidation = ()=> {
        form.value.resetValidation()
      }
  
      const entityData = ref({})
  
      return {
        page: 1,
        pageCount: 0,
        itemsPerPage: props.itemsPage,
        status,
        statusColor,
        eaStatus,
        eaStatusColor,
        icons: {
          mdiEmail,
          mdiEyeOutline
        },
        valueSelected: [],
        msgConfirm: '',
        activemsgConfirm: false,
        msgConfirmReenvio: '',
        overlay,
        equipos: [],
        valid,
        form,
        validate,
        resetValidation,
        isDialogOpen: false,
        validators: { required, requiredObject},
        entityData,
        laboratorios: []
      }
    },
    watch: {
            page(value) {
              this.$emit('change-page', this.page)
            },
    },
    methods: {
      loadAlert(text, type="error", title="Advertencia"){
        this.$swal.fire({
                title: title,
                text: text,
                icon: type,
                confirmButtonText: 'OK',
              })
      },
      formatDate(created_at) {
          return moment(created_at).format('DD/MM/YYYY');
      },
      formatDateTime(fecha) {
        if(fecha==null) return ''
        return moment(fecha).format('DD/MM/YYYY HH:mm');
      },
      changeItemPerPage(item){
        this.$emit('item-per-page', item)
      },
      select(select){
        console.log(select)
        if(select.value) {
  
            var pidm = null
            if(select.item != undefined) {
              pidm = select.item.pidm
            } else {
              if(select.currentItem != undefined)  pidm = select.currentItem.pidm
            }
            
            if(pidm != null) {
              var index = this.valueSelected.indexOf(pidm);
              if (index == -1) {
                this.valueSelected.push(pidm)
              }
            }
            
        } else {
   
            var pidm = null
            if(select.item != undefined) {
              pidm = select.item.pidm
            } else {
              if(select.currentItem != undefined)  pidm = select.currentItem.pidm
            }
            
            if(pidm != null) {
              var index = this.valueSelected.indexOf(select.item.pidm);
              if (index > -1) {
                  this.valueSelected.splice(index, 1);
              }
            }
  
        }
        this.$forceUpdate()
      },
      selectAll(select){
        select.items.map((item) => {
            const index = this.valueSelected.indexOf(item.pidm);
            if (index > -1) {
                if(!select.value) {
                  this.valueSelected.splice(index, 1);
                }
            } else {
              if(select.value) {
                this.valueSelected.push(item.pidm)
              }
            }
        })
        this.$forceUpdate()
      },
      showMessageConfirm(){
        if (this.valid) {
          this.msgConfirm = "Seguro de generar y enviar EA para el alumno: "+ this.entityData.full_name
  
          this.activemsgConfirm= true
        }
      },
      closemsgConfirm(){
        this.activemsgConfirm = false
      },
  
      showFormDetalle(item){
        this.modeForm = 2
        this.$emit('show-detail-form',item)
      },
      enviarCorreo(item){
        this.modeForm = 2
        this.$emit('enviar-correo',item)
      },
      closeDialog(){
        this.isDialogOpen = false
        this.entityData = {}
        this.resetValidation()
      },
      cancelar(){
  
      },
      changeItemPerPage(item){
        this.$emit('item-per-page', item)
      },
    }
  }
  </script>