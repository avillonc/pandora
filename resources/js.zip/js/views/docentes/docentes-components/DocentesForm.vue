<template>
  <v-card-text class="mt-5">
      <v-form ref="form" v-if="modeForm==1"
          >
        <v-row >
          <v-col cols="12" md="4">
            <v-text-field
                label="SSN"
                v-model="entityData.documento_search"
                outlined                  
                dense
                :rules="[validators.required]"
                hide-details="auto"
            ></v-text-field>
          </v-col>
          <v-col cols="12" md="2">
            
            <v-btn block color="info" type="button" outlined @click="consultarDocente"> 
                <v-icon
                  left
                  dark
                >
                  {{icons.mdiAccountSearch}}
                </v-icon>
                Consultar</v-btn>
          </v-col>
        </v-row>
      </v-form>
        <v-row v-if="modeForm==1">
            <v-col cols="12"> <v-divider></v-divider></v-col>
          </v-row> 
        <v-row>
              <v-col cols="12" md="5">
                <h4 class="mt-3 mb-0">Datos de docente: </h4>
              </v-col>
              <v-col cols="12" md="4">
              </v-col>

          </v-row>  
        <v-form ref="form"
          v-model="valid"
          @submit="onSubmit" 
          @submit.prevent="validate">
          <v-row v-if="modeForm==2">
              <v-col cols="12" md="3">
                <v-text-field
                    label="ID"
                    v-model="entityData.documento"
                    outlined
                    v-bind:readonly="isReadOnly"
                    v-bind:filled="isReadOnly"          
                    dense
                    hide-details="auto"
                    :rules="[validators.required]"
                ></v-text-field>
              </v-col>
              <v-col cols="12" md="3">
                <v-text-field
                    label="PIDM"
                    v-model="entityData.pidm"
                    outlined
                    v-bind:readonly="isReadOnly"
                    v-bind:filled="isReadOnly"          
                    dense
                    hide-details="auto"
                    :rules="[validators.required]"
                ></v-text-field>
              </v-col> 
              <v-col cols="12" md="3">
                <v-text-field
                    label="SSN"
                    v-model="entityData.ssn"
                    outlined
                    v-bind:readonly="isReadOnly"
                    v-bind:filled="isReadOnly"          
                    dense
                    hide-details="auto"
                    :rules="[validators.required]"
                ></v-text-field>
              </v-col>
          </v-row>
          <v-row>
              <v-col cols="12" md="6">
              <v-text-field
                  label="First name"
                  v-model="entityData.first_name"
                  outlined
                  v-bind:readonly="isReadOnly"
                  v-bind:filled="isReadOnly"          
                  dense
                  hide-details="auto"
                  :rules="[validators.required]"
              ></v-text-field>
              </v-col> 
              <v-col cols="12" md="6" >
              <v-text-field
                  label="Last name"
                  v-model="entityData.last_name"
                  outlined
                  v-bind:readonly="isReadOnly"
                  v-bind:filled="isReadOnly"
                  dense
                  hide-details="auto"
                  :rules="[validators.required]"
              ></v-text-field>
              </v-col>
          </v-row>
          <v-row>
            <v-col cols="12" md="6" >
              <v-text-field
                label="E-mail"
                v-model="entityData.email"
                outlined
                v-bind:readonly="isReadOnly"
                v-bind:filled="isReadOnly"
                dense
                hide-details="auto"
                :rules="[validators.required]"
              ></v-text-field>
            </v-col>
            <v-col cols="12" md="6" >
              <v-text-field
                label="Harson E-mail"
                v-model="entityData.email_harson"
                outlined
                dense
                v-bind:readonly="isReadOnly"
                v-bind:filled="isReadOnly"
                hide-details="auto"
                :rules="[validators.required]"
              ></v-text-field>
            </v-col>
          </v-row>
          <v-row>
            <v-col cols="12" md="6" >
              <v-text-field
                label="Cell phone"
                v-model="entityData.cell_phone"
                :counter="12"
                outlined
                dense
                v-bind:readonly="isReadOnly"
                v-bind:filled="isReadOnly"
                hide-details="auto"
              ></v-text-field>
            </v-col>
            <v-col cols="12" md="6" >
              <v-radio-group v-model="entityData.gender" row v-bind:readonly="isReadOnly" v-bind:filled="isReadOnly" :rules="[validators.required]">
                <v-radio label="Male" value="M"></v-radio>
                <v-radio label="Female" value="F"></v-radio>
              </v-radio-group>

            </v-col>
          </v-row>
          <v-input></v-input>
          <v-row v-if="modeForm==1">

              <v-col cols="12" md="6"></v-col>
              <v-col cols="12" md="3">
                <v-checkbox
                  class="mt-4"
                  label="Enviar correo de bienvenida"
                  v-model="entityData.enviar_correo"
                  :true-value="true"
                  >
                </v-checkbox>
              </v-col>
              <v-col cols="12" md="3">
              <v-btn  block color="success" type="submit" v-bind:disabled="isReadOnly"  >
                  <v-icon
                  left
                  dark
                  >
                  {{icons.mdiContentSave}}
                  </v-icon>
                  Guardar
              </v-btn>
              </v-col>
          </v-row>    
        </v-form>
  </v-card-text>
</template>
  
  <script>
  import { ref, watch } from '@vue/composition-api'
  import { mdiContentSave, mdiAccountSearch} from '@mdi/js'
  import { isEmpty, getFieldDb } from '@core/utils/index'
  import { required, alphaDasNameValidator, requiredObject, maxlengthValidator, minNumber, sch_required } from '@core/utils/validation.js'
  import useAppConfig from '@core/@app-config/useAppConfig'
  
  var _props = {
      entityData: {
          type: Object,
          required: true,
        },
    };
  export default { 

    props: _props,
    setup() {
      const valid = ref(false)
      const form = ref(null)
      const validate = () => {
        form.value.validate()
      }
  
      var { overlay } = useAppConfig()
  
      const enabled = {
        2: 'Inactivo',
        1: 'Activo',
      }
  
      return {
        valid,
        form,
        validate,
        validators: { required, alphaDasNameValidator, requiredObject, maxlengthValidator, minNumber, sch_required},
        getFieldDb,
        isEmpty,
        icons: {
          mdiContentSave,
          mdiAccountSearch
        },
        //entityData: {},
        isReadOnly: true,
        modeForm: 1,
        overlay,
        enabled,
        checked: false
      }
    },
    beforeMount(){
      
      if(typeof this.entityData.first_name !== "undefined")
        { 
          var data = {
            document: this.entityData.documento
          }
          this.overlay= true
          this.$http.post('docentes/consultar', data)
          .then(response => {
              if(response.data.length > 0){
                console.log(response.data[0]['celular'])
                this.entityData.first_name    = response.data[0]['first_name']
                this.entityData.last_name     = response.data[0]['last_name']
                this.entityData.email         = response.data[0]['mailpersonal']
                this.entityData.email_harson  = response.data[0]['mailharson']
                this.entityData.cell_phone    = response.data[0]['celular']
                this.entityData.gender        = response.data[0]['sexo']
                this.overlay= false
                this.$forceUpdate()
              }
              
          })
          this.modeForm = 2; // nuevo
        } else{
          this.modeForm = 1; // visualiza
          
        }
      
      this.entityData.enviar_correo=true
      this.initialize()
      
    },
    
    methods: {
      initialize() {

        //console.log(this.entityData.first_name);
        this.overlay = true
        this.overlay = false
        window.scrollTo({ top: 0, behavior: 'smooth' });
        this.$forceUpdate()
      },
      consultarDocente(){
        if(!this.entityData.documento_search){
          this.loadAlert('Ingrese un SSN de búsqueda');
          return;
        }
        //if (this.valid) {
          this.overlay = true
          var data = {
            document: this.entityData.documento_search,
          }
          this.$http.post('docentes/consultar', data)
          .then(response => {
              //alert(response.data[0]['ssn']);
              if(response.data.length > 0 && response.data[0]['ssn'] !== null){
                this.$swal.fire({
                  title: "Atención",
                  text: response.data[0]['first_name'] + ' ' + response.data[0]['last_name'] + ' ya se encuetra registrado como DOCENTE HARSON',
                  icon: "success",
                  confirmButtonText: 'Ok',
                });

                document.getElementById("btnRegresar").click();
                this.modeForm = 2
              }
              else if(response.data.length > 0){
                this.$swal.fire({
                  title: "Persona ya existe en la base de datos",
                  text: "¿desea registrarlo como docente Harson?",
                  icon: "warning",
                  confirmButtonText: 'Continuar',
                }).then((result) => {
                  //alert(1)
                  if (result.isConfirmed) {
                    this.entityData.first_name    = response.data[0]['first_name']
                    this.entityData.last_name     = response.data[0]['last_name']
                    this.entityData.email         = response.data[0]['mailpersonal']
                    this.entityData.email_harson  = response.data[0]['mailharson']
                    this.entityData.cell_phone    = response.data[0]['celular']
                    this.entityData.gender        = response.data[0]['sexo']
                    this.isReadOnly = false
                  }else{
                    this.isReadOnly = true
                  }
                })
              }else{
                this.$swal.fire({
                  title: "Persona aun no está registrada",
                  //text: "¿desea registrarlo como docente Harson?",
                  icon: "success",
                  confirmButtonText: 'Ok',
                })
                this.entityData.first_name    = ""
                this.entityData.last_name     = ""
                this.entityData.email         = ""
                this.entityData.email_harson  = ""
                this.entityData.cell_phone    = ""
                this.entityData.gender        = ""
                this.isReadOnly = false
              }
              
              //this.calcularTuition();
              this.$forceUpdate()
              this.overlay = false
            
          })
        //}
      },
      regresar(){
        this.$emit('on-backward')
      },
      loadAlert(text, type="error", title="Advertencia"){
        //this.$store.commit('appConfig/TOGGLE_SNACKBAR', {show: true, text: text, color: type})
        this.$swal.fire({
                title: title,
                text: text,
                icon: type,
                confirmButtonText: 'OK',
              }).then((result) => {
                if (result.isConfirmed) {
                  //document.querySelectorAll("#btnRegresar").forEach(el=>el.click())
                  //document.querySelectorAll("#btnConsultar").forEach(el=>el.click())
                  
                }
              })
      },
      onSubmit(){
        if (this.valid) {
          this.overlay = true
          this.$http.post('docentes/guardar', this.entityData)
              .then(response => {
                if(response.data.cod == 1){
                  this.loadAlert(response.data.msj, 'success', 'Éxito')
                  window.scrollTo({ top: 0, behavior: 'smooth' });
                  this.overlay = false
                  document.getElementById("btnRegresar").click();
                }else if(response.data.cod == 0){
                  this.loadAlert(response.data.msj, 'error', 'Advertencia')
                  window.scrollTo({ top: 0, behavior: 'smooth' });
                  this.overlay = false
                }

                  //document.getElementById("btnConsultar").click();
                  
                  //
                  //this.$forceUpdate();
                  
              }).catch(function(err){
                  console.log(err)
                  //alert("erro de servidor")

                  /*this.$swal.fire({
                    title: 'Advertencia',
                    text: 'Hubo un problema al registrar a este docente.',
                    icon: type,
                    confirmButtonText: 'OK',
                  })
                  window.scrollTo({ top: 0, behavior: 'smooth' });
                  this.overlay = false */
                  //document.getElementById("btnRegresar").click();
                  //document.getElementById("btnConsultar").click();
                
                  /*if(err.response.status == 422) {                  
                   
                    this.overlay = false
                    this.$emit('on-backward')
                    this.$forceUpdate();
                  }*/
              });
              /*.catch(error => {     
                    this.overlay = false
                    this.$emit('load-alert', error.response.data.message)
              }) */      
        } else {
          this.validate()
          this.loadAlert('Tiene campos incompletos');
           let elementsInErrors = document.getElementsByClassName('error--text');
          if (elementsInErrors && elementsInErrors.length > 0) {
              elementsInErrors[0].scrollIntoView({ behavior: 'smooth', block: 'center' });
          }
        }
      },
    }
  }
  </script>
  