<template>
    <v-card>
      <v-card-title class="text-wrap">
        <h4 class="py-4"><strong>
        Reporte de Alumnos Matriculados con Deuda</strong></h4>
      </v-card-title>
      <v-toolbar flat v-if="isShowEntityActive"
      style="background: rgb(var(--v-theme-on-white))">
      <v-btn 
      variant="tonal"
      color="secondary"
      id="btnRegresar"
      class="mb-2"
      @click="createEntityOrClose"
      > 
          <v-icon left icon="mdi-arrow-left">
          </v-icon>
          Regresar
      </v-btn>
      <v-divider></v-divider>
    </v-toolbar>
    <v-divider v-if="!isShowEntityActive"></v-divider>
      <v-card-text v-if="!isShowEntityActive" class="my-4">
        <v-form ref="form"
          v-model="valid"
          @submit="onSubmitGeneral" 
          @submit.prevent="validate"
          >
          <v-row>
            <v-col cols="12" md="3">
                <v-autocomplete
                  variant="outlined"
                  density="compact"
                  label="Periodo"
                  v-model="entityData.term_code"
                  :items="periodos"
                  item-title="period_desc"
                  item-value="period_val"
                  :menu-props="{ offsetY: true }"
                  hide-details="auto"
                  :rules="[validators.required]"
                  
                ></v-autocomplete>
            </v-col> 
            <v-col cols="12" md="3">
                <v-autocomplete
                  label="Carrera"
                  v-model="entityData.majr_code"
                  variant="outlined"
                  density="compact"
                  :items="programs"
                  item-title="name"
                  item-value="majr_code"
                  :menu-props="{ offsetY: true }"
                  hide-details="auto"
                ></v-autocomplete>
            </v-col>

            <v-col cols="12" md="3">
                <v-autocomplete
                  label="Estado"
                  v-model="entityData.estado"
                  variant="outlined"
                  density="compact"
                  :items="estados"
                  item-title="text"
                  item-value="id"
                  :menu-props="{ offsetY: true }"
                  hide-details="auto"
                  
                ></v-autocomplete>
            </v-col>
            <v-col cols="12" md="3">
              <v-text-field
                  label="Fecha"
                  v-model="entityData.fecha"
                  outlined
                  type="date"
                  dense
                  hide-details="auto"
                  density="compact"
                  :rules="[validators.required]"
                ></v-text-field>
            </v-col>
            <v-col cols="12" md="3">
              <v-text-field
                  label="Deuda >="
                  density="compact"
                  v-model="entityData.deuda"
                  outlined
                  dense
                  hide-details="auto"
                  
              ></v-text-field>
            </v-col>
            <v-col
            cols="12"
            md="3"
            ></v-col>
            <v-col
            cols="12"
            md="3"
            >
            <v-btn block color="success" type="button" @click="exportResult" outlined :loading="isLoading"> 
            <v-icon
                left
                dark
                icon="mdi-file-excel"
            >
            </v-icon>
            Exportar</v-btn>
          </v-col>
          <v-col
            cols="12"
            md="3"
            > 
            <v-btn  block color="success" type="submit" :loading="isLoading" >
                <v-icon
                left
                dark
                id="btnConsultar"
                icon="mdi-magnify"
            >
            </v-icon>
                Consultar
            </v-btn>
          </v-col>
          </v-row>
          <v-row>
          <v-spacer></v-spacer>
          
        </v-row>
        </v-form>
      </v-card-text>
      <u-c-datatable  v-if="!isShowEntityActive"
              class="mt-4 row-pointer"
              :items="items" 
              :key="tableKey"
              :isLoading="isLoading"
              :headers="headers"
              :itemTotal="itemTotal"
              :itemsPage="itemsPerPage"
              :page="page"
              @change-page="changePage"
              @item-per-page="changeItemPerPage"
        ></u-c-datatable>
    </v-card>
</template>

<script setup>

  //import { ref, inject } from 'vue'
import useAppConfig from '@core/@app-config/useAppConfig';
import { required, requiredObject } from '@core/utils/validation.js';
import moment from "moment";
import UCDatatable from './report-components/ReportTabla.vue';
//variables de sistema
  let { overlay } = useAppConfig()
  const $http = inject('http')

  let periodos = ref([])
  let programs = ref([])
  let  estados = [{id: '', text: 'Todos'}, 
    {id: 'AS', text: 'Activos'}, 
    {id: 'IS', text: 'Inactivos'},
    {id: 'EG', text: 'Egresados'}, 
    {id: 'RA', text:'Retiros Administrativos'},
    {id: 'RP', text:'Retiro de Periodo'},
    {id: 'RD', text:'Retiros Definitivo'},
    {id: 'EB', text:'Expulsado por Notas'}

  ]

  let  validators = { required, 
    requiredObject}
  let headers = [
          { title: 'ID', key: 'spriden_id', sortable: false, width: '70px',cellClass:'text-xs', align:'center'},
          { title: 'Nombres', key: 'fullname', sortable: false, width: '290px', cellClass:'text-xs', },
          { title: 'Carrera', key: 'carrera', sortable: false, cellClass:'text-xs', align:'center' },
          { title: 'Lo', key: 'lo', sortable: false, width: '80px', cellClass:'text-xs', align:'center'},
          { title: 'admision', key: 'admision', sortable: false, width: '80px', cellClass:'text-xs', align:'center'},
          //{ title: 'Deuda', key: 'risk_deb', sortable: false, cellClass:'text-xs', align:'center'},
          { title: 'Estado', key: 'est', sortable: false, cellClass:'text-xs', align:'center'},
          { title: 'Teléfono', key: 'telefono', sortable: false, width: '250px',cellClass:'text-xs', align:'center'},
          { title: 'Dirección', key: 'spraddr_street_line1',width: '400px', sortable: false, cellClass:'text-xs', },
          { title: 'Ciudad', key: 'spraddr_city', sortable: false, width: '250px',cellClass:'text-xs text-center'},
          { title: 'F nacimiento', key: 'f_nacimiento', width: '250px',sortable: false, cellClass:'text-xs text-center'},
          { title: 'Edad', key: 'edad', sortable: false, cellClass:'text-xs text-center'},
          { title: 'Correo', key: 'correo', sortable: false, cellClass:'text-xs text-center'},
          { title: 'Nuevo', key: 'nuevo', sortable: false, cellClass:'text-xs text-center'},
          { title: 'Cate', key: 'cate', sortable: false, cellClass:'text-xs text-center'},
          { title: 'Benef', key: 'benef', sortable: false, cellClass:'text-xs text-center'},
          { title: 'Sol. Retiro', key: 'sol_retiro', sortable: false, cellClass:'text-xs text-center'},
          { title: 'Credito Mat.', key: 'credito_mat', sortable: false, cellClass:'text-xs text-center'},
          { title: 'Credito Apro.', key: 'credito_apro', sortable: false, cellClass:'text-xs text-center'},
          { title: 'Ponde Acu', key: 'ponde_acu', sortable: false, cellClass:'text-xs text-center'},
          { title: 'Asistencia (%)', key: 'asistencia', sortable: false, cellClass:'text-xs text-center'},
          { title: 'Prioridad', key: 'prioridad', sortable: false, cellClass:'text-xs text-center'},
          { title: 'Fec. Venc 0000', key: 'fec_venc_0000', sortable: false, cellClass:'text-xs text-center'},
          { title: 'Fec. Pago 0000', key: 'fec_pago_0000', sortable: false, cellClass:'text-xs text-center'},
          { title: 'Fec. Venc 0001', key: 'fec_venc_0001', sortable: false, cellClass:'text-xs text-center'},
          { title: 'Fec. Pago 0001', key: 'fec_pago_0001', sortable: false, cellClass:'text-xs text-center'},
          { title: 'Fec. Venc 0002', key: 'fec_venc_0002', sortable: false, cellClass:'text-xs text-center'},
          { title: 'Fec. Pago 0002', key: 'fec_pago_0002', sortable: false, cellClass:'text-xs text-center'},
          { title: 'Fec. Venc 0003', key: 'fec_venc_0003', sortable: false, cellClass:'text-xs text-center'},
          { title: 'Fec. Pago 0003', key: 'fec_pago_0003', sortable: false, cellClass:'text-xs text-center'},
          { title: 'Fec. Venc 0004', key: 'fec_venc_0004', sortable: false, cellClass:'text-xs text-center'},
          { title: 'Fec. Pago 0004', key: 'fec_pago_0004', sortable: false, cellClass:'text-xs text-center'},
          { title: 'Fec. Venc 0005', key: 'fec_venc_0005', sortable: false, cellClass:'text-xs text-center'},
          { title: 'Fec. Pago 0005', key: 'fec_pago_0005', sortable: false, cellClass:'text-xs text-center'},
          { title: 'Fec. Venc 0006', key: 'fec_venc_0006', sortable: false, cellClass:'text-xs text-center'},
          { title: 'Fec. Pago 0006', key: 'fec_pago_0006', sortable: false, cellClass:'text-xs text-center'},
          { title: 'Fec. Venc 0007', key: 'fec_venc_0007', sortable: false, cellClass:'text-xs text-center'},
          { title: 'Fec. Pago 0007', key: 'fec_pago_0007', sortable: false, cellClass:'text-xs text-center'},
          { title: 'Fec. Venc 0008', key: 'fec_venc_0008', sortable: false, cellClass:'text-xs text-center'},
          { title: 'Fec. Pago 0008', key: 'fec_pago_0008', sortable: false, cellClass:'text-xs text-center'},
          { title: 'Fec. Venc 0009', key: 'fec_venc_0009', sortable: false, cellClass:'text-xs text-center'},
          { title: 'Fec. Pago 0009', key: 'fec_pago_0009', sortable: false, cellClass:'text-xs text-center'},
          { title: 'Fec. Venc 0010', key: 'fec_venc_0010', sortable: false, cellClass:'text-xs text-center'},
          { title: 'Fec. Pago 0010', key: 'fec_pago_0010', sortable: false, cellClass:'text-xs text-center'},
          { title: 'Fec. Venc 0011', key: 'fec_venc_0011', sortable: false, cellClass:'text-xs text-center'},
          { title: 'Fec. Pago 0011', key: 'fec_pago_0011', sortable: false, cellClass:'text-xs text-center'},
          { title: 'Fec. Venc 0012', key: 'fec_venc_0012', sortable: false, cellClass:'text-xs text-center'},
          { title: 'Fec. Pago 0012', key: 'fec_pago_0012', sortable: false, cellClass:'text-xs text-center'},

          { title: 'Fec. Venc 0001', key: 'fec_venc_0013', sortable: false, cellClass:'text-xs text-center'},
          { title: 'Fec. Pago 0001', key: 'fec_pago_0013', sortable: false, cellClass:'text-xs text-center'},
          { title: 'Fec. Venc 0002', key: 'fec_venc_0014', sortable: false, cellClass:'text-xs text-center'},
          { title: 'Fec. Pago 0002', key: 'fec_pago_0014', sortable: false, cellClass:'text-xs text-center'},
          { title: 'Fec. Venc 0003', key: 'fec_venc_0015', sortable: false, cellClass:'text-xs text-center'},
          { title: 'Fec. Pago 0003', key: 'fec_pago_0015', sortable: false, cellClass:'text-xs text-center'},
          { title: 'Fec. Venc 0004', key: 'fec_venc_0016', sortable: false, cellClass:'text-xs text-center'},
          { title: 'Fec. Pago 0004', key: 'fec_pago_0016', sortable: false, cellClass:'text-xs text-center'},
          { title: 'Fec. Venc 0005', key: 'fec_venc_0017', sortable: false, cellClass:'text-xs text-center'},
          { title: 'Fec. Pago 0005', key: 'fec_pago_0017', sortable: false, cellClass:'text-xs text-center'},
          { title: 'Fec. Venc 0006', key: 'fec_venc_0018', sortable: false, cellClass:'text-xs text-center'},
          { title: 'Fec. Pago 0006', key: 'fec_pago_0018', sortable: false, cellClass:'text-xs text-center'},
          { title: 'Fec. Venc 0007', key: 'fec_venc_0019', sortable: false, cellClass:'text-xs text-center'},
          { title: 'Fec. Pago 0007', key: 'fec_pago_0019', sortable: false, cellClass:'text-xs text-center'},
          { title: 'Fec. Venc 0008', key: 'fec_venc_0020', sortable: false, cellClass:'text-xs text-center'},
          { title: 'Fec. Pago 0008', key: 'fec_pago_0020', sortable: false, cellClass:'text-xs text-center'},
          { title: 'Fec. Venc 0009', key: 'fec_venc_0021', sortable: false, cellClass:'text-xs text-center'},
          { title: 'Fec. Pago 0009', key: 'fec_pago_0021', sortable: false, cellClass:'text-xs text-center'},
          { title: 'Fec. Venc 0010', key: 'fec_venc_0022', sortable: false, cellClass:'text-xs text-center'},
          { title: 'Fec. Pago 0010', key: 'fec_pago_0022', sortable: false, cellClass:'text-xs text-center'},
          { title: 'Fec. Venc 0011', key: 'fec_venc_0023', sortable: false, cellClass:'text-xs text-center'},
          { title: 'Fec. Pago 0011', key: 'fec_pago_0023', sortable: false, cellClass:'text-xs text-center'},
          { title: 'Fec. Venc 0012', key: 'fec_venc_0024', sortable: false, cellClass:'text-xs text-center'},
          { title: 'Fec. Pago 0012', key: 'fec_pago_0024', sortable: false, cellClass:'text-xs text-center'},



          { title: 'HFEE', key: 'p000', sortable: false, cellClass:'text-xs text-center'},
          { title: 'P001', key: 'p001', sortable: false, cellClass:'text-xs text-center'},
          { title: 'P002', key: 'p002', sortable: false, cellClass:'text-xs text-center'},
          { title: 'P003', key: 'p003', sortable: false, cellClass:'text-xs text-center'},
          { title: 'P004', key: 'p004', sortable: false, cellClass:'text-xs text-center'},
          { title: 'P005', key: 'p005', sortable: false, cellClass:'text-xs text-center'},
          { title: 'P006', key: 'p006', sortable: false, cellClass:'text-xs text-center'},
          { title: 'P007', key: 'p007', sortable: false, cellClass:'text-xs text-center'},
          { title: 'P008', key: 'p008', sortable: false, cellClass:'text-xs text-center'},
          { title: 'P009', key: 'p009', sortable: false, cellClass:'text-xs text-center'},
          { title: 'P010', key: 'p010', sortable: false, cellClass:'text-xs text-center'},
          { title: 'P011', key: 'p011', sortable: false, cellClass:'text-xs text-center'},
          { title: 'P012', key: 'p012', sortable: false, cellClass:'text-xs text-center'},

          { title: 'P013', key: 'p013', sortable: false, cellClass:'text-xs text-center'},
          { title: 'P014', key: 'p014', sortable: false, cellClass:'text-xs text-center'},
          { title: 'P015', key: 'p015', sortable: false, cellClass:'text-xs text-center'},
          { title: 'P016', key: 'p016', sortable: false, cellClass:'text-xs text-center'},
          { title: 'P017', key: 'p017', sortable: false, cellClass:'text-xs text-center'},
          { title: 'P018', key: 'p018', sortable: false, cellClass:'text-xs text-center'},
          { title: 'P019', key: 'p019', sortable: false, cellClass:'text-xs text-center'},
          { title: 'P020', key: 'p020', sortable: false, cellClass:'text-xs text-center'},
          { title: 'P021', key: 'p021', sortable: false, cellClass:'text-xs text-center'},
          { title: 'P022', key: 'p022', sortable: false, cellClass:'text-xs text-center'},
          { title: 'P023', key: 'p023', sortable: false, cellClass:'text-xs text-center'},
          { title: 'P024', key: 'p024', sortable: false, cellClass:'text-xs text-center'},
        ]

  const valid = ref(false)
  const form = ref(null)
  let page = ref(1)
  let itemsPerPage = ref(25)
  let itemTotal = ref(0)
  let isLoading = ref(false)
  let tableKey = 0
  let isShowEntityActive = ref(false)
  
  //let entityData = ref({deuda: 0, fecha: moment().format('YYYY-MM-DD')})
  let entityData = ref({deuda: 0, fecha: moment().format('YYYY-MM-DD'), estado: '', majr_code: ''})
  let items = ref([])
  let valueSelected = ref({})

  const validate = () => {
    form.value.validate()
  }

  const setOverlay = (value) => {
    overlay = value
  }

  function  initialize() {
    setOverlay(true)
    $http.get('/data/termcode')
        .then(response => {
      periodos.value = response.data

      $http.get('/data/currentTermCode')
        .then(resp => {
          entityData.value.term_code = resp.data.termcode
          setOverlay(false)
      })
    })
  }

  function  onSubmitGeneral() {
    page.value = 1
    onSubmit()
  }

  function  onSubmit() 
  {
    if (!valid.value) {
      return
    }          
    isLoading.value = true
      //items.value = []  
      entityData.value.itemsPerPage = itemsPerPage.value
      entityData.value.page = page.value          
      $http.post('/reports/matrideuda-list', entityData.value)
      .then(response => {
          items.value = response.data.data
          itemTotal.value = Number(response.data.rows)
          console.log(response.data.data)
          termSelected = true
          if(response.data.data.length>0){
              termSelected = true
            }else{
              termSelected = false
            }
          //this.valueSelected = {}
          isLoading.value = false          
          tableKey++
      })
      .catch(error => {
            isLoading.value = false
      })
  }

  function exportResult(){
    //alert(entityData.value.majr_code)
    window.open('/reports/matrideuda-export/?term_code=' + entityData.value.term_code  
      + '&majr_code='+(entityData.value.majr_code ?? '')
      +'&estado='+(entityData.value.estado ?? '')
      +'&fecha='+(entityData.value.fecha ?? '')
      +'&deuda='+(entityData.value.deuda ?? ''))
  }

  function changePage(pagenum){
    page.value = pagenum
    onSubmit()
  }

  function changeItemPerPage(perpage) {
    itemsPerPage.value = perpage
    page.value = 1
    onSubmit()
  }

  function getPrograms() {
    $http.get('/data/getPrograms')
    .then(response => {
      response.data.push({majr_code: '', name: 'TODOS'});
      programs.value = response.data
    })
  }

  function createEntityOrClose(){
    valueSelected.value = {}
    isShowEntityActive.value = !isShowEntityActive.value
  }

  onBeforeMount(() => {
    initialize()
    getPrograms()
   
  })

</script>
 
  <style>

  .row-pointer:hover {
    cursor: pointer;
  }

  </style>
  