<template>
  <v-card>
    <v-card-title >
      <h4><strong>Reporte de Facturación Vs Cobranza</strong></h4>
    </v-card-title>
    <v-toolbar flat v-if="isShowEntityActive">
      <v-btn 
      color="secondary"
      id="btnRegresar"
      class="mb-2"
      @click="createEntityOrClose"
      > 
          <v-icon left icon="mdi-arrow-left">
          </v-icon>
          Regresar
      </v-btn>
      <v-divider></v-divider>
    </v-toolbar>
      <v-divider v-if="!isShowEntityActive"></v-divider>
    <v-card-text v-if="!isShowEntityActive" class="my-4">
        <v-form ref="form"
        v-model="valid"
        @submit="onSubmit" 
        @submit.prevent="validate">
        <v-row>
          <v-col cols="12" md="4">
            <v-autocomplete
                    variant="outlined"
                    density="compact"
                    label="Periodo"
                    v-model="entityData.term_code"
                    :items="periodos"
                    item-title="period_desc"
                    item-value="period_val"
                    :menu-props="{ offsetY: true }"
                    hide-details="auto"
                    :rules="[validators.required]"
                  ></v-autocomplete>
            </v-col>            
            <v-col
            cols="12"
            md="4"
            >
            <v-btn block color="success" type="button" @click="exportResult" outlined :disabled="!termSelected"> 
            <v-icon
                left
                dark
                icon="mdi-file-excel"
                density="compact"
            >
            </v-icon>
            Exportar resultados</v-btn>
          </v-col>
          <v-col
            cols="12"
            md="4"
            > 
            <v-btn  block color="success" type="submit" :loading="isLoading">
                <v-icon
                left
                dark
                id="btnConsultar"
                icon="mdi-magnify"
                density="compact"
            >
            </v-icon>
                Consultar
            </v-btn>
          </v-col>
          
        </v-row>

        </v-form>
    </v-card-text>
    <u-c-datatable  v-if="!isShowEntityActive"
              class="mt-4 row-pointer"
              :items="items" 
              :key="tableKey"
              :isLoading="isLoading"
              :headers="headers"
              :itemTotal="itemTotal"
              :itemsPage="itemsPerPage"
              :page="page"
              @change-page="changePage"
              @item-per-page="changeItemPerPage"
        ></u-c-datatable>
        
  </v-card>
</template>

<script setup>
import useAppConfig from '@core/@app-config/useAppConfig';
import { required, requiredObject } from '@core/utils/validation.js';
import moment from 'moment';
import UCDatatable from './report-components/ReportTabla.vue';

  //variables de sistema
  let { overlay } = useAppConfig()
  const $http = inject('http')

  let periodos = ref([])
  let  validators = { required, 
    requiredObject}
  let headers = [
    { title: 'NIVEL', key: 'nivel', sortable: false, width: '300px',cellClass:'text-xs font-weight-bold'},
    { title: 'FACTURADO', key: 'facturado', filterable: true, align: 'right', cellClass:'nowrap', sortable: false},
    { title: 'COBRADO', key: 'cobrado', filterable: true , align: 'right', sortable: false},
    { title: 'SALDOS POR PAGAR', key: 'saldos_x_pagar', align: 'right', cellClass:'font-weight-bold',  sortable: false  },
  ]

  const valid = ref(false)
  const form = ref(null)
  let page = ref(1)
  let itemsPerPage = ref(25)
  let itemTotal = ref(0)
  let isLoading = ref(false)
  let termSelected = ref(false)
  let tableKey = 0
  let isShowEntityActive = ref(false)
  
  let entityData = ref({ from_date: moment().format('YYYY-MM-DD'), 
                          to_date: moment().format('YYYY-MM-DD')})
  let items = ref([])
  let valueSelected = ref({})

  const validate = () => {
    form.value.validate()
  }

  const setOverlay = (value) => {
    overlay = value
  }

  function  initialize() {
    setOverlay(true)
    $http.get('/data/termcode')
    .then(response => {
      response.data.push({period_val: '2023', period_desc: 'Año 2023'});
      response.data.push({period_val: '2024', period_desc: 'Año 2024'});

      periodos.value = response.data

      $http.get('/data/currentTermCode')
        .then(resp => {
          entityData.value.term_code = resp.data.termcode
          setOverlay(false)
      })
    })
   
  }

  function  onSubmitGeneral() {
    page.value = 1
    onSubmit()
  }

  function  onSubmit() 
  {
    if (!valid.value) {
      return
    }          
    isLoading.value = true
      //items.value = []  
      entityData.value.itemsPerPage = itemsPerPage.value
      entityData.value.page = page.value          
      $http.post('reports/facturacobranza-list', entityData.value)
        .then(response => {
            if(response.data.data.length>0){
              termSelected = true
            }else{
              termSelected = false
            }
            isLoading.value = false      
            items.value = response.data.data
            itemTotal.value = Number(response.data.rows)
            tableKey++


        })
        .catch(error => {
            isLoading.value = false
        })
  }

  function exportResult(){
      window.open('/reports/facturacobranza-export/?term_code=' + entityData.value.term_code )
    }

  function changePage(pagenum){
    page.value = pagenum
    onSubmit()
  }

  function changeItemPerPage(perpage) {
    itemsPerPage.value = perpage
    page.value = 1
    onSubmit()
  }

  function createEntityOrClose(){
    valueSelected.value = {}
    isShowEntityActive.value = !isShowEntityActive.value
  }

  onBeforeMount(() => {
    initialize()
    

  })

</script>
 
  <style>

  .row-pointer:hover {
    cursor: pointer;
  }

  </style>
  