
<template>
    <div class="text-sm">
      <v-card-text class="my-6">
        <v-row>
          <v-col
            cols="12"
            md="6"
          >
          <span>Total de Registros: {{itemTotal}}</span>
            </v-col>
          <v-spacer></v-spacer>
        </v-row>
      </v-card-text>
      <v-data-table-server
        class="pb-4"
        density="compact"
        :headers="headers"
        :items="items"
        :loading="isLoading"
        :page="page"
        :items-per-page="itemsPerPage"
        items-per-page-text="Items por Página"
        :search="search"
        no-data-text="No hay datos para mostrar"
        hide-default-footer
        :items-length="itemTotal"
        @update:itemsPerPage="changeItemPerPage"
        @update:page="changePage"
  
      
      >
        <template #[`item.dni`]="{item}">
            <strong>{{item.value.dni}}</strong>
        </template>
        <template #[`item.nombre`]="{item}">
              <span class="text-primary">{{item.value.nombre}}</span>
        </template>
        <template v-slot:loading>
          <div class="text-center py-4">
            <p>Obteniendo Data ...</p>
          </div>
        </template>
        <template #[`item.cobranza`]="{item}">
              <strong>{{item.value.cobranza}}</strong>
        </template>
      </v-data-table-server>
    </div>
  </template>
  <script>
  import { ref } from 'vue'
  //import * as moment from 'moment'
  import useAppConfig from '@core/@app-config/useAppConfig'
import { required, requiredObject } from '@core/utils/validation.js'
  
  export default {
  props: {
    items: {
      type: Array,
      required: true
    },
    isLoading: {
      type: Boolean,
      default: false,
    },
    headers: {
      type: Array,
      required: true
    },
    sortBy: {
      type: String,
      default: "id"
    },
    showSelect: {
      type: Boolean,
      default: true
    },
    nameAction: {
      type: String,
      default: 'Guardar'
    },
    search: {
      type: String,
      default: ''
    },
    itemTotal: {
      type: Number,
      default: null
    },
    itemsPage: {
      type: Number,
      default: 25
    },
    page: {
      type: Number,
      default: 1
    }
  },
  
  setup(props) {
  
    const enabledColor = (value) => {
        switch (value) {
        case 'AS':
          return 'info';
        case 'RP':
          return 'error';
        case 'IS':
          return 'primary';
        default:
          return 'secondary';
      }
    }
  
    var { overlay } = useAppConfig()
  
    const valid = ref(false)
    const form = ref(null)
    const validate = () => {
      form.value.validate()
    }
  
    const resetValidation = ()=> {
      form.value.resetValidation()
    }
  
    const entityData = ref({})
  
    return {
      page: props.page,
      pageCount: 0,
      itemsPerPage: props.itemsPage,
      enabledColor,
      valueSelected: {},
      msgConfirm: '',
      activemsgConfirm: false,
      msgConfirmReenvio: '',
      overlay,
      equipos: [],
      valid,
      form,
      validate,
      resetValidation,
      isDialogOpen: false,
      validators: { required, requiredObject}
    }
  },
  methods: {
    loadAlert(text, type="error", title="Advertencia"){
      this.$swal.fire({
              title: title,
              text: text,
              icon: type,
              confirmButtonText: 'OK',
            })
    },
    formatDate(created_at) {
        return moment(created_at).format('DD/MM/YY');
    },
    formatDateTime(fecha) {
      if(fecha==null) return ''
      return moment(fecha).format('DD/MM/YY HH:mm');
    },
    changeItemPerPage(item){
      this.valueSelected = {}
      this.$emit('item-per-page', item)
    },
    selectRow(event, row){
      this.$emit('show-form',row.item.value)
    },
    changePage(value){
      this.valueSelected = {}
      this.$emit('change-page', value)
    }
  }
  }
  </script>