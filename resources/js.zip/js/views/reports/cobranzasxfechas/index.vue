<template>
  <v-card>
    <v-card-title >
      <h4><strong>Reporte de Cobranzas por Rango de Fechas</strong></h4>
    </v-card-title>
    <v-toolbar flat v-if="isShowEntityActive">
      <v-btn 
      color="secondary"
      id="btnRegresar"
      class="mb-2"
      @click="createEntityOrClose"
      > 
          <v-icon left icon="mdi-arrow-left">
          </v-icon>
          Regresar
      </v-btn>
      <v-divider></v-divider>
    </v-toolbar>
      <v-divider v-if="!isShowEntityActive"></v-divider>
    <v-card-text v-if="!isShowEntityActive" class="my-4">
        <v-form ref="form"
        v-model="valid"
        @submit="onSubmit" 
        @submit.prevent="validate">
        <v-row>
          <v-col cols="12" md="3">
              <v-text-field
                  label="Fecha Inicial"
                  v-model="entityData.from_date"
                  outlined
                  type="date"            
                  dense
                  hide-details="auto"
                  density="compact"
                  :now="today"
                ></v-text-field>
          </v-col>
          <v-col cols="12" md="3">
              <v-text-field
                  label="Fecha Final"
                  v-model="entityData.to_date"
                  outlined
                  type="date"
                  dense
                  hide-details="auto"
                  density="compact"
                ></v-text-field>
            </v-col>
            <v-col cols="12" md="3">
              <v-autocomplete
                variant="outlined"
                density="compact"
                label="Tipo de Pago"
                v-model="entityData.tipo_pago"
                :items="tipos"
                item-title="descr"
                item-value="codigo"
                :menu-props="{ offsetY: true }"
                hide-details="auto"
                  ></v-autocomplete>
            </v-col> 
            <v-col cols="12" md="3">
              <v-autocomplete
                variant="outlined"
                density="compact"
                label="Usuario"
                v-model="entityData.user"
                :items="users"
                item-title="nomuser"
                item-value="nomuser"
                :menu-props="{ offsetY: true }"
                hide-details="auto"
                  ></v-autocomplete>
            </v-col> 
        </v-row>
        <v-row>
          <v-spacer></v-spacer>
          <v-col
            cols="12"
            md="3"
            >
            <v-btn block color="success" type="button" :loading="isLoading2" @click="graficoTipoPago" outlined :disabled="!termSelected" > 
            <v-icon
              left
              dark
              icon="mdi-chart-bar"
            >
            </v-icon>
            Por Tipo de Pago</v-btn>
          </v-col>
          <v-col
            cols="12"
            md="3"
            >
            <v-btn block color="success" type="button" :loading="isLoading2" @click="grafFechas" outlined :disabled="!termSelected" > 
            <v-icon
                left
                dark
                icon="mdi-chart-bar"
            >
            </v-icon>
            Por Fechas</v-btn>
          </v-col>
          <v-col
            cols="12"
            md="3"
            >
            <v-btn block color="success" type="button" :loading="isLoading" @click="exportResult" outlined :disabled="!termSelected" > 
            <v-icon
                left
                dark
                icon="mdi-file-excel"
            >
            </v-icon>
            Exportar</v-btn>
          </v-col>
          <v-col
            cols="12"
            md="3"
            > 
            <v-btn  block color="success" type="submit" :loading="isLoading" >
                <v-icon
                left
                dark
                id="btnConsultar"
                icon="mdi-magnify"
            >
            </v-icon>
                Consultar
            </v-btn>
          </v-col>
        </v-row>
        </v-form>
    </v-card-text>
    <u-c-datatable  v-if="!isShowEntityActive"
              class="mt-4 row-pointer"
              :items="items" 
              :key="tableKey"
              :isLoading="isLoading"
              :headers="headers"
              :itemTotal="itemTotal"
              :itemsPage="itemsPerPage"
              :page="page"
              @change-page="changePage"
              @item-per-page="changeItemPerPage"
        ></u-c-datatable>
        
  </v-card>
  <v-row justify="center">
    <v-dialog
      v-model="entityData.dialog"
      fullscreen
      :scrim="false"
      transition="dialog-bottom-transition"
    >
      <v-card>
        <v-toolbar
          dark
          color="primary"
        >
          <v-btn
            dark
            @click="dialog = false" 
            icon="mdi-close"
          >
            <v-icon></v-icon>
          </v-btn>
          <v-toolbar-title>Gráfico de barras por {{ grafico == 1 ? 'tipo de pago' : '' }} {{ grafico == 2 ? 'rango de fechas' : '' }}</v-toolbar-title>
          <v-spacer></v-spacer>
          <v-toolbar-items>
            <v-btn
              variant="text"
              @click="entityData.dialog = false"
            >
              Cerrar
            </v-btn>
          </v-toolbar-items>
        </v-toolbar>
        <v-list
          lines="two"
          subheader
        >
        
        </v-list>

        <VCardText>
          <VueApexCharts
            type="bar"
            :options="options"
            :series="series"
            :height="420"
          />

        </VCardText>

        <v-divider></v-divider>
        
      </v-card>
    </v-dialog>
  </v-row>
</template>

<script setup>
import useAppConfig from '@core/@app-config/useAppConfig';
import { required, requiredObject } from '@core/utils/validation.js';
import { hexToRgb } from '@layouts/utils';
import moment from 'moment';
import VueApexCharts from "vue3-apexcharts";
import { useTheme } from 'vuetify';
import UCDatatable from './report-components/ReportTabla.vue';

  //variables de sistema
  let { overlay } = useAppConfig()
  const $http = inject('http')
  let  validators = { required, 
    requiredObject}
  let headers = [
    { title: 'DNI', key: 'dni', sortable: false, width: '150px',cellClass:'text-xs font-weight-bold', align:'center'},
    { title: 'NOMBRES', key: 'nombre', filterable: true, width: '320px', cellClass:'nowrap', sortable: false},
    { title: 'HORA', key: 'hora', filterable: true , width: '150px',align: 'center', sortable: false},
    { title: 'PERIODO', key: 'tbraccd_term_code', cellClass:'font-weight-bold', align: 'right', sortable: false  },
    { title: 'TIPO DE PAGO', key: 'tipo_pago', cellClass:'font-weight-bold', align: 'right', sortable: false  },
    { title: 'TIPO DE COBRO', key: 'tp_cobro', cellClass:'font-weight-bold', align: 'right', sortable: false  },
    { title: 'REF', key: 'ref', cellClass:'font-weight-bold', align: 'right', sortable: false  },
    { title: 'COBRANZA', key: 'cobranza', cellClass:'font-weight-bold', align: 'right', sortable: false  },
  ]

  const valid = ref(false)
  const form = ref(null)
  let page = ref(1)
  let itemsPerPage = ref(25)
  let itemTotal = ref(0)
  let grafico = ref(0)
  let isLoading = ref(false)
  let isLoading2 = ref(false)
  
  let termSelected = ref(false)
  let dialog= false
  let tableKey = 0
  let isShowEntityActive = ref(false)
  
  let entityData = ref({ from_date: moment().format('YYYY-MM-DD'), 
                          to_date: moment().format('YYYY-MM-DD'),
                          tipo_pago: ''})
  let tipos = ref()
  let users = ref()
  let items = ref([])
  
  let titulos = []
  let valores = []

  let valueSelected = ref({})

  const validate = () => {
    form.value.validate()
  }

  const setOverlay = (value) => {
    overlay = value
  }

  //Empieza gráfico de barras
  const vuetifyTheme = useTheme()
  const options = controlledComputed(() => vuetifyTheme.name.value, () => {
    const currentTheme = ref(vuetifyTheme.current.value.colors)
    const variableTheme = ref(vuetifyTheme.current.value.variables)
    const disabledColor = `rgba(${ hexToRgb(currentTheme.value['on-surface']) },${ variableTheme.value['disabled-opacity'] })`
    const borderColor = `rgba(${ hexToRgb(String(variableTheme.value['border-color'])) },${ variableTheme.value['border-opacity'] })`
    
    //console.log(disabledColor)
    return {
      chart: { 
        parentHeightOffset: 0,
        toolbar: { show: false },
      },
      plotOptions: {
        bar: {
          borderRadius: 9,
          distributed: true,
          columnWidth: '95%',
          endingShape: 'rounded',
          startingShape: 'rounded',
          dataLabels: {
                  position: 'top', // top, center, bottom

                },

        },
      },
      stroke: {
        width: 2,
        colors: [currentTheme.value.surface],
      },
      legend: { show: false },
      grid: {
        borderColor,
        strokeDashArray: 7,
        padding: {
          top: -1,
          right: 0,
          left: -12,
          bottom: 5,
        },
      },
      dataLabels: { enabled: true ,
        offsetY: -20,
        style: {
          colors: ['#000000']
        },},
      colors: [
        '#ff5252',
        '#52ff83',
        '#52ff83',
        '#ffb452',
        '#4d71cb',
        '#4be094',
        '#9111c0',
        '#c09911',
        '#c04311',
        '#117cc0',
        '#c0112e',
        '#c01174',
      ],
      states: {
        hover: { filter: { type: 'none' } },
        active: { filter: { type: 'none' } },
      },
      xaxis: {
        categories: titulos ,
        tickPlacement: 'on',
        labels: { show: true },
        crosshairs: { opacity: 0 },
        axisTicks: { show: false },
        axisBorder: { show: false },
      },
      yaxis: {
        show: true,
        tickAmount: 4,
        labels: {
          offsetX: -17,
          style: {
            colors: disabledColor,
            //colors: '#6675df',
            fontSize: '12px',
          },
          //formatter: value => `${ value > 999 ? `${ (value / 1000).toFixed(1) }` : value }`,
        },
      },
    }
  })
  const series = [{
    data: valores
  }]

  //Termina gráfico de barras
  
  function  initialize() {
    
    setOverlay(true)
    $http.get('/data/getTypePaymentsHarson')
    .then(response => {
      response.data.push({descr: 'TODOS', codigo: ''});
      tipos.value = response.data
    })   
    $http.post('data/getUsers', entityData.value)
    .then(response => {
      users.value = response.data
    })   
    
  } 

  function  onSubmit() 
  {
    if (!valid.value) {
      return
    }          
    isLoading.value = true
    //items.value = []  
    entityData.value.itemsPerPage = itemsPerPage.value
    entityData.value.page = page.value 
    
    //LISTA
    $http.post('reports/cobranzafechas-list', entityData.value)
      .then(response => {
          if(response.data.data.length>0){
            termSelected = true
          }else{
            termSelected = false
          }
          //console.log(response.data.data)
          isLoading.value = false      
          items.value = response.data.data
          itemTotal.value = Number(response.data.rows)
          tableKey++
      })
      .catch(error => {
        isLoading.value = false
      })
  }

  function exportResult(){
    window.open('/reports/cobranzafechas-export/?from_date=' + entityData.value.from_date
        +'&to_date='+(entityData.value.to_date ?? '')
        +'&tipo_pago='+(entityData.value.tipo_pago ?? '')
        +'&user='+(entityData.value.user ?? ''))
  }

  function graficoTipoPago(){
    titulos.length = 0
    valores.length = 0
    grafico = 1
    isLoading2.value = true
    $http.post('reports/cobranzafechas-graf-tipo', entityData.value)
    .then(response => {
      //console.log("aaaca")
      response.data.filter((item) => {

          valores.push(item.cobranza)
          titulos.push(item.tipo_pago)
      });

      entityData.value.dialog = true
      isLoading2.value = false   
      tableKey++
    })
    .catch(error => {
      isLoading2.value = false
    }) 
  }

  function grafFechas(){
    titulos.length = 0
    valores.length = 0
    grafico = 2
    isLoading2.value = true
    $http.post('reports/cobranzafechas-graf-fechas', entityData.value)
    .then(response => {
      //console.log("aaaca")
      response.data.filter((item) => {

          valores.push(item.cobranza)
          titulos.push(item.fecha)
      });

      entityData.value.dialog = true
      isLoading2.value = false   
      tableKey++
    })
    .catch(error => {
      isLoading2.value = false
    }) 
  }
  
  function graficoFechas(){
    titulos.length = 0
    valores.length = 0

    isLoading.value = true
    $http.post('reports/cobranzafechas-graf-tipo', entityData.value)
    .then(response => {
      //console.log("aaaca")
      response.data.filter((item) => {

          valores.push(item.cobranza)
          titulos.push(item.tipo_pago)
      });

      entityData.value.dialog = true
      isLoading.value = false   
      tableKey++
    })
    .catch(error => {
      isLoading.value = false
    }) 
  }
  function changePage(pagenum){
    page.value = pagenum
    onSubmit()
  }

  function changeItemPerPage(perpage) {
    itemsPerPage.value = perpage
    page.value = 1
    onSubmit()
  }

  function createEntityOrClose(){
    valueSelected.value = {}
    isShowEntityActive.value = !isShowEntityActive.value
  }

  onBeforeMount(() => {
    initialize()
    

  })

</script>
 
  <style>

  .row-pointer:hover {
    cursor: pointer;
  }

  </style>
  