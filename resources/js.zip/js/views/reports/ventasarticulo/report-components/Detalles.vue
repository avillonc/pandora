<template>
  <v-card-text >
        <v-row>
          <v-spacer></v-spacer>
          <v-col
            cols="12"
            md="9"
            > 
          </v-col>
          <v-col
            cols="12"
            md="3"
            >
            <v-btn block color="success" type="button" @click="exportResultDet" outlined > 
            <v-icon
                left
                dark
                icon="mdi-file-excel"
            >
            </v-icon>
            Exportar resultados</v-btn>
          </v-col>
          
        </v-row>
      </v-card-text>
<div class="text-sm">
      <v-card-text >
        <v-row>
          <v-col
            cols="12"
            md="6"
          >
          <span>Total de Registros: {{itemTotal}}</span>
            </v-col>
          <v-spacer></v-spacer>
        </v-row>
      </v-card-text>
      <v-data-table-server
        class="pb-4"
        density="compact"
        :headers="headers"
        :items="entityData.detalles"
        :loading="isLoading"
        :page="page"
        :items-per-page="itemsPerPage"
        items-per-page-text="Items por Página"
        :search="search"
        no-data-text="No hay datos para mostrar"
        hide-default-footer
        :items-length="itemTotal"
        @update:itemsPerPage="changeItemPerPage"
        @update:page="changePage"
      >
        <template #[`item.spriden_id`]="{item}">
            <strong>{{item.value.spriden_id}}</strong>
        </template>
        <template #[`item.fullname`]="{item}">
              <span class="text-primary">{{item.value.fullname}}</span>
        </template>
        <template #[`item.tbraccd_amount`]="{item}">
              <span class="text-success">{{item.value.tbraccd_amount}}</span>
        </template>
        <template v-slot:loading>
          <div class="text-center py-4">
            <p>Obteniendo Data ...</p>
          </div>
        </template>
      </v-data-table-server>
    </div>
</template>

<script>
import useAppConfig from '@core/@app-config/useAppConfig';
import { maxlengthValidator, required } from '@core/utils/validation.js';
//import * as moment from 'moment'
import { ref } from 'vue';


export default {

  props: {
    valueSelected: {
      type: Object,
      required: true,
    },
    from_date: {
      type: Object,
      required: true,
    },
    to_date: {
      type: Object,
      required: true,
    },
  },
  setup() {


    var { overlay } = useAppConfig()
    let  entityData = ref({detalles: []})
    const valid = ref(false)
    const form = ref(null)
    const validate = () => {
      form.value.validate()
    }

    const resetValidation = ()=> {
      form.value.resetValidation()
    }

    return {
      validators: { required},
      valid,
      entityData,
      form,
      validate,
      resetValidation, 
      validators: { required, maxlengthValidator},
      headers: [
        { title: 'Dni', key: 'spriden_id', cellClass:'title-xs' },
        { title: 'Nombres', key: 'fullname', cellClass:'title-xs'  },
        { title: 'Periodo', key: 'periodo',  cellClass:'title-xs'  },
        { title: 'Correo', key: 'correo',  cellClass: 'title-xs'},
        { title: 'Teléfono', key: 'telefono',  cellClass:'title-xs' },
        { title: 'Carrera', key: 'carrera',  cellClass:'title-xs' },
        { title: 'Fecha', key: 'fecha',  cellClass:'title-xs' },
        { title: 'Can', key: 'cantidad',  cellClass:'title-xs' },
        { title: 'Importe doc', key: 'tbraccd_amount', align:'text-right', cellClass:'title-xs' },
        { title: 'Saldo', key: 'saldo',  cellClass:'title-xs' },
      ],
      overlay,
      collapseOnScroll: true,
    }
  },
  
  mounted(){
    //console.log(this.valueSelected.codigo)
    this.onSubmit()
    this.blankentityData()

  },
  methods: {
    loadAlert(text, type="error", title="Advertencia"){
      this.$swal.fire({
              title: title,
              text: text,
              icon: type,
              confirmButtonText: 'OK',
            })
    },
    onSubmit() {
          var data = {codigo: this.valueSelected.codigo, from_date: this.from_date, to_date: this.to_date}
          this.overlay = true
          this.$http.post('reports/ventas-detalles', data)
          .then(response => {   
            //console.log(response.data)
              this.entityData.detalles = response.data.data
            
              this.key1++
              this.overlay = false   
              this.$forceUpdate() 
          })
          .catch(error => {
                this.overlay = false
                this.loadAlert(error.response.data.message)
          })
      },
      exportResultDet(){
        window.open('/reports/ventas-export-det/?codigo=' + this.valueSelected.codigo
            +'&from_date='+(this.from_date ?? '')
            +'&to_date='+(this.to_date ?? ''))
      },      
    blankentityData(){
      this.entityData = {}
    },

  }
}
</script>
<style lang="scss">

</style>