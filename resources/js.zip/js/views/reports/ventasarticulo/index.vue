<template>
  <v-card>
    <v-card-title >
      <h4><strong>Reporte de Ventas</strong></h4>
    </v-card-title>
    <v-toolbar flat v-if="isShowEntityActive"
        style="background: rgb(var(--v-theme-on-white))">
        <v-btn 
        variant="tonal"
        color="secondary"
        id="btnRegresar"
        class="mb-2"
        @click="createEntityOrClose"
        > 
            <v-icon left icon="mdi-arrow-left">
            </v-icon>
            Regresar
        </v-btn>
        <v-divider></v-divider>
      </v-toolbar>
      <v-divider v-if="!isShowEntityActive"></v-divider>
      <v-card-text v-if="!isShowEntityActive" class="my-4">
        <v-form ref="form"
        v-model="valid"
        @submit="onSubmit" 
        @submit.prevent="validate">
        <v-row>
          <v-col cols="12" md="3">
              <v-text-field
                  label="Fecha Inicial"
                  v-model="entityData.from_date"
                  outlined
                  type="date"            
                  dense
                  hide-details="auto"
                  density="compact"
                  :now="today"
                ></v-text-field>
          </v-col>
          <v-col cols="12" md="3">
              <v-text-field
                  label="Fecha Final"
                  v-model="entityData.to_date"
                  density="compact"
                  outlined
                  type="date"
                  dense
                  hide-details="auto"
                ></v-text-field>
            </v-col>
          <v-col cols="12" md="6">
            <v-text-field
                label="Descripción"
                density="compact"
                v-model="entityData.concepto"
                outlined
                dense
                hide-details="auto"
            ></v-text-field>
          </v-col>
          
        </v-row>
        <v-row>
          <v-spacer></v-spacer>
          <v-col
            cols="12"
            md="3"
            >
            <v-btn block color="success" type="button" @click="exportResult" outlined :disabled="!termSelected" :loading="isLoading"> 
            <v-icon
                left
                dark
                icon="mdi-file-excel"
            >
            </v-icon>
            Exportar resultados</v-btn>
          </v-col>
          <v-col
            cols="12"
            md="3"
            > 
            <v-btn  block color="success" type="submit" :loading="isLoading">
                <v-icon
                left
                dark
                id="btnConsultar"
                icon="mdi-magnify"
            >
            </v-icon>
                Consultar
            </v-btn>
          </v-col>
        </v-row>
        </v-form>
    </v-card-text>
    <u-c-datatable v-if="!isShowEntityActive"
              class="row-pointer"
              :items="items" 
              :key="tableKey"
              :isLoading="isLoading"
              :headers="headers"
              :itemTotal="itemTotal"
              :itemsPage="itemsPerPage"
              :page="page"
              @change-page="changePage"
              @item-per-page="changeItemPerPage"
              @ver-detalles="verDetalles"
        ></u-c-datatable>
        <detalles v-if="isShowEntityActive"
        :from_date="from_date"
        :to_date="to_date"
        :valueSelected="valueSelected">
        </detalles>
  </v-card>
</template>

<script setup>
import useAppConfig from '@core/@app-config/useAppConfig';
import moment from 'moment';
import Detalles from './report-components/Detalles.vue';
import UCDatatable from './report-components/ReportTabla.vue';

  //variables de sistema
  let { overlay } = useAppConfig()
  const $http = inject('http')

  let headers = [
    { title: 'Código', key: 'codigo', sortable: false, width: '150px',cellClass:'text-xs font-weight-bold', align:'center'},
    { title: 'Descripción', key: 'descripcion', filterable: true, width: '400px', cellClass:'nowrap', sortable: false},
    { title: 'Cantidad', key: 'cantidad', filterable: true , align: 'center', sortable: false},
    { title: 'Importe', key: 'importe', cellClass:'font-weight-bold', align: 'right', sortable: false  },
    { title: 'Saldo', key: 'saldo', cellClass:'font-weight-bold', align: 'right', sortable: false  },
  ]

  const valid = ref(false)
  const form = ref(null)
  let page = ref(1)
  let itemsPerPage = ref(25)
  let itemTotal = ref(0)
  let isLoading = ref(false)
  let termSelected = ref(false)
  let tableKey = 0
  let itemSelected= ref({})
  let isShowEntityActive= ref(false)
  let entityData = ref({ from_date: moment().format('YYYY-MM-DD'), 
                          to_date: moment().format('YYYY-MM-DD')})
  let items = ref([])
  let valueSelected = ref({})
  let from_date = ref()
  let to_date = ref()
  
  const validate = () => {
    form.value.validate()
  }

  const setOverlay = (value) => {
    overlay = value
  }

  function  initialize() {
    setOverlay(true)
    setOverlay(false)
   
  }

  function  onSubmitGeneral() {
    page.value = 1
    onSubmit()
  }

  function  onSubmit() 
  {
    if (!valid.value) {
      return
    }          
    isLoading.value = true
      //items.value = []  
      entityData.value.itemsPerPage = itemsPerPage.value
      entityData.value.page = page.value          
      $http.post('reports/ventas-list', entityData.value)
        .then(response => {
            if(response.data.data.length>0){
              termSelected = true
            }else{
              termSelected = false
            }
            isLoading.value = false      
            items.value = response.data.data
            itemTotal.value = Number(response.data.rows)
            tableKey++


        })
        .catch(error => {
            isLoading.value = false
        })
  }

  function exportResult(){
    window.open('/reports/ventas-export/?from_date=' + entityData.value.from_date
        +'&to_date='+(entityData.value.to_date ?? '')
        +'&concepto='+(entityData.value.concepto ?? ''))
  }

  function changePage(pagenum){
    page.value = pagenum
    onSubmit()
  }

  function changeItemPerPage(perpage) {
    itemsPerPage.value = perpage
    page.value = 1
    onSubmit()
  }

  function createEntityOrClose(){
    valueSelected.value = {}
    isShowEntityActive.value = !isShowEntityActive.value
  }

  onBeforeMount(() => {
    initialize()
  })
  function verDetalles(selected){
    valueSelected.value = selected
    from_date.value = entityData.value.from_date
    to_date.value = entityData.value.to_date
    isShowEntityActive.value = true
  }

</script>
 
  <style>

  .row-pointer:hover {
    cursor: pointer;
  }

  </style>
  