<template>
  <div>
    <v-card>
      <v-card-title class="my-2">
        <h3><strong>{{ isShowEntityActive ?  ( isEmpty(entityData.idLaboratorio) ? 'Nuevo Usuario' : 'Editar Usuario') : 'Usuarios' }}</strong></h3>
      </v-card-title>
      <v-spacer></v-spacer>
      <UCToolbar
        :showForm="isShowEntityActive"
        @on-create="createEntityOrClose"
        @on-read="initialize"
      ></UCToolbar>
      <u-c-data-table-options 
        :key="tableKey"
        v-if="!isShowEntityActive" 
        :items="items" 
        :isTable="false"
        :isLoading="isLoading"
        :headers="headers"
        :search="search"
        sortBy="idLaboratorio"
        @edit="editEntity"
        @delete="showMessageDelete"
        itemKey="idLaboratorio">
        <template>
          <v-text-field
            slot="fieldSearch"
            v-model="search"
            append-icon="mdi-magnify"
            label="Buscar en la tabla"
            hide-details
            density="compact"
            variant="outlined"
            small
          ></v-text-field>
        </template>
      </u-c-data-table-options>
      <UCDialogQuestion
        :visible="activeMsgDelete"
        :message="msgDelete"
        title="Eliminar"
        @cancel="closeMsgDelete"
        @ok="deleteEntity"
      ></UCDialogQuestion>
      <user-entity
        v-if="isShowEntityActive"
        :roles="roles"
        :entityData="entityData" 
        @create="onCreateEntity"
        @on-backward="createEntityOrClose"
        @load-alert="loadAlert"
        @reload="initialize">
      </user-entity> 
    </v-card>
  </div>
</template>

<script>

import UCDataTableOptions from '@/components/UCDataTableOptions.vue'
import UCToolbar from '@/components/UCToolbar.vue'
import UCDialogQuestion from '@/components/UCDialogQuestion.vue'
import UserEntity from './user-components/UserForm.vue'
import { ref } from 'vue'
import { isEmpty } from '@core/utils/index'
import useAppConfig from '@core/@app-config/useAppConfig'

export default {
  components: {
    UserEntity,
    UCDataTableOptions,
    UCToolbar,
    UCDialogQuestion
  },
  setup() {
    const entityData = ref({})
    var { overlay } = useAppConfig()

    let isShowEntityActive = ref(false)
    let items = ref([])
    let entity_user = ref({})
    let roles = ref([])
    let activeMsgDelete = ref(false)
    let tableKey = ref(0)

    return {
      entityData,
      isShowEntityActive,
      isLoading: false,
      items,
      entity_user,
      headers: [
        { title: 'ID', key: 'id', sortable: false, width: '40px'},
        { title: 'USUARIO', key: 'dni', sortable: false, width: '40px'},
        { title: 'USUARIO BANNER', key: 'username', sortable: false},
        { title: 'NOMBRE COMPLETO', key: 'name', sortable: false},
        { title: 'ROL', key: 'role_name', sortable: false},
        { title: 'CORREO', key: 'email', sortable: false},
        { title: '', key: 'options', sortable: false },
      ],
      activeMsgDelete,
      msgDelete: '',
      tableKey,
      itemsPage: 25,
      page: 1,
      isEmpty,
      overlay,
      roles, 
      search: ''
    }
  },
  beforeMount(){
    this.overlay = true
    this.$http.get('/maintenance/roles')
        .then(response => {
          this.roles = response.data
          this.overlay = false
          this.initialize()
        }).catch(error => {
            this.overlay = false
        })
  },
  methods: {
    loadAlert(text, type="error", title="Advertencia"){
      this.$swal.fire({
              title: title,
              text: text,
              icon: type,
              confirmButtonText: 'OK',
            })
    },
    initialize() {
      this.isLoading = true
      this.items = []
      this.$http.get('/maintenance/users')
          .then(response => {
            this.items = response.data
            this.isLoading = false
            this.tableKey +=1
            this.$forceUpdate()
      })
    },
    blankEntityData(){
      this.entityData = {estado: 1}
    },
    createEntityOrClose(){
      this.blankEntityData()
      this.isShowEntityActive = !this.isShowEntityActive
    },
    onCreateEntity(item){
      this.isShowEntityActive = false
      if(this.items.length==0) {
         this.items.push(item) 
      } else {
        this.items.splice(0, 0, item)
      }
      this.blankEntityData()
      this.overlay = false 
    },
    editEntity(item){
      this.entityData = item.raw
      this.isShowEntityActive = true
    },
    showMessageDelete(item){
      this.entityData = item.raw
      this.msgDelete = "¿Eliminar Usuario: " + this.entityData.name + "?"
      this.activeMsgDelete= true
    },
    closeMsgDelete(){
      this.blankEntityData()
      this.activeMsgDelete = false
    },
    deleteEntity(){
        this.overlay = true
        this.$http.delete('/maintenance/users/'+this.entityData.id)
            .then(() => {
              this.overlay = false
              
              const index = this.items.indexOf(this.entityData);
              if (index > -1) {
                  this.items.splice(index, 1);
              }

              this.tableKey +=1
              this.closeMsgDelete()
              this.loadAlert('Usuario eliminado correctamente', 'success', 'Éxito')
              
            })
            .catch(error => {  
                  this.overlay = false
                  this.loadAlert(error.response.data.message)
            })
    }
  }
}
</script>
