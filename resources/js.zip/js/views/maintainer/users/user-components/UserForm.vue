<template>
  <v-card-text class="mt-5">
        <v-form ref="form"
          v-model="valid"
          @submit="onSubmit" 
          @submit.prevent="preSubmit">
          <v-row>
            <v-col
              cols="12"
              md="7"
            >
              <v-text-field
                label="Nombres"
                v-model="entityData.first_name"
                variant="outlined"
                density="compact"
                hide-details="auto"
                :rules="[validators.required]"
              ></v-text-field>
            </v-col>
            <v-col
              cols="12"
              md="7"
            >
              <v-text-field
                label="Apellidos"
                v-model="entityData.last_name"
                variant="outlined"
                density="compact"
                hide-details="auto"
                :rules="[validators.required]"
              ></v-text-field>
            </v-col>
            <v-col
              cols="12"
              md="7"
            >
              <v-text-field
                label="DNI / USERNAME"
                v-model="entityData.dni"
                variant="outlined"
                density="compact"
                hide-details="auto"
                :rules="[validators.required]"
              ></v-text-field>
            </v-col> 
            <v-col
              cols="12"
              md="7"
            >
              <v-text-field
                label="Correo"
                v-model="entityData.email"
                variant="outlined"
                density="compact"
                hide-details="auto"
                :rules="[validators.required, validators.emailValidator]"
              ></v-text-field>
            </v-col> 
            <v-col cols="12" md="7">
          		<v-text-field
                  label="Username Banner"
                  v-model="entityData.username" 
                  variant="outlined"
                  density="compact"
                  hide-details="auto" 
                  :rules="[validators.required]"
                ></v-text-field>
          </v-col>
            <v-col cols="12" md="7">
              <v-autocomplete
                    label="Rol"
                    v-model="entityData.role_id" 
                    variant="outlined"
                    density="compact"
                    :items="roles"
                    item-title="name"
                    item-value="id"
                    :menu-props="{ offsetY: true }"
                    hide-details="auto"  
                    :rules="[validators.requiredObject]"
               ></v-autocomplete> 
            </v-col> 
            <v-col
              cols="12"
              md="7"
            > 
            </v-col>
            <v-col
              offset-md="4"
              cols="12"
              md="3"
            >
              <v-btn  block color="success" type="submit">
                <v-icon
                          left
                          dark
                          icon="mdi-content-save"
                        >
                        </v-icon>
                Guardar
              </v-btn>
            </v-col>
          </v-row>
        </v-form>
  </v-card-text>
</template>

<script>
import { isEmpty, getFieldDb } from '@core/utils/index'
import { required, requiredObject, emailValidator } from '@core/utils/validation.js'
import useAppConfig from '@core/@app-config/useAppConfig'

export default {
  props: {
    entityData: {
      type: Object,
      required: true,
    }, 
    roles: {
      type: Array,
      required: true
    }
  },
  setup() {
    const valid = ref(false)
    const form = ref(null)
    const validate = () => {
      form.value.validate()
    }

    var { overlay } = useAppConfig()

    const enabled = {
      2: 'Inactivo',
      1: 'Activo',
    }

    return {
      valid,
      form,
      validate,
      validators: { required, requiredObject, emailValidator },
      getFieldDb,
      isEmpty,
      overlay,
      enabled
    }
  },
  mounted(){
    if(!this.isEmpty(this.entityData.id)) {
      this.validate()
    }
  },
  methods: {
    preSubmit(){
      this.validate()
    },
    onSubmit(){
      if (!this.valid) {
          return
        }

        if(this.isEmpty(this.entityData.id)) {
          this.overlay = true
          this.$http.post('/maintenance/users', this.entityData)
            .then(response => {
                this.entityData.id = response.data.id
                this.entityData.role_name = response.data.role_name
                this.entityData.name = response.data.name
                this.$emit('create', this.entityData)
                this.$emit('load-alert', 'Usuario registrado correctamente', 'success', 'Éxito')
            })
            .catch(error => {     
                  this.overlay = false
                  this.$emit('load-alert', error.response.data.message)
            })
        } else {
           this.overlay = true
           this.$http.put('/maintenance/users/'+this.entityData.id, this.entityData) 
            .then(response => {
                this.entityData.role_name = response.data.role_name
                this.$emit('on-backward')
                this.overlay = false 
                this.$emit('load-alert', 'Usuario modificado correctamente', 'success', 'Éxito')
            })
            .catch(error => {     
                  this.overlay = false
                  this.$emit('load-alert', error.response.data.message)
            }) 
        }
    },
  }
}
</script>
