import { createRouter, createWebHistory } from 'vue-router'

import store from '@/store'

const ifNotAuthenticated = (to, from, next) => {
    if (!store.getters['app/isAuthenticated']) {
        next()
        return
    }
    next('/')
}

const ifAuthenticated = (to, from, next) => {
    if (store.getters['app/isAuthenticated']) {
        next()
        return
    }
    //next('/login')
    return next({ path: '/login' })
}


const router = createRouter({
  history: createWebHistory(import.meta.env.BASE_URL),
  scrollBehavior() {
    return { x: 0, y: 0 }
  },
  routes: [
    { path: '/', redirect: '/home' },
    {
      path: '/',
      component: () => import('../layouts/default.vue'),
      children: [
        {
          path: 'home',
          name: 'home',
          component: () => import('../views/home.vue'),
          beforeEnter: ifAuthenticated,
        },
        {
          path: 'teacher_registration',
          name:'teacher_registration',
          component: () => import('../views/home.vue'),
          beforeEnter: ifAuthenticated,
           meta: { 
            requiresAuth: true
          },
        },
        {
          path: 'studentsmonitoring',
          name:'studentsmonitoring',
          component: () => import('../views/counseling/StudentsMonitoring.vue'),
          beforeEnter: ifAuthenticated,
           meta: { 
            requiresAuth: true,
            levelOne: 'academiccounselor' 
          },
        }
      ]
    },
    {
      path: '/',
      component: () => import('../layouts/default.vue'),
      children: [
        {
          path: 'studentsmonitoring',
          name:'studentsmonitoring',
          component: () => import('../views/counseling/StudentsMonitoring.vue'),
          beforeEnter: ifAuthenticated,
           meta: { 
            requiresAuth: true,
            levelOne: 'academic_management' ,
            levelTwo: 'academiccounselor'
          },
        }
      ]
    },
    {
      path: '/',
      component: () => import('../layouts/default.vue'),
      children: [
        { 
          path: 'agreement',
          name: 'agreement',
          component: () => import('../views/application/Applications.vue'),
          beforeEnter: ifAuthenticated,
        },
        { 
          path: 'acceptance',
          name: 'acceptance',
          component: () => import('../views/application/Acceptance.vue'),
          beforeEnter: ifAuthenticated,
        },
      ],
      meta: {
            requiresAuth: true,
            levelOne: 'admission' ,
            levelTwo: 'applications'
      }     
    },
    {
      path: '/',
      component: () => import('../layouts/default.vue'),
      children: [
        {
          path: 'users',
          name:'users',
          component: () => import('../views/maintainer/users/Users.vue'),
          beforeEnter: ifAuthenticated,
           meta: { 
            requiresAuth: true,
            levelOne: 'security' 
          }
        },
      ]
    },
    {
      path: '/',
      component: () => import('../layouts/default.vue'),
      children: [
        {
          path: 'dailystatus',
          component: () => import('../views/dailystatus/applicants.vue'),
          beforeEnter: ifAuthenticated,
        },
      ],
      meta: {
            requiresAuth: true,
            levelOne: 'admission'
      },
    },
    {
      path: '/',
      component: () => import('../layouts/default.vue'),
      children: [
        {
          path: 'sells-report',
          component: () => import('../views/reports/ventasarticulo/index.vue'),
          beforeEnter: ifAuthenticated,
        },
        {
          path: 'debt-report',
          component: () => import('../views/reports/matriculadosdeuda/index.vue'),
          beforeEnter: ifAuthenticated,
        },
        {
          path: 'collections-report',
          component: () => import('../views/reports/cobranzasxfechas/index.vue'),
          beforeEnter: ifAuthenticated,
        },
        {
          path: 'billing-collections-report',
          component: () => import('../views/reports/facturacionvscobranzas/index.vue'),
          beforeEnter: ifAuthenticated,
        },
      ],
      meta: {
            requiresAuth: true,
            levelOne: 'reports',
            levelTwo: 'billings'
      },
    },
    {
      path: '/',
      path: '/', 
      component: () => import('../layouts/blank.vue'),
      children: [
        {
          path: 'login',
          name: 'login',
          component: () => import('../views/login.vue'),
          beforeEnter: ifNotAuthenticated
        },
        {
          path: 'login/:id/:token',
          name: 'loginid',
          component: () => import('../views/login.vue'),
          beforeEnter: ifNotAuthenticated,
        },
        {
          path: 'error-401',
          name: 'error-401',
          component: () => import('../views/notRegistered.vue'),
        },
        {
          path: 'error-403',
          name: 'error-403',
          component: () => import('../views/NotAuthorized.vue'),
        },
        {
          path: '/:pathMatch(.*)*',
          name: 'error-404',
          component: () => import('../views/Error404.vue'),
        },
      ],
    },
  ],
})

function searchPath(argument, level, levelTwo, path) {
  var find = argument.find(el => el.path == level);
  if (find != undefined) {
    if(find.children) {
        if (!searchPath(find.children, levelTwo, null, path)) {
          return searchPath(find.children, path, null, null)
        } else {
          return true
        }
    } else {
      return true
    }
  } 

  return false
}

router.beforeEach((to, _, next) => {
  //console.log(to)
  var menu = store.state.app.menu
  const levelOne=to.meta.levelOne ? to.meta.levelOne : to.path
  const levelTwo=to.meta.levelTwo ? to.meta.levelTwo : to.path

  if(to.meta.requiresAuth && to.meta.noValidate==undefined) {

    var findpath = searchPath(menu, levelOne, levelTwo, to.path) 

    if (!store.getters['app/isAuthenticated']) return next({ path: '/login' })
    if(!findpath) return next({ name: 'error-403' })
  }
    
  return next()

})



export default router
