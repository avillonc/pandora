<template>
  <div class="h-100 d-flex align-center justify-space-between">
    <!-- 👉 Footer: left content -->
    <span class="d-flex align-center text-caption">
      &copy;
      {{ new Date().getFullYear() }}. All rights Reserved
    </span>
  </div>
</template>
